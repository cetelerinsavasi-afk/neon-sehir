// =============================================================================
// ÇETE & İSTİHBARAT SİSTEMİ — TÜM SAYISAL KURALLAR TEK YERDE
// -----------------------------------------------------------------------------
// "ONAYLI" işaretli değerler talimattaki kesin kurallardır, değiştirilmemeli.
// "VARSAYIM" işaretli değerler talimatta sayısı verilmemiş, kaynak tasarımda
// olduğu belirtilen ama elimizdeki dosyalarda bulunmayan değerlerdir — oyun
// tasarımcısı tarafından onaylanana kadar bu dosyada tek satırdan
// değiştirilebilir. (Bkz. docs/cete-sistemi/ACIK-KARARLAR.md)
// =============================================================================

export const MS_HOUR = 60 * 60 * 1000;
export const MS_DAY = 24 * MS_HOUR;

export const GANG = {
  // --- Kurma (ONAYLI şartlar) ---
  CREATE_MIN_GOLD: 1_000_000,
  CREATE_MIN_REPUTATION: 100,
  CREATE_MIN_POWER: 40_000,
  // VARSAYIM: 1.000.000 altın şartı aynı zamanda kuruluş ücreti olarak
  // düşülür (para sistemden çıkar). 0 yapılırsa sadece "sahip olma" şartı olur.
  CREATE_FEE: 1_000_000,
  FOUNDER_START_PRESTIGE: 10_000_000, // ONAYLI

  // --- Rütbe (ONAYLI) ---
  SAG_KOL_SLOTS: 2,
  KIDEMLI_SLOTS: 4,
  RANK_THRESHOLD: 1_000_000, // altı → Çömez
  RESPECT_PRESTIGE: 1_000_000, // Mafya Babası saygısı
  // v64: saygı HAFTALIK — her oyuncuya haftada en fazla 1 kez (hafta Pazartesi 00:00'da başlar).
  // Bu sürümden önce gösterilmiş saygılar (hafta bilgisi olmayan) bu haftaya sayılır;
  // ilk sıfırlanma bir sonraki Pazartesi 00:00.
  RESPECT_LEGACY_WEEK: '2026-09-28',

  // --- Prestij kaynakları ---
  DONATION_PRESTIGE_PER_GOLD: 5, // ONAYLI: 1 altın bağış = 5 prestij
  // v38: dilimler 8'e çıktığı için savaş prestiji hasarın YARISI (500.000 hasar → 250.000 prestij)
  WAR_PRESTIGE_PER_POWER: 0.5,
  WITHDRAW_PRESTIGE_PER_GOLD: 5, // ONAYLI: Baba kendi hesabına aldığı her altın için 5 prestij kaybeder

  // --- Kasa & dağıtım (ONAYLI) ---
  // 00:00 kasasının %20'si "serbest": dağıtım + Baba'nın kendine aktarımı +
  // başka çeteye gönderim bu TEK hakkı paylaşır.
  DISTRIBUTABLE_RATIO: 0.2,
  DISTRIBUTION_TTL_MS: 24 * MS_HOUR,
  DIST_RANKED_SLOTS: 7, // rütbeliler dağıtımı: sabit 7 kişi
  DIST_MIN_SLOTS: 7, // diğer gruplar: en az 7 kişi
  DIST_MAX_SLOTS: 500,
  MIN_DONATION: 100,

  // --- Haraç / rüşvet (ONAYLI: alt/üst sınır yok) — v38: son dilim (21:00) başlayana kadar ödenir ---
  HARAC_PAY_DEADLINE_HOUR: 21,
  ATTACK_ANNOUNCE_HOUR: 12, // saldırılar tır sahibine 12:00'de duyurulur

  // --- Bahisli savaş ---
  BET_MIN_STAKE: 10_000, // VARSAYIM
  // ONAYLI: en fazla = iki çetenin 00:00 kasalarından KÜÇÜĞÜNÜN 1/4'ü
  BET_MAX_RATIO_OF_SMALLER_MIDNIGHT_KASA: 0.25,
  BET_OFFERS_PER_DAY: 1, // ONAYLI: çete başına günde 1 teklif
  // ONAYLI: bahis teklifi Cumartesi ve Pazar gönderilemez (Pzt–Cum açık).
  BET_OFFER_WEEKDAYS: [1, 2, 3, 4, 5],
  // v35: kabul edilen bahis bir sonraki saldırı diliminde başlar, 24 saat (v38: 8 dilim) sürer
  BET_DURATION_MS: 24 * MS_HOUR,
  // İstihbarat ihbar/açma/operasyon için son an: v38'de ilk 2 dilimin (6 saat) sonu
  BET_INTEL_WINDOW_MS: 6 * MS_HOUR,

  // --- Sabotaj / Operasyon — SABİT ücret (artık her yeni sabotaj/operasyonla
  // ARTMAZ). Çete sabotajı 50.000, İstihbarat operasyonu 100.000 altın. ---
  SABOTAGE_PRICE: 50_000,
  INTEL_OP_PRICE: 100_000,
  SABOTAGE_START_DEADLINE_HOUR: 12,
  ATTACK_PHASE_1_START_HOUR: 12, // sabotaj/operasyon 12:00–24:00 = 4 dilim (v38)

  // --- Ticaret yolu (ONAYLI) ---
  // v50: günlük sipariş limiti = o pazar savaşına katılan TÜM tarafların
  // (çeteler + İstihbarat) toplam gücünün %0,5'i. Yolu kazanan çete alır.
  // v67: %0,5 → %1 (mevcut yolların limiti de bir kez 2 katına çıkarılır — ensureRouteLimitV67)
  // v75: %1 → %0,5 (mevcut yolların limiti de bir kez yarıya indirilir — ensureRouteLimitV75)
  TRADE_ORDER_LIMIT_TOTAL_RATIO: 0.005,
  // v39 (ESKİ): kazanan çetenin kendi gücünün %1'i. Artık yalnızca tek seferlik
  // v39 geçişinde (ensureRouteLimitV39) kullanılır; yeni savaşları etkilemez.
  TRADE_ORDER_LIMIT_RATIO: 0.01,
  TRADE_ROUTE_BUY_RATIO: 0.5, // mağaza (yasaklı madde: Amazor) fiyatının yarısı
  ROUTE_HOLD_DAYS: 21, // kazanan yolu 21 gün elinde tutar
  // v67: sipariş Pzt–Cmt, 00:00–12:00 arası. Tır siparişten sonraki ilk 3 saatlik
  // dilimde (03·06·09·12) yola çıkar, o gecenin 00:00'ında depoya varır.
  // Yola çıktıktan sonraki 6 saat: ihbar / içerik sızdırma / sabotaj / operasyon.
  // Ardından saldırı (savunma) başlar ve 24:00'te biter. Haraç/rüşvet 21:00'e kadar.
  ORDER_WEEKDAYS: [1, 2, 3, 4, 5, 6],
  ORDER_DEADLINE_HOUR: 12,
  TRUCK_INTEL_WINDOW_MS: 6 * MS_HOUR,

  // --- Tır (ONAYLI) ---
  TRUCK_PRICE: 100_000,
  TRUCK_LIFE_DAYS: 21, // gün (sefer değil); son 1 gün sipariş verilemez
  TRUCK_CAPACITY: { araba: 10, silah: 10, yasakliMadde: 100 }, // tek tür ürün

  // --- Depo (ONAYLI) --- her alım +100 kapasite, ömürsüz, satılamaz
  DEPOT_PRICE: 100_000,
  DEPOT_CAPACITY_PER_PURCHASE: 100,
  // v71 — 2. el çete ilanına reklam (oyuncu ilanlarıyla aynı: 1000 altın / 24 saat, kasadan)
  MARKET_AD_PRICE: 1000,
  MARKET_AD_DURATION_MS: 24 * 60 * 60 * 1000,
  DEPOT_UNIT_SIZE: { araba: 10, silah: 10, yasakliMadde: 1 },

  // --- Aktiflik (ONAYLI: 30 gün hiçbir savaşa katılmayan atılır; Baba dahil) ---
  INACTIVE_WARN_DAYS: 29,
  INACTIVE_REMOVE_DAYS: 30,

  // --- Oylama (ONAYLI) ---
  DEVIRME_MIN_RATIO: 0.51, // >= %51
  AYAKLANMA_MIN_RATIO_EXCLUSIVE: 0.66, // > %66 (2-1, 4-2 geçer)
  KICK_MIN_RATIO_EXCLUSIVE: 0.51, // ONAYLI: %51'den fazla
  // ONAYLI: başarısız ayaklanmada başlatan çeteden atılır.
  AYAKLANMA_FAIL_KICKS_INITIATOR: true,
  // v33: oylamalar 00:00–12:00 arasında başlatılır, ANINDA başlar ve o gecenin 00:00'ında biter.
  VOTE_START_DEADLINE_HOUR: 12,
  SUGGESTION_MIN_INTERVAL_MS: 60 * 1000,

  // --- Metin limitleri ---
  NAME_MIN: 3,
  NAME_MAX: 24,
  NOTE_MAX: 160,
  CHAT_MAX: 300,
  CHAT_MIN_INTERVAL_MS: 1500,
};

export const INTEL = {
  JOIN_MIN_REPUTATION: 50, // ONAYLI (polislik şartı YOK)
  CODENAME_MIN: 3,
  CODENAME_MAX: 16,
  REPORT_PRESTIGE: 1_000_000, // ONAYLI: tır ihbarı
  LEAK_PRESTIGE: 1_000_000, // ONAYLI: tır içeriği sızdırma
  // v33: bahisli savaşa müdahale — ihbar/açma ödülü tırlarla aynı; operasyon sabit ücret
  BET_REPORT_PRESTIGE: 1_000_000,
  BET_LEAK_PRESTIGE: 1_000_000,
  BET_OP_PRICE: 100_000,
  TAKEDOWN_PRESTIGE: 10_000_000, // ONAYLI: çete çökertme
  POLICE_REWARD_PRESTIGE_PER_GOLD: 1, // ONAYLI: yakalama ödülü = prestij (1:1)
  // v50: pazar savaşını kazanırsa kasaya, savaşa katılan TÜM tarafların
  // (çeteler + İstihbarat) toplam gücünün %5'i girer (eskiden kendi gücünün 1/10'u).
  WAR_WIN_KASA_TOTAL_RATIO: 0.05,
  // v50: şüpheyle yakalanma cezasının (soygun / yasaklı madde) SADECE yarısı
  // kasaya girer; kalan yarısı yakılır (ekonomiden çıkar). Oyuncunun borcu değişmez.
  SUSPICION_FINE_KASA_RATIO: 1 / 2,
  // v88: kasa sınırı = üye sayısı × bu tutar. Gelen para sınırı aşan kısmı yanar.
  // Üye azalırsa fazla SİLİNMEZ; harcandıkça azalır, sınırın altına inene kadar
  // yeni gelir girmez. (İade edilen kendi parası — dağıtım/operasyon iadesi — sınırdan muaf.)
  KASA_CAP_PER_MEMBER: 100_000,
  KASA_RESET_V88: 1_000_000, // tek seferlik: kasa bu tutara indirilir
  KICK_BASKAN_MIN_RATIO_EXCLUSIVE: 0.66, // Başkan'ı atmak: > %66
  KICK_MIN_RATIO: 0.51, // diğerleri: >= %51
  // v61 (istismar önlemi): İstihbaratta en az bu kadar üye yoksa kimse atılamaz,
  // çıkarma oylaması başlatılamaz/uygulanmaz (kendi isteğiyle ayrılmak serbest).
  KICK_MIN_MEMBERS: 8,
  // v61: dağıtım yapılabilmesi için hedef grupta en az bu kadar üye olmalı
  // (Rütbeliler / Ajanlar / Muhbirler / Tüm üyeler — her biri ayrı sayılır).
  DIST_MIN_GROUP_MEMBERS: 5,
  NAME: 'İstihbarat',
  LOGO: { emoji: '🕵️', color: '#19e8ff', bg: '#06222b' },
};

// Çete rütbeleri (sıra = yetki sırası, küçük = daha yetkili)
export const GANG_RANKS = ['baba', 'sagkol', 'kidemli', 'tetikci', 'comez'];
export const INTEL_RANKS = ['baskan', 'sef', 'uzman', 'ajan', 'muhbir'];
export const RANK_LABELS = {
  baba: 'Mafya Babası',
  sagkol: 'Sağ Kol',
  kidemli: 'Kıdemli',
  tetikci: 'Tetikçi',
  comez: 'Çömez',
  baskan: 'Başkan',
  sef: 'Şef',
  uzman: 'Uzman',
  ajan: 'Ajan',
  muhbir: 'Muhbir',
};
// İstihbarat rütbesinin çete eşdeğeri (yetki kontrolünü tek fonksiyonla yapmak için)
export const INTEL_TO_GANG_EQUIV = { baskan: 'baba', sef: 'sagkol', uzman: 'kidemli', ajan: 'tetikci', muhbir: 'comez' };

export function rankLevel(rank) {
  const g = INTEL_TO_GANG_EQUIV[rank] || rank;
  const i = GANG_RANKS.indexOf(g);
  return i === -1 ? 99 : i;
}
export function atLeast(rank, minGangRank) {
  return rankLevel(rank) <= GANG_RANKS.indexOf(minGangRank);
}
export function isRanked(rank) {
  return atLeast(rank, 'kidemli');
}

// --- Logo seçenekleri (sunucu doğrular) ---
export const LOGO_EMOJIS = ['💀', '🐍', '🦂', '🐺', '🦅', '🐉', '🔥', '⚡', '🗡️', '🎯', '👑', '🃏', '🌹', '🕷️', '🦈', '💎', '⚔️', '🔱', '☠️', '🐅'];
export const LOGO_COLORS = ['#ff2e8c', '#19e8ff', '#ffd23f', '#7cff6b', '#b16bff', '#ff7a2e', '#ffffff', '#ff3b3b'];
export const LOGO_BGS = ['#1a0610', '#06222b', '#231c05', '#0b2208', '#170b26', '#2a1206', '#101318', '#2a0808'];

// --- Ticaret ürünleri (ONAYLI: 3 ürün, her pazar sıradaki: yasaklı madde →
// silah → araba). kind: material → AMAZOR fiyatı; weapon/vehicle → katalog.
export const TRADE_PRODUCTS = [
  { id: 'yasakliMadde', label: 'Yasaklı Madde', emoji: '💊', kind: 'material', material: 'yasakliMadde' },
  { id: 'silah', label: 'Silah', emoji: '🔫', kind: 'weapon' },
  { id: 'araba', label: 'Araba', emoji: '🚗', kind: 'vehicle' },
];
export const TRADE_PRODUCT_IDS = TRADE_PRODUCTS.map((p) => p.id);
export function productById(id) {
  return TRADE_PRODUCTS.find((p) => p.id === id) || null;
}

// Dağıtım hedef grupları
export const DIST_GROUPS = ['rutbeli', 'tetikci', 'comez', 'hepsi'];

// Savaş katılım pencereleri — v38: 3 saatlik 8 dilim (00,03,06,…,21 → slot 0..7)
export const WINDOW_HOURS = 3;
// v38 öncesi 6 saatlik dilim (geçiş günü çift saldırı koruması için)
export const LEGACY_WINDOW_HOURS = 6;
export const WAR_SHARDS = 8;
