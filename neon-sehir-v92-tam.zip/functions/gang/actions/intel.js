// İSTİHBARAT — sabit organizasyon (sabit ad + sabit logo), kod adıyla gizli
// kimlik, çetelere sızma (ihbar / içerik sızdırma), operasyon, rüşvet,
// İstihbarat üyesi Mafya Babası olursa karar paneli.
// Güncel onaylı kurallar: katılım şartı SADECE 50+ saygınlık (polislik
// şartı yok), karşı istihbarat yok, operasyona ekstra maliyet yok (sadece
// sabotaj ücreti).
import { GANG, INTEL, atLeast } from '../config.js';
import { addDays, midnightMsOf, dateKeyOf, truckTimes } from '../time.js';
import { decidedOutcome } from './votes.js';

const CODENAME_RE = /^[\p{L}\p{N}_\-. ]+$/u;

export function createIntelActions(core) {
  const { FV, fail, readMembership, readWallet, intelLog, announceIntel, notify, systemChat, cleanText, requireIntel } = core;

  const linkRef = (ctx, rosterId) => core.db.doc(`gangWorlds/${ctx.worldId}/intelRosterLinks/${rosterId}`);

  function intelDefaults() {
    return { name: INTEL.NAME, logo: INTEL.LOGO, note: 'Şehrin gölgesinde, her yerde.', memberCount: 0 };
  }
  function intelStateDefaults(ctx) {
    return { kasa: 0, kasaAtMidnight: 0, midnightDateKey: ctx.dateKey, distributableLeft: 0 };
  }

  // --- İstihbarattan ayrılma (sessiz): prestij silinir, kod adı serbest ---
  async function planIntelLeave(tx, ctx, membership) {
    const rosterSnap = await tx.get(ctx.ref.roster(membership.intelRosterId));
    return { rosterId: membership.intelRosterId, roster: rosterSnap.data() || null, actorId: ctx.actorId, membership };
  }
  function applyIntelLeave(tx, ctx, plan, { actorId = null } = {}) {
    const who = actorId || plan.actorId;
    tx.delete(ctx.ref.roster(plan.rosterId));
    tx.delete(linkRef(ctx, plan.rosterId));
    if (plan.roster?.codeName) tx.delete(ctx.ref.codeName(core.nameKeyOf(plan.roster.codeName)));
    tx.set(
      ctx.ref.membership(who),
      { intelRosterId: null, intelRank: null, intelCodeName: null, intelJoinedAtMs: null, intelDecisionGangId: null, intelDecisionDeadline: null },
      { merge: true }
    );
    tx.set(ctx.ref.intel(), { memberCount: FV.increment(-1) }, { merge: true });
    ctx.logs.push({ gang: 'intel_membership', world: ctx.worldId, event: 'leave' });
    // Gizlilik: kimseye "X ayrıldı" bildirimi GÖNDERİLMEZ.
  }

  function parseCodeName(v) {
    const codeName = cleanText(v, { min: INTEL.CODENAME_MIN, max: INTEL.CODENAME_MAX, field: 'Kod adı' });
    if (!CODENAME_RE.test(codeName)) fail('invalid-argument', 'Kod adında sadece harf, rakam, boşluk, _ - . kullanılabilir.');
    return { codeName, key: core.nameKeyOf(codeName) };
  }

  async function joinIntel(ctx, data) {
    const { codeName, key } = parseCodeName(data.codeName);
    return core.db.runTransaction(async (tx) => {
      const wallet = await readWallet(tx, ctx, ctx.actorId);
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const [codeSnap, intelSnap, stateSnap] = await Promise.all([tx.get(ctx.ref.codeName(key)), tx.get(ctx.ref.intel()), tx.get(ctx.ref.intelState())]);
      if (membership.intelRosterId) fail('failed-precondition', 'Zaten İstihbarattasın.');
      if (membership.gangRank === 'baba') fail('failed-precondition', 'Mafya Babası İstihbarata katılamaz.');
      if (wallet.reputation < INTEL.JOIN_MIN_REPUTATION) fail('failed-precondition', `İstihbarata katılmak için en az ${INTEL.JOIN_MIN_REPUTATION} saygınlık gerekli.`);
      if (codeSnap.exists) fail('already-exists', 'Bu kod adı kullanılıyor.');
      if (!intelSnap.exists) tx.set(ctx.ref.intel(), intelDefaults());
      if (!stateSnap.exists) tx.set(ctx.ref.intelState(), intelStateDefaults(ctx));
      const rosterRef = ctx.ref.rosterCol().doc();
      tx.set(rosterRef, { codeName, rank: 'muhbir', prestige: 0, prestigeAtMidnight: 0, joinedAtMs: ctx.now, lastActiveAtMs: ctx.now });
      tx.set(linkRef(ctx, rosterRef.id), { actorId: ctx.actorId });
      tx.set(ctx.ref.codeName(key), { rosterId: rosterRef.id });
      tx.set(
        ctx.ref.membership(ctx.actorId),
        { intelRosterId: rosterRef.id, intelRank: 'muhbir', intelCodeName: codeName, intelJoinedAtMs: ctx.now },
        { merge: true }
      );
      tx.set(ctx.ref.intel(), { memberCount: FV.increment(1) }, { merge: true });
      systemChat(tx, ctx, ctx.ref.intelChat('genel'), `🕵️ ${codeName} İstihbarata katıldı.`);
      ctx.logs.push({ gang: 'intel_membership', world: ctx.worldId, event: 'join' });
      return { rosterId: rosterRef.id, codeName };
    });
  }

  async function leaveIntel(ctx) {
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      requireIntel(membership);
      const plan = await planIntelLeave(tx, ctx, membership);
      applyIntelLeave(tx, ctx, plan);
      return { left: true };
    });
  }

  async function updateIntelNote(ctx, data) {
    const note = cleanText(data.note, { max: GANG.NOTE_MAX, field: 'Not' });
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const me = (await tx.get(ctx.ref.roster(rid))).data();
      if (!me || !['baskan', 'sef'].includes(core.effRank(me, ctx, 'muhbir'))) fail('permission-denied', 'Notu sadece Başkan ve Şefler değiştirebilir.');
      tx.set(ctx.ref.intel(), { note }, { merge: true });
      return { updated: true };
    });
  }

  // Kod adı değiştirme (✏️) — benzersiz; eski mesajlarda eski ad kalır.
  async function changeCodeName(ctx, data) {
    const { codeName, key } = parseCodeName(data.codeName);
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const [me, codeSnap] = await Promise.all([tx.get(ctx.ref.roster(rid)), tx.get(ctx.ref.codeName(key))]);
      if (!me.exists) fail('failed-precondition', 'İstihbarat üyesi değilsin.');
      const oldName = me.data().codeName;
      const oldKey = core.nameKeyOf(oldName || '');
      if (oldKey === key && oldName === codeName) return { codeName };
      if (codeSnap.exists && codeSnap.data().rosterId !== rid) fail('already-exists', 'Bu kod adı kullanılıyor.');
      if (oldKey !== key) {
        tx.delete(ctx.ref.codeName(oldKey));
        tx.set(ctx.ref.codeName(key), { rosterId: rid });
      }
      tx.update(ctx.ref.roster(rid), { codeName });
      tx.set(ctx.ref.membership(ctx.actorId), { intelCodeName: codeName }, { merge: true });
      if (me.data().rank === 'baskan') tx.set(ctx.ref.intel(), { baskanCode: codeName }, { merge: true });
      systemChat(tx, ctx, ctx.ref.intelChat('genel'), `✏️ ${oldName} artık ${codeName} kod adını kullanıyor.`);
      return { codeName };
    });
  }

  // İstihbarat sohbeti: genel (tüm üyeler) + yonetim (Başkan, Şef, Uzman).
  async function sendIntelChat(ctx, data) {
    const channel = String(data.channel || 'genel');
    if (!['genel', 'yonetim'].includes(channel)) fail('invalid-argument', 'Geçersiz kanal.');
    const text = cleanText(data.text, { min: 1, max: GANG.CHAT_MAX, field: 'Mesaj' });
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const me = (await tx.get(ctx.ref.roster(rid))).data();
      if (!me) fail('failed-precondition', 'İstihbarat üyesi değilsin.');
      if (channel !== 'genel' && !atLeast(core.effRank(me, ctx, 'muhbir'), 'kidemli')) fail('permission-denied', 'Bu kanala sadece rütbeliler yazabilir.');
      if (me.lastChatAtMs && ctx.now - me.lastChatAtMs < GANG.CHAT_MIN_INTERVAL_MS) fail('resource-exhausted', 'Biraz yavaş!');
      // Gerçek kimlik YOK: sadece kod adı + roster kimliği
      tx.set(ctx.ref.intelChat(channel).doc(), { rosterId: rid, codeName: me.codeName, rank: me.rank, text, createdAtMs: ctx.now });
      tx.update(ctx.ref.roster(rid), { lastChatAtMs: ctx.now });
      return { sent: true };
    });
  }

  // ---------------------------------------------------------------------------
  // İHBAR — İstihbarat üyesi, kendi çetesinde Tetikçi+ ise seferdeki tırı
  // ihbar edebilir. Bir tır (sefer) yalnızca BİR kez ihbar edilir.
  // ---------------------------------------------------------------------------
  async function reportTruck(ctx, data) {
    const truckId = String(data.truckId || '');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      if (!membership.gangId) fail('failed-precondition', 'Bir çetede değilsin.');
      const [meSnap, rosterSnap, truckSnap] = await Promise.all([
        tx.get(ctx.ref.member(membership.gangId, ctx.actorId)),
        tx.get(ctx.ref.roster(rid)),
        tx.get(ctx.ref.truck(truckId)),
      ]);
      const truck = truckSnap.data();
      if (!truck || truck.gangId !== membership.gangId) fail('permission-denied', 'Bu tırı göremezsin.');
      if (!atLeast(core.effRank(meSnap.data(), ctx), 'tetikci')) fail('permission-denied', 'Tırları görmek için en az Tetikçi olmalısın.');
      if (truck.status !== 'in_transit') fail('failed-precondition', 'Sadece seferdeki tırlar ihbar edilebilir.');
      // v67: ihbar, tır yola çıktıktan sonraki 6 saat içinde (sonra saldırı başlar)
      const { departAtMs, attackAtMs } = truckTimes(truck);
      if (truck.departDateKey !== ctx.dateKey || ctx.now >= attackAtMs) fail('deadline-exceeded', 'Tır ihbarı, tır yola çıktıktan sonraki 6 saat içinde yapılabilir.');
      const reportId = `${truckId}_${truck.departDateKey}`;
      const repSnap = await tx.get(ctx.ref.intelReport(reportId));
      if (repSnap.exists) fail('already-exists', 'Bu tır zaten ihbar edildi.');
      const gang = (await tx.get(ctx.ref.gang(membership.gangId))).data();
      tx.set(ctx.ref.intelReport(reportId), {
        truckId,
        truckCode: truck.code,
        gangId: truck.gangId,
        gangName: gang?.name || truck.gangName,
        gangLogo: gang?.logo || null,
        departDateKey: truck.departDateKey,
        departAtMs,
        attackAtMs,
        reportedByCode: rosterSnap.data().codeName,
        reportedAtMs: ctx.now,
        leaked: false,
        opWarId: null,
      });
      tx.update(ctx.ref.roster(rid), { prestige: FV.increment(INTEL.REPORT_PRESTIGE) });
      announceIntel(tx, ctx, '📡', `${rosterSnap.data().codeName}, TIR #${truck.code} (${gang?.name || ''}) tırını ihbar etti.`);
      ctx.logs.push({ gang: 'intel_report', world: ctx.worldId, reportId });
      return { reportId, prestige: INTEL.REPORT_PRESTIGE };
    });
  }

  // İÇERİK SIZDIRMA — Kıdemli+ ; ihbar edilmiş tırın yükünü bir kez sızdırır.
  async function leakTruck(ctx, data) {
    const reportId = String(data.reportId || '');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const repSnap = await tx.get(ctx.ref.intelReport(reportId));
      if (!repSnap.exists) fail('failed-precondition', 'Önce tır ihbar edilmeli.');
      const rep = repSnap.data();
      if (membership.gangId !== rep.gangId) fail('permission-denied', 'Bu tırın içeriğini göremezsin.');
      if (rep.departDateKey !== ctx.dateKey || ctx.now >= truckTimes(rep).attackAtMs) fail('deadline-exceeded', 'İçerik, tır yola çıktıktan sonraki 6 saat içinde sızdırılabilir.');
      const [meSnap, rosterSnap, cargoSnap, truckSnap] = await Promise.all([
        tx.get(ctx.ref.member(rep.gangId, ctx.actorId)),
        tx.get(ctx.ref.roster(rid)),
        tx.get(ctx.ref.cargo(rep.truckId)),
        tx.get(ctx.ref.truck(rep.truckId)),
      ]);
      if (!atLeast(core.effRank(meSnap.data(), ctx), 'kidemli')) fail('permission-denied', 'Tır içeriğini görmek için en az Kıdemli olmalısın.');
      if (rep.leaked) fail('already-exists', 'Bu tırın içeriği zaten sızdırıldı.');
      if (truckSnap.data()?.status !== 'in_transit' || truckSnap.data()?.departDateKey !== rep.departDateKey) fail('failed-precondition', 'Bu sefer bitti.');
      const items = cargoSnap.data()?.items || {};
      const estReward = core.instantValueOf(items);
      const opSnap = rep.opWarId ? await tx.get(ctx.ref.war(rep.opWarId)) : null;
      // İçerik adetleri İstihbarata gösterilmez — sadece ödül değeri.
      tx.update(ctx.ref.intelReport(reportId), {
        leaked: true,
        estReward,
        leakedByCode: rosterSnap.data().codeName,
        leakedAtMs: ctx.now,
      });
      if (opSnap?.exists) tx.update(opSnap.ref, { estReward });
      tx.update(ctx.ref.roster(rid), { prestige: FV.increment(INTEL.LEAK_PRESTIGE) });
      announceIntel(tx, ctx, '📦', `${rosterSnap.data().codeName}, TIR #${rep.truckCode} içeriğini sızdırdı — ödül değeri ${estReward.toLocaleString('tr-TR')}.`);
      ctx.logs.push({ gang: 'intel_leak', world: ctx.worldId, reportId });
      return { leaked: true, estReward, prestige: INTEL.LEAK_PRESTIGE };
    });
  }

  // ---------------------------------------------------------------------------
  // v33 — BAHİSLİ SAVAŞA MÜDAHALE
  //  Bahis kabul edildikten sonra, savaş başlamadan (o gecenin 00:00'ından)
  //  önce:
  //   - İHBAR: iki çeteden birinde en az Tetikçi olan İstihbarat üyesi
  //     (+1M). İstihbarat bahsi görür ama TUTARI göremez.
  //   - İÇERİĞİ AÇMA: iki çeteden birinde en az Kıdemli olan İstihbarat
  //     üyesi (+1M). İstihbarat toplam bahsi (havuzu) görür.
  //   - OPERASYON: Başkan/Şef, İstihbarat kasasından 100.000 ile başlatır
  //     (tutar görülmeden de başlatılabilir). Savaş 00:00'da 3 taraflı
  //     başlar; en güçlü taraf havuzun tamamını alır.
  //  00:00'dan sonra İstihbarat müdahale edemez. Çeteler müdahaleyi savaş
  //  başlarken (00:00) öğrenir.
  // ---------------------------------------------------------------------------
  // v35: bahis kabul edildikten sonra İLK SALDIRI DİLİMİNİN SONUNA kadar
  // (başlangıç + 6 saat = ilk 2 dilim) müdahale edilebilir; sonrası çetelerin arasında.
  async function readBetForIntel(tx, ctx, warId) {
    const war = (await tx.get(ctx.ref.war(warId))).data();
    if (!war || war.type !== 'bet') fail('not-found', 'Bahis bulunamadı.');
    const deadline = Number(war.startsAtMs || 0) + GANG.BET_INTEL_WINDOW_MS;
    if (!['accepted', 'active'].includes(war.status) || ctx.now >= deadline) fail('failed-precondition', 'Bu bahse artık müdahale edilemez (ilk saldırı dilimi bitti).');
    return war;
  }

  async function reportBet(ctx, data) {
    const warId = String(data.warId || '');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const war = await readBetForIntel(tx, ctx, warId);
      if (!membership.gangId || !war.gangIds.includes(membership.gangId)) fail('permission-denied', 'Bu bahis senin çetenin değil.');
      const [meSnap, rosterSnap, repSnap] = await Promise.all([
        tx.get(ctx.ref.member(membership.gangId, ctx.actorId)),
        tx.get(ctx.ref.roster(rid)),
        tx.get(ctx.ref.betReport(warId)),
      ]);
      if (!atLeast(core.effRank(meSnap.data(), ctx), 'tetikci')) fail('permission-denied', 'Bahsi ihbar etmek için çetende en az Tetikçi olmalısın.');
      if (repSnap.exists) fail('already-exists', 'Bu bahis zaten ihbar edildi.');
      const [a, b] = war.gangIds;
      tx.set(ctx.ref.betReport(warId), {
        warId,
        gangIds: war.gangIds,
        names: { [a]: war.sides?.[a]?.name || '', [b]: war.sides?.[b]?.name || '' },
        logos: { [a]: war.sides?.[a]?.logo || null, [b]: war.sides?.[b]?.logo || null },
        dateKey: war.dateKey,
        startsAtMs: war.startsAtMs,
        intelDeadlineMs: Number(war.startsAtMs || 0) + GANG.BET_INTEL_WINDOW_MS,
        reportedByCode: rosterSnap.data().codeName,
        reportedAtMs: ctx.now,
        leaked: false,
        pot: null,
        opStarted: false,
      });
      tx.update(ctx.ref.roster(rid), { prestige: FV.increment(INTEL.BET_REPORT_PRESTIGE) });
      announceIntel(tx, ctx, '🎲', `${rosterSnap.data().codeName}, ${war.sides?.[a]?.name} ⚔️ ${war.sides?.[b]?.name} bahisli savaşını ihbar etti.`);
      ctx.logs.push({ gang: 'intel_bet_report', world: ctx.worldId, warId });
      return { reported: true, prestige: INTEL.BET_REPORT_PRESTIGE };
    });
  }

  async function leakBet(ctx, data) {
    const warId = String(data.warId || '');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const war = await readBetForIntel(tx, ctx, warId);
      if (!membership.gangId || !war.gangIds.includes(membership.gangId)) fail('permission-denied', 'Bu bahis senin çetenin değil.');
      const [meSnap, rosterSnap, repSnap, stake] = await Promise.all([
        tx.get(ctx.ref.member(membership.gangId, ctx.actorId)),
        tx.get(ctx.ref.roster(rid)),
        tx.get(ctx.ref.betReport(warId)),
        core.readBetStake(tx, ctx, warId, war),
      ]);
      if (!repSnap.exists) fail('failed-precondition', 'Önce bahis ihbar edilmeli.');
      if (!atLeast(core.effRank(meSnap.data(), ctx), 'kidemli')) fail('permission-denied', 'Bahsin içeriğini açmak için çetende en az Kıdemli olmalısın.');
      if (repSnap.data().leaked) fail('already-exists', 'Bu bahsin içeriği zaten açıldı.');
      const pot = stake * 2;
      tx.update(ctx.ref.betReport(warId), { leaked: true, pot, leakedByCode: rosterSnap.data().codeName, leakedAtMs: ctx.now });
      tx.update(ctx.ref.roster(rid), { prestige: FV.increment(INTEL.BET_LEAK_PRESTIGE) });
      announceIntel(tx, ctx, '📦', `${rosterSnap.data().codeName} bahsin içeriğini açtı — toplam bahis ${pot.toLocaleString('tr-TR')}.`);
      return { leaked: true, pot, prestige: INTEL.BET_LEAK_PRESTIGE };
    });
  }

  async function startBetOperation(ctx, data) {
    const warId = String(data.warId || '');
    return core.db.runTransaction(async (tx) => {
      const guard = await core.requestGuard(tx, ctx, data.requestId);
      if (guard.done) return guard.result;
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const war = await readBetForIntel(tx, ctx, warId);
      const [me, repSnap, stSnap] = await Promise.all([tx.get(ctx.ref.roster(rid)), tx.get(ctx.ref.betReport(warId)), tx.get(ctx.ref.intelState())]);
      if (!['baskan', 'sef'].includes(core.effRank(me.data(), ctx, 'muhbir'))) fail('permission-denied', 'Operasyonu sadece Başkan ve Şefler başlatabilir.');
      if (!repSnap.exists) fail('failed-precondition', 'Önce bahis ihbar edilmeli.');
      if (repSnap.data().opStarted) fail('already-exists', 'Bu bahse zaten operasyon var.');
      const price = INTEL.BET_OP_PRICE;
      const state = stSnap.data() || {};
      if (Number(state.kasa || 0) < price) fail('failed-precondition', `Operasyon ücreti ${price.toLocaleString('tr-TR')} — İstihbarat kasasında yeterli para yok.`);
      tx.update(ctx.ref.intelState(), { kasa: FV.increment(-price) });
      tx.update(ctx.ref.betReport(warId), { opStarted: true, opByCode: me.data().codeName, opAtMs: ctx.now, opCost: price });
      core.ledger(tx, ctx, { type: 'intel_bet_op_cost', amount: price, from: { kind: 'intel', id: 'main' }, to: { kind: 'burn' }, before: state.kasa, refId: warId });
      const [a, b] = war.gangIds;
      const started = ctx.now >= Number(war.startsAtMs || 0);
      if (started && !war.sides?.intel) {
        // Savaş zaten başladıysa İstihbarat hemen 3. taraf olur; çeteler şimdi öğrenir.
        tx.update(ctx.ref.war(warId), { 'sides.intel': { orgType: 'intel', orgId: 'main', name: INTEL.NAME, logo: INTEL.LOGO, role: 'intel' }, intelInvolved: true });
        for (const g of [a, b]) core.announce(tx, ctx, g, '🕵️', `İstihbarat ${war.sides?.[a]?.name} ⚔️ ${war.sides?.[b]?.name} bahisli savaşına dahil oldu! Artık 3 taraf var — en güçlü taraf tüm bahsi alır.`);
      }
      announceIntel(tx, ctx, '🎯', `${me.data().codeName}, ${war.sides?.[a]?.name} ⚔️ ${war.sides?.[b]?.name} bahsine operasyon başlattı (${price.toLocaleString('tr-TR')}). ${started ? 'Savaşa hemen katılabiliriz.' : 'Savaş başlayınca 3 taraflı olur.'}`);
      ctx.logs.push({ gang: 'intel_bet_op', world: ctx.worldId, warId });
      const res = { started: true, price };
      guard.save(res);
      return res;
    });
  }

  // ---------------------------------------------------------------------------
  // KARAR PANELİ — İstihbarat üyesi Mafya Babası olduysa sonraki 00:00'a kadar:
  //  'disband' → çete dağıtılır (tüm üyeler atılır), çökertme prestiji
  //  'stay'    → İstihbarattan (sessizce) ayrılır, Baba olarak devam
  // Karar verilmezse 00:00'da 'stay' uygulanır (bkz. clock).
  // ---------------------------------------------------------------------------
  async function intelDecision(ctx, data) {
    const choice = data.choice;
    if (!['disband', 'stay'].includes(choice)) fail('invalid-argument', 'Geçersiz seçim.');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      if (!membership.gangId || membership.intelDecisionGangId !== membership.gangId) fail('failed-precondition', 'Bekleyen bir karar yok.');
      if (membership.intelDecisionDeadline && ctx.dateKey >= membership.intelDecisionDeadline) fail('deadline-exceeded', 'Karar süresi doldu.');
      const gangId = membership.gangId;
      const [gangSnap, meSnap, rosterSnap] = await Promise.all([tx.get(ctx.ref.gang(gangId)), tx.get(ctx.ref.member(gangId, ctx.actorId)), tx.get(ctx.ref.roster(rid))]);
      if (meSnap.data()?.rank !== 'baba' || gangSnap.data()?.status !== 'active') fail('failed-precondition', 'Artık Mafya Babası değilsin.');
      if (choice === 'stay') {
        const plan = { rosterId: rid, roster: rosterSnap.data(), actorId: ctx.actorId, membership };
        applyIntelLeave(tx, ctx, plan);
        return { choice };
      }
      const gang = gangSnap.data();
      tx.update(ctx.ref.gang(gangId), { status: 'disbanded', dissolvedReason: 'intel_takedown', dissolvedAtMs: ctx.now, cleanupDone: false });
      if (gang.nameKey) tx.delete(ctx.ref.gangName(gang.nameKey));
      tx.update(ctx.ref.roster(rid), { prestige: FV.increment(INTEL.TAKEDOWN_PRESTIGE) });
      tx.set(ctx.ref.membership(ctx.actorId), { intelDecisionGangId: null, intelDecisionDeadline: null }, { merge: true });
      // v40: kimin teslim ettiği kimseye söylenmez (kod adı dahil) — sadece çetenin çökertildiği duyurulur
      announceIntel(tx, ctx, '💥', `${gang.name} çetesi çökertildi ve İstihbarata teslim edildi! Çetenin kasası İstihbarat kasasına geçiyor.`);
      ctx.logs.push({ gang: 'intel_takedown', world: ctx.worldId, gangId });
      ctx.afterCommit.push(() => core.cleanupGang(ctx, gangId));
      return { choice, gangId };
    });
  }

  // ---------------------------------------------------------------------------
  // Polis kancası: İstihbarat üyesi bir polis suçlu yakalayıp ödül aldığında
  // aldığı miktar kadar İstihbarat prestiji kazanır (idempotent: refId).
  // Sadece canlı dünya; oyuncunun kendi suçları dahil değildir (bu kanca
  // sadece polis yakalama ödülünde çağrılır).
  // ---------------------------------------------------------------------------
  async function awardPoliceReward(ctx, actorId, amount, refId) {
    if (!(amount > 0)) return { skipped: true };
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, actorId);
      if (!membership.intelRosterId) return { skipped: true };
      const markRef = ctx.ref.request(`police_${actorId}_${String(refId).replace(/[^a-zA-Z0-9-]/g, '').slice(0, 80)}`);
      const [mark, roster] = await Promise.all([tx.get(markRef), tx.get(ctx.ref.roster(membership.intelRosterId))]);
      if (mark.exists || !roster.exists) return { skipped: true };
      const prestige = Math.floor(amount * INTEL.POLICE_REWARD_PRESTIGE_PER_GOLD);
      tx.update(ctx.ref.roster(membership.intelRosterId), { prestige: FV.increment(prestige) });
      tx.set(markRef, { atMs: ctx.now, prestige });
      ctx.logs.push({ gang: 'prestige', world: ctx.worldId, event: 'police_reward', amount: prestige });
      return { prestige };
    });
  }

  // ---------------------------------------------------------------------------
  // İSTİHBARAT ATMA SİSTEMİ (devirme/ayaklanma YOK)
  //  - Anında: Başkan → Ajan / Muhbir; Şef → Muhbir.
  //  - Oylama: Başkan ve Şef doğrudan atamadıkları herkes için (Şef, Başkan'ı
  //    da oylamaya götürebilir); Uzman, Başkan hariç herkes için.
  //  - Başkan için > %66, diğerleri için ≥ %51 evet gerekir. Başarısız
  //    oylamada hiçbir şey değişmez. Atılanın yeri 00:00'da dolar (rütbe).
  //  - Talep 00:00'a kadar gizli/iptal edilebilir; oylama 00:00'da başlar,
  //    24 saat sürer; oy hakkı o anki Başkan + Şefler + Uzmanlar (snapshot).
  // ---------------------------------------------------------------------------
  const DIRECT_KICK = { baskan: ['ajan', 'muhbir'], sef: ['muhbir'] };
  function intelKickVoteAllowed(initRank, targetRank) {
    if (!targetRank) return false;
    if (initRank === 'baskan' || initRank === 'sef') return !(DIRECT_KICK[initRank] || []).includes(targetRank);
    if (initRank === 'uzman') return targetRank !== 'baskan';
    return false;
  }
  function intelVoteOutcome(vote) {
    const yes = Number(vote.yes || 0);
    const no = Number(vote.no || 0);
    const total = yes + no;
    const ratio = total > 0 ? yes / total : 0;
    const passed = total > 0 && (vote.targetWasBaskan ? ratio > INTEL.KICK_BASKAN_MIN_RATIO_EXCLUSIVE : ratio >= INTEL.KICK_MIN_RATIO);
    return { passed, ratio };
  }

  async function removeFromIntel(tx, ctx, rosterId, roster, reasonText) {
    const link = await tx.get(linkRef(ctx, rosterId));
    const actorId = link.data()?.actorId || null;
    const ms = actorId ? await readMembership(tx, ctx, actorId) : null;
    return () => {
      if (!actorId || !ms || ms.intelRosterId !== rosterId) {
        // bağlantı yoksa sadece roster temizliği
        tx.delete(ctx.ref.roster(rosterId));
        tx.delete(linkRef(ctx, rosterId));
        if (roster?.codeName) tx.delete(ctx.ref.codeName(core.nameKeyOf(roster.codeName)));
        tx.set(ctx.ref.intel(), { memberCount: FV.increment(-1) }, { merge: true });
        return;
      }
      applyIntelLeave(tx, ctx, { rosterId, roster, actorId, membership: ms }, { actorId });
      notify(tx, ctx, actorId, reasonText, 'intel');
    };
  }

  // v61 — istismar önlemi: az üyeyle (≤7) kimse atılamaz; yeni katılan üye
  // katıldığı günün 00:00'ına kadar atılamaz (ör. 23:00'te giren 00:00'dan sonra).
  function kickBlockReason(ctx, rosterSize, target) {
    if (rosterSize < INTEL.KICK_MIN_MEMBERS) return `İstihbaratta ${INTEL.KICK_MIN_MEMBERS - 1} ya da daha az üye varken kimse çıkarılamaz.`;
    if (target && Number(target.joinedAtMs || 0) > 0 && dateKeyOf(Number(target.joinedAtMs)) === ctx.dateKey) return "Yeni katılan üye 00:00'a kadar çıkarılamaz.";
    return null;
  }

  async function kickIntelMember(ctx, data) {
    const targetRosterId = String(data.targetRosterId || '');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      if (!targetRosterId || targetRosterId === rid) fail('invalid-argument', 'Geçersiz üye.');
      const [me, target, rosterSnap] = await Promise.all([tx.get(ctx.ref.roster(rid)), tx.get(ctx.ref.roster(targetRosterId)), tx.get(ctx.ref.rosterCol())]);
      if (!target.exists) fail('failed-precondition', 'Bu ajan artık İstihbaratta değil.');
      if (!(DIRECT_KICK[core.effRank(me.data(), ctx, 'muhbir')] || []).includes(target.data().rank)) fail('permission-denied', 'Bu üyeyi doğrudan atamazsın (oylama gerekir).');
      const blocked = kickBlockReason(ctx, rosterSnap.size, target.data());
      if (blocked) fail('failed-precondition', blocked);
      const apply = await removeFromIntel(tx, ctx, targetRosterId, target.data(), '🚫 İstihbarattan çıkarıldın. İstihbarat prestijin silindi.');
      apply();
      announceIntel(tx, ctx, '🚫', `${target.data().codeName}, ${me.data().codeName} tarafından İstihbarattan çıkarıldı.`);
      return { kicked: true };
    });
  }

  // v33: oylama 00:00–12:00 arasında başlatılır, ANINDA başlar, o gecenin
  // 00:00'ında biter. Oy hakkı başladığı andaki Başkan + Şefler + Uzmanlar.
  async function requestIntelKickVote(ctx, data) {
    const targetRosterId = String(data.targetRosterId || '');
    if (ctx.hour >= GANG.VOTE_START_DEADLINE_HOUR) fail('deadline-exceeded', 'Oylama sadece 00:00–12:00 arasında başlatılabilir.');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      if (!targetRosterId || targetRosterId === rid) fail('invalid-argument', 'Geçersiz hedef.');
      const lockRef = ctx.ref.intelVoteLock(targetRosterId.replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80));
      const [me, target, act, rosterSnap, lockSnap] = await Promise.all([
        tx.get(ctx.ref.roster(rid)),
        tx.get(ctx.ref.roster(targetRosterId)),
        tx.get(ctx.ref.intelVotes().where('status', '==', 'active')),
        tx.get(ctx.ref.rosterCol()),
        tx.get(lockRef),
      ]);
      if (!target.exists) fail('failed-precondition', 'Bu ajan artık İstihbaratta değil.');
      if (!intelKickVoteAllowed(core.effRank(me.data(), ctx, 'muhbir'), target.data().rank)) fail('permission-denied', 'Bu üye için çıkarma oylaması başlatamazsın.');
      const blocked = kickBlockReason(ctx, rosterSnap.size, target.data());
      if (blocked) fail('failed-precondition', blocked);
      if (act.docs.some((d) => d.data().targetRosterId === targetRosterId)) fail('already-exists', 'Bu üye için zaten bir oylama var.');
      if (lockSnap.exists && Number(lockSnap.data().endsAtMs || 0) > ctx.now) {
        const lv = (await tx.get(ctx.ref.intelVotes().doc(lockSnap.data().voteId))).data();
        if (lv?.status === 'active') fail('already-exists', 'Bu üye için zaten bir oylama var.');
      }
      const voters = rosterSnap.docs.filter((d) => ['baskan', 'sef', 'uzman'].includes(d.data().rank)).map((d) => d.id);
      const endsAtMs = midnightMsOf(addDays(ctx.dateKey, 1));
      const vRef = ctx.ref.intelVotes().doc();
      tx.set(vRef, {
        type: 'kick',
        status: 'active',
        initiatorCode: me.data().codeName,
        targetRosterId,
        targetCode: target.data().codeName,
        targetWasBaskan: target.data().rank === 'baskan',
        voterIds: voters,
        yes: 0,
        no: 0,
        votedCount: 0,
        startsAtMs: ctx.now,
        endsAtMs,
      });
      tx.set(lockRef, { voteId: vRef.id, endsAtMs });
      // v39: hedef oylama bitene kadar Muhbir yetkisinde
      tx.update(ctx.ref.roster(targetRosterId), { underVoteUntilMs: Math.max(Number(target.data().underVoteUntilMs || 0), endsAtMs) });
      return { voteId: vRef.id };
    });
  }

  async function cancelIntelVoteRequest(ctx, data) {
    const pendingId = String(data.pendingId || '');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const ref = ctx.ref.intelPending().doc(pendingId);
      const p = (await tx.get(ref)).data();
      if (!p || p.initiatorRosterId !== rid) fail('not-found', 'Talep bulunamadı.');
      if (p.status !== 'pending') fail('failed-precondition', 'Bu talep artık iptal edilemez.');
      tx.update(ref, { status: 'cancelled', cancelReason: 'by_initiator' });
      return { cancelled: true };
    });
  }

  async function castIntelVote(ctx, data) {
    const voteId = String(data.voteId || '');
    const choice = data.choice === 'yes' ? 'yes' : data.choice === 'no' ? 'no' : null;
    if (!choice) fail('invalid-argument', 'Geçersiz oy.');
    return core.db.runTransaction(async (tx) => {
      const membership = await readMembership(tx, ctx, ctx.actorId);
      const rid = requireIntel(membership);
      const voteRef = ctx.ref.intelVotes().doc(voteId);
      const [voteSnap, ballotSnap] = await Promise.all([tx.get(voteRef), tx.get(ctx.ref.intelBallot(voteId, rid))]);
      const vote = voteSnap.data();
      if (!vote) fail('not-found', 'Oylama bulunamadı.');
      if (vote.status !== 'active' || ctx.now >= vote.endsAtMs) fail('deadline-exceeded', 'Oylama kapandı.');
      if (!(vote.voterIds || []).includes(rid)) fail('permission-denied', 'Bu oylamada oy hakkın yok.');
      if (ballotSnap.exists) fail('already-exists', 'Oyunu zaten kullandın.');
      tx.set(ctx.ref.intelBallot(voteId, rid), { choice, atMs: ctx.now });
      tx.update(voteRef, { [choice]: FV.increment(1), votedCount: FV.increment(1) });
      // v52: bu oyla sonuç kesinleştiyse oylama hemen sonuçlandırılır (bkz. system.js)
      const after = { ...vote, [choice]: Number(vote[choice] || 0) + 1, votedCount: Number(vote.votedCount || 0) + 1 };
      return { voted: true, voteId, decided: Boolean(decidedOutcome(after, intelVoteOutcome)) };
    });
  }

  // Tek bir İstihbarat oylamasını sonuçlandırır. early=true → süre dolmadan,
  // sonuç KESİNLEŞTİĞİ için (v52); kesinlik işlem içinde yeniden doğrulanır.
  function resolveOneIntelVote(ctx, ref, { early = false } = {}) {
    return core.db.runTransaction(async (tx) => {
          const d = { ref };
          const vote = (await tx.get(d.ref)).data();
          if (!vote || vote.status !== 'active') return { skipped: true };
          const endedEarly = vote.endsAtMs > ctx.now;
          if (endedEarly && !(early && decidedOutcome(vote, intelVoteOutcome))) return { skipped: true };
          const [target, rosterSnap] = await Promise.all([tx.get(ctx.ref.roster(vote.targetRosterId)), tx.get(ctx.ref.rosterCol())]);
          const { passed, ratio } = intelVoteOutcome(vote);
          const pct = `%${Math.round(ratio * 100)}${endedEarly ? ' · sonuç kesinleşti, oylama erken bitti' : ''}`;
          const result = { passed, ratio, yes: vote.yes || 0, no: vote.no || 0, endedEarly };
          if (!target.exists) {
            tx.update(d.ref, { status: 'cancelled', cancelReason: 'member_left', resolvedAtMs: ctx.now, result });
            return { cancelled: true };
          }
          // v61: sonuçlanma anında üye sayısı 7 ya da altına düştüyse çıkarma uygulanmaz
          if (passed && rosterSnap.size < INTEL.KICK_MIN_MEMBERS) {
            tx.update(d.ref, { status: 'cancelled', cancelReason: 'min_members', resolvedAtMs: ctx.now, result });
            if (Number(target.data().underVoteUntilMs || 0) > ctx.now) tx.update(ctx.ref.roster(vote.targetRosterId), { underVoteUntilMs: 0 });
            announceIntel(tx, ctx, '🗳️', `${vote.targetCode} için çıkarma oylaması geçti ama İstihbaratta ${INTEL.KICK_MIN_MEMBERS - 1} ya da daha az üye kaldığı için uygulanmadı.`);
            return { cancelled: true, reason: 'min_members' };
          }
          let apply = null;
          if (passed) apply = await removeFromIntel(tx, ctx, vote.targetRosterId, target.data(), `🗳️ Oylama sonucu İstihbarattan çıkarıldın (${pct}).`);
          tx.update(d.ref, { status: 'resolved', resolvedAtMs: ctx.now, result });
          if (apply) apply();
          // v52: erken bittiyse ve hedef kaldıysa "oylama altında (Muhbir yetkisi)" durumu biter
          else if (endedEarly && Number(target.data().underVoteUntilMs || 0) > ctx.now) tx.update(ctx.ref.roster(vote.targetRosterId), { underVoteUntilMs: 0 });
          announceIntel(tx, ctx, '🗳️', passed ? `${vote.targetCode} oylamayla İstihbarattan çıkarıldı (${pct}).` : `${vote.targetCode} için çıkarma oylaması reddedildi (${pct}).`);
          return { resolved: true, passed };
    });
  }

  // 00:00: biten oylamalar sonuçlanır, bekleyen talepler (geçerliyse) başlar.
  async function resolveIntelVotes(ctx, safe) {
    const act = await ctx.ref.intelVotes().where('status', '==', 'active').get();
    for (const d of act.docs) {
      if (d.data().endsAtMs > ctx.now) continue;
      await safe(ctx, `intel-vote:${d.id}`, () => resolveOneIntelVote(ctx, d.ref));
    }
  }

  // v52: oy verildiği anda sonuç kesinleştiyse hemen sonuçlandır + kod adı listesini yenile
  async function resolveIntelVoteEarly(ctx, voteId) {
    const res = await resolveOneIntelVote(ctx, ctx.ref.intelVotes().doc(voteId), { early: true });
    if (!res?.skipped) await core.refreshIntelRoster(ctx);
    return res;
  }

  async function startIntelPendingVotes(ctx) {
    return core.db.runTransaction(async (tx) => {
        const [pendSnap, rosterSnap, actSnap] = await Promise.all([
          tx.get(ctx.ref.intelPending().where('status', '==', 'pending')),
          tx.get(ctx.ref.rosterCol()),
          tx.get(ctx.ref.intelVotes().where('status', '==', 'active')),
        ]);
        const roster = new Map(rosterSnap.docs.map((d) => [d.id, d.data()]));
        const voters = [...roster.entries()].filter(([, r]) => ['baskan', 'sef', 'uzman'].includes(r.rank)).map(([id]) => id);
        const pend = pendSnap.docs.map((d) => ({ ref: d.ref, ...d.data() })).filter((p) => p.requestedAtMs < ctx.now);
        pend.sort((a, b) => a.requestedAtMs - b.requestedAtMs);
        const started = new Set(actSnap.docs.map((d) => d.data().targetRosterId));
        for (const p of pend) {
          const ini = roster.get(p.initiatorRosterId);
          const tgt = roster.get(p.targetRosterId);
          if (!ini || !tgt || started.has(p.targetRosterId) || !intelKickVoteAllowed(ini.rank, tgt.rank) || kickBlockReason(ctx, roster.size, tgt)) {
            tx.update(p.ref, { status: 'cancelled', cancelReason: 'invalid_at_midnight' });
            continue;
          }
          started.add(p.targetRosterId);
          const vRef = ctx.ref.intelVotes().doc();
          tx.set(vRef, {
            type: 'kick',
            status: 'active',
            initiatorCode: ini.codeName,
            targetRosterId: p.targetRosterId,
            targetCode: tgt.codeName,
            targetWasBaskan: tgt.rank === 'baskan',
            voterIds: voters,
            yes: 0,
            no: 0,
            votedCount: 0,
            startsAtMs: ctx.now,
            endsAtMs: ctx.now + 24 * 3600_000,
          });
          tx.update(p.ref, { status: 'started', voteId: vRef.id });
          tx.update(ctx.ref.roster(p.targetRosterId), { underVoteUntilMs: ctx.now + 24 * 3600_000 }); // v39
        }
    });
  }

  // Şüpheyle yakalanma cezası → İstihbarat kasası (idempotent: refId)
  // v50: cezanın yalnızca INTEL.SUSPICION_FINE_KASA_RATIO kadarı (yarısı)
  // kasaya girer; kalanı yakılır — hiçbir yere yazılmaz, sadece iz için
  // işaret kaydında (burned) tutulur. amount = oyuncuya yazılan TAM ceza.
  async function creditFineToIntel(ctx, amount, refId) {
    const credited = Math.floor(amount * INTEL.SUSPICION_FINE_KASA_RATIO);
    const burned = amount - credited;
    return core.db.runTransaction(async (tx) => {
      const markRef = ctx.ref.request(`fine_${String(refId).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 100)}`);
      const [mark, info] = await Promise.all([tx.get(markRef), core.readIntelKasa(tx, ctx)]);
      if (mark.exists) return { skipped: true };
      // v88: kasa sınırı — sınırı aşan kısım da yanar
      const r = credited > 0 ? core.creditIntel(tx, ctx, info, credited, { type: 'intel_fine_income', refId: String(refId).slice(0, 100) }) : { credited: 0, burned: 0 };
      tx.set(markRef, { atMs: ctx.now, amount, credited: r.credited, burned: burned + r.burned });
      if (r.credited > 0) intelLog(tx, ctx, '🚓', `Şüpheyle yakalanan bir suçlunun cezasının yarısı kasaya girdi: +${r.credited.toLocaleString('tr-TR')}`);
      return { credited: r.credited, burned: burned + r.burned };
    });
  }

  return {
    creditFineToIntel,
    planIntelLeave,
    applyIntelLeave,
    joinIntel,
    leaveIntel,
    changeCodeName,
    kickIntelMember,
    requestIntelKickVote,
    cancelIntelVoteRequest,
    castIntelVote,
    intelKickVoteAllowed,
    intelVoteOutcome,
    updateIntelNote,
    sendIntelChat,
    reportTruck,
    leakTruck,
    reportBet,
    leakBet,
    startBetOperation,
    intelDecision,
    awardPoliceReward,
    intelDefaults,
    intelStateDefaults,
    resolveIntelVotes,
    resolveIntelVoteEarly,
    startIntelPendingVotes,
    linkRef,
  };
}
