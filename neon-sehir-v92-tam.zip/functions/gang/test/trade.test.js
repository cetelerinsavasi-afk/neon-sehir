import test from 'node:test';
import assert from 'node:assert/strict';
import { createHarness, setupGang, ist } from './harness.js';

// Harness başlangıcı: 2026-09-21 Pazartesi 09:00 (İstanbul)
// v67 zaman çizelgesi: sipariş Pzt–Cmt 00:00–12:00 → sonraki 3 saatlik dilimde
// (03·06·09·12) yola çıkar → 6 saat ihbar/sabotaj/operasyon → saldırı → 00:00 teslim.

async function setupTradeGang(h, name = 'Alfa', { depot = 1000 } = {}) {
  const G = await setupGang(h, { members: 4, name });
  // prestijler 00:00 rütbe hesabıyla tutarlı: ids0 & ids3 Sağ Kol, ids1 & ids2 Kıdemli
  const plan = [
    [0, 5_000_000, 'sagkol'],
    [3, 4_000_000, 'sagkol'],
    [1, 2_000_000, 'kidemli'],
    [2, 1_000_000, 'kidemli'],
  ];
  for (const [i, p, r] of plan) {
    await h.setPrestige(G.gangId, G.ids[i], p);
    await h.setRank(G.gangId, G.ids[i], r);
  }
  await h.fundKasa(G.gangId, 5_000_000);
  if (depot) await h.giveDepot(G.gangId, depot);
  return G;
}

const depotOf = (h, gangId) => h.get(`gangs/${gangId}/private/depot`);
// v39: günde 1 tır sınırı — farklı günlerde alınmış gibi kurulum için bayrağı temizle
async function buyTruckAnyDay(h, gangId, uid, payload = {}) {
  await h.db.doc(`gangWorlds/test/gangs/${gangId}/private/state`).set({ truckBuyDateKey: null }, { merge: true });
  return h.act(uid, 'buyTruck', payload);
}

test('tır: 100.000 altın, sadece Baba/Sağ Kol; 4 haneli benzersiz kimlik; ömür 21 gün; v39: günde en fazla 1 tır', async () => {
  const h = await createHarness();
  const G = await setupTradeGang(h);
  await h.fails(G.ids[1], 'buyTruck');
  const rs = await Promise.allSettled([1, 2, 3, 4, 5, 6].map((i) => h.act(i % 2 ? G.baba : G.ids[0], 'buyTruck', { requestId: `t${i}` })));
  const ok = rs.filter((r) => r.status === 'fulfilled').map((r) => r.value);
  assert.equal(ok.length, 1, 'aynı gün tek tır (eşzamanlı istek dahil)');
  assert.match(rs.find((r) => r.status === 'rejected').reason.message, /Bugün zaten tır/);
  assert.match(ok[0].code, /^\d{4}$/);
  assert.equal(h.state(G.gangId).kasa, 5_000_000 - 100_000);
  const t = h.get(`trucks/${ok[0].truckId}`);
  assert.equal(t.boughtDateKey, '2026-09-21');
  assert.equal(t.expiresDateKey, '2026-10-12');
  await h.nextDay();
  const second = await h.act(G.baba, 'buyTruck');
  assert.notEqual(second.code, ok[0].code);
});
test('depo: 100.000 = +100 kapasite, her alımda genişler; sadece Baba/Sağ Kol; v39: günde en fazla 1', async () => {
  const h = await createHarness();
  const G = await setupTradeGang(h, 'Alfa', { depot: 0 });
  await h.fails(G.ids[1], 'buyDepot');
  await h.act(G.baba, 'buyDepot');
  assert.match((await h.fails(G.ids[0], 'buyDepot')).message, /Bugün zaten depo/);
  await h.nextDay();
  await h.act(G.ids[0], 'buyDepot');
  assert.equal(depotOf(h, G.gangId).capacity, 200);
  assert.equal(h.state(G.gangId).kasa, 5_000_000 - 200_000);
  assert.ok(h.chat(G.gangId).some((m) => /kapasite 200/.test(m)));
});
test('sipariş: yol sahibi, yarı fiyat, Pzt–Cmt 00:00–12:00, tır kapasitesi 10/10/100, tek tür, depo yeri, günlük limit, iptal', async () => {
  const h = await createHarness();
  const G = await setupTradeGang(h, 'Alfa', { depot: 0 });
  const { truckId } = await h.act(G.baba, 'buyTruck');
  const e0 = await h.fails(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 10 } });
  assert.match(e0.message, /ticaret yolu/);
  await h.giveRoute(G.gangId, 'yasakliMadde', 100_000);
  await h.giveRoute(G.gangId, 'silah', 1_000_000);
  // depo yok → sipariş yok
  const e1 = await h.fails(G.baba, 'placeOrder', { truckId, product: 'silah', items: { 'silah:1': 1 } });
  assert.match(e1.message, /depo/i);
  await h.act(G.baba, 'buyDepot'); // 100 kapasite
  await h.fails(G.ids[1], 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 10 } }); // Kıdemli
  await h.fails(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { 'silah:1': 1 } }); // tek tür
  await h.fails(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 101 } }); // tır: 100
  await h.fails(G.baba, 'placeOrder', { truckId, product: 'silah', items: { 'silah:1': 6, 'silah:2': 5 } }); // tır: 10 silah
  // limit 100k → yasaklı madde 1.250 → en fazla 80 adet
  const lim = await h.fails(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 81 } });
  assert.match(lim.message, /limit/);
  const k0 = h.state(G.gangId).kasa;
  const r = await h.act(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 80 } });
  assert.equal(r.cost, 80 * 1250);
  assert.equal(r.units, 80);
  assert.equal(h.state(G.gangId).kasa, k0 - 100_000);
  assert.equal(depotOf(h, G.gangId).reservedUnits, 80);
  // tıra günde tek sipariş
  const dup = await h.fails(G.ids[0], 'placeOrder', { truckId, product: 'silah', items: { 'silah:1': 1 } });
  assert.match(dup.message, /bekleyen/);
  // ikinci tır: depoda 20 yer kaldı → 3 silah (30 yer) sığmaz, 2 silah sığar
  const t2 = (await buyTruckAnyDay(h, G.gangId, G.baba)).truckId;
  const full = await h.fails(G.baba, 'placeOrder', { truckId: t2, product: 'silah', items: { 'silah:1': 3 } });
  assert.match(full.message, /yer/);
  await h.act(G.baba, 'placeOrder', { truckId: t2, product: 'silah', items: { 'silah:1': 2 } });
  assert.equal(depotOf(h, G.gangId).reservedUnits, 100);
  // iptal: para, limit ve yer geri
  await h.act(G.baba, 'cancelOrder', { orderId: `${truckId}_2026-09-21` });
  assert.equal(depotOf(h, G.gangId).reservedUnits, 20);
  await h.act(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 80 } });
  // v67: kalkış saati bir sonraki 3 saatlik dilim (09:00 siparişi → 12:00)
  assert.equal(h.get(`orders/${truckId}_2026-09-21`).departAtMs, ist('2026-09-21', '12:00'));
  // 12:00'den sonra sipariş yok
  h.at('2026-09-21', '12:00');
  const noon = await h.fails(G.baba, 'placeOrder', { truckId: t2, product: 'silah', items: { 'silah:1': 1 } });
  assert.match(noon.message, /00:00–12:00/);
  // Pazar sipariş yok
  h.at('2026-09-27', '10:00');
  const we = await h.fails(G.baba, 'placeOrder', { truckId: t2, product: 'silah', items: { 'silah:1': 1 } });
  assert.match(we.message, /Pazartesi–Cumartesi/);
});

test('v67: Cumartesi sipariş verilir; yola çıkan tır aynı gün iptal edilemez ve ikinci kez yüklenemez', async () => {
  const h = await createHarness();
  const G = await setupTradeGang(h);
  await h.giveRoute(G.gangId, 'araba', 1_000_000);
  const { truckId } = await h.act(G.baba, 'buyTruck');
  await h.tickTo('2026-09-26', '02:10'); // Cumartesi
  await h.act(G.baba, 'placeOrder', { truckId, product: 'araba', items: { 'araba:1': 2 } });
  await h.tickTo('2026-09-26', '03:01');
  const t = h.get(`trucks/${truckId}`);
  assert.equal(t.status, 'in_transit');
  assert.equal(t.departAtMs, ist('2026-09-26', '03:00'));
  assert.equal(t.attackAtMs, ist('2026-09-26', '09:00'));
  const c = await h.fails(G.baba, 'cancelOrder', { orderId: `${truckId}_2026-09-26` });
  assert.match(c.message, /iptal edilemez/);
  const again = await h.fails(G.baba, 'placeOrder', { truckId, product: 'araba', items: { 'araba:1': 1 } });
  assert.match(again.message, /zaten yola çıktı/);
  await h.tickTo('2026-09-27', '00:05');
  assert.equal(depotOf(h, G.gangId).items['araba:1'], 2, 'gece 00:00 teslim');
});

test('v67: sipariş verilen gün sonraki dilimde yola çıkar, gece 00:00 depoya ulaşır; ertesi gün tekrar yüklenir; çift teslim yok', async () => {
  const h = await createHarness();
  const G = await setupTradeGang(h);
  await h.giveRoute(G.gangId, 'araba', 1_000_000);
  const { truckId } = await h.act(G.baba, 'buyTruck');
  await h.act(G.baba, 'placeOrder', { truckId, product: 'araba', items: { 'araba:1': 4 } }); // Pzt 09:00
  await h.tickTo('2026-09-21', '11:55');
  assert.equal(h.get(`trucks/${truckId}`).status, 'idle', 'kalkış saati gelmedi');
  await h.tickTo('2026-09-21', '12:02');
  let t = h.get(`trucks/${truckId}`);
  assert.equal(t.status, 'in_transit');
  assert.equal(t.departDateKey, '2026-09-21');
  assert.equal(t.attackAtMs, ist('2026-09-21', '18:00'));
  assert.deepEqual(h.get(`trucks/${truckId}/cargo/main`).items, { 'araba:1': 4 });
  assert.ok(h.chat(G.gangId).some((m) => /yola çıktı — 18:00'e kadar/.test(m)));
  await h.tickTo('2026-09-22', '00:05');
  let d = depotOf(h, G.gangId);
  assert.equal(d.items['araba:1'], 4);
  assert.equal(d.usedUnits, 40);
  assert.equal(h.get(`trucks/${truckId}`).status, 'idle');
  // ertesi gün yeni sipariş
  h.at('2026-09-22', '07:30');
  await h.act(G.baba, 'placeOrder', { truckId, product: 'araba', items: { 'araba:2': 3 } });
  await h.tickTo('2026-09-22', '09:00');
  assert.equal(h.get(`trucks/${truckId}`).status, 'in_transit');
  await h.internal.clock.runClock('test');
  assert.equal(depotOf(h, G.gangId).items['araba:1'], 4);
  await h.tickTo('2026-09-23', '00:05');
  d = depotOf(h, G.gangId);
  assert.equal(d.items['araba:2'], 3);
  assert.equal(d.usedUnits, 70);
  assert.equal(d.reservedUnits, 0);
  assert.equal(h.get(`trucks/${truckId}`).status, 'idle');
});

test('tır ömrü: son gün sipariş yok; ömrü dolunca hurdaya çıkar, kimlik serbest', async () => {
  const h = await createHarness();
  const G = await setupTradeGang(h);
  await h.giveRoute(G.gangId, 'yasakliMadde', 1_000_000);
  const { truckId, code } = await h.act(G.baba, 'buyTruck');
  await h.db.doc(`gangWorlds/test/trucks/${truckId}`).update({ expiresDateKey: '2026-09-23' });
  await h.act(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 5 } }); // 2 gün kaldı: olur
  await h.tickTo('2026-09-22', '09:00');
  const e = await h.fails(G.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 5 } });
  assert.match(e.message, /ömrü/);
  await h.tickTo('2026-09-23', '00:05');
  assert.equal(depotOf(h, G.gangId).items.yasakliMadde, 5, 'son sefer teslim edildi');
  const t = h.get(`trucks/${truckId}`);
  assert.equal(t.status, 'retired');
  assert.equal(h.get(`truckCodes/${code}`), undefined);
});

test('v67: çete depo ürünleri anında satılamaz ve dağıtılamaz (sadece 2. el)', async () => {
  const h = await createHarness();
  const G = await setupTradeGang(h);
  await h.db.doc(`gangWorlds/test/gangs/${G.gangId}/private/depot`).set({ items: { yasakliMadde: 100, 'silah:2': 5 }, capacity: 200, usedUnits: 150, reservedUnits: 0 });
  const kasa0 = h.state(G.gangId).kasa;
  assert.match((await h.fails(G.baba, 'sellFromDepot', { itemKey: 'yasakliMadde', qty: 10 })).message, /anında satılamaz/);
  assert.match((await h.fails(G.baba, 'distributeFromDepot', { itemKey: 'silah:2', qty: 5, group: 'rutbeli' })).message, /dağıtılamaz/);
  assert.equal(h.state(G.gangId).kasa, kasa0);
  assert.equal(depotOf(h, G.gangId).usedUnits, 150);
  const l = await h.act(G.baba, 'listDepotItem', { itemKey: 'silah:2', qty: 2, unitPrice: 8_000 });
  assert.ok(l.listingId, '2. ele konabilir');
});

// Sabotaj kurulum: A'nın n tırı yolda (yasaklı madde)
// v67: sipariş o günün 05:30'unda verilir → 06:00'da yola çıkar → 12:00'ye kadar
// ihbar/sabotaj/operasyon, 12:00–24:00 saldırı (eski testlerle aynı pencere).
async function trucksOnRoad(h, A, n, qty = 50, product = 'yasakliMadde', day = '2026-09-22') {
  await h.giveRoute(A.gangId, product, 5_000_000);
  if (h.clock.now < ist(day, '05:30')) await h.tickTo(day, '05:30');
  const ids = [];
  for (let i = 0; i < n; i++) {
    const { truckId } = await buyTruckAnyDay(h, A.gangId, A.baba);
    const items = product === 'yasakliMadde' ? { yasakliMadde: qty } : { [`${product}:1`]: qty };
    await h.act(A.baba, 'placeOrder', { truckId, product, items });
    ids.push(truckId);
  }
  return ids;
}

test('sabotaj ücreti SABİT 50k (her yeni sabotajla artmaz); 12:00 sonrası yok; Kıdemli başlatamaz', async () => {
  const h = await createHarness();
  const A = await setupTradeGang(h, 'Alfa', { depot: 5000 });
  const B = await setupTradeGang(h, 'Beta', { depot: 5000 });
  const C = await setupTradeGang(h, 'Gama', { depot: 5000 });
  const trucks = await trucksOnRoad(h, A, 3);
  await h.tickTo('2026-09-22', '08:00');
  const kB = h.state(B.gangId).kasa;
  const q = await h.act(B.baba, 'quoteSabotage', { truckId: trucks[0] });
  assert.equal(q.price, 50_000);
  await h.act(B.baba, 'startSabotage', { truckId: trucks[0] });
  const q2 = await h.act(C.baba, 'quoteSabotage', { truckId: trucks[1] });
  assert.equal(q2.price, 50_000, 'başka çetenin sabotajı fiyatı ARTIRMAZ');
  await h.act(C.ids[0], 'startSabotage', { truckId: trucks[1] });
  await h.fails(B.ids[1], 'startSabotage', { truckId: trucks[2] }); // Kıdemli yetkisiz
  const q3 = await h.act(B.baba, 'quoteSabotage', { truckId: trucks[2] });
  assert.equal(q3.price, 50_000);
  assert.equal(h.state(B.gangId).kasa, kB - 50_000);
  await h.fails(B.baba, 'startSabotage', { truckId: trucks[0] }); // aynı tır tekrar
  h.at('2026-09-22', '12:00');
  const late = await h.fails(B.baba, 'startSabotage', { truckId: trucks[2] });
  assert.match(late.message, /12:00/);
  // ertesi gün de aynı sabit fiyat
  const [t4] = await trucksOnRoad(h, A, 1, 50, 'yasakliMadde', '2026-09-23');
  await h.tickTo('2026-09-23', '09:00');
  assert.equal((await h.act(B.baba, 'quoteSabotage', { truckId: t4 })).price, 50_000);
});

test('sabotaj talebi: Kıdemli/Tetikçi sohbete talep gönderir, Çömez gönderemez, tekrar yok', async () => {
  const h = await createHarness();
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta');
  const [t1] = await trucksOnRoad(h, A, 1);
  const x = await h.persona({ displayName: 'Çömez B', gold: 1, power: 1000, reputation: 1 });
  await h.act(x, 'joinGang', { gangId: B.gangId });
  await h.tickTo('2026-09-22', '08:00');
  await h.act(B.ids[1], 'requestSabotage', { truckId: t1 });
  await h.fails(B.ids[1], 'requestSabotage', { truckId: t1 });
  await h.fails(x, 'requestSabotage', { truckId: t1 });
  await h.fails(B.baba, 'requestSabotage', { truckId: t1 }); // Baba doğrudan başlatır
  assert.ok(h.chat(B.gangId).some((m) => /sabotaj talebi gönderdi: TIR #/.test(m)));
});

test('saldırılar tır sahibine 12:00de duyurulur; o zamana kadar savunma/saldırı kartını göremez', async () => {
  const h = await createHarness();
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta');
  const [t1] = await trucksOnRoad(h, A, 1);
  await h.tickTo('2026-09-22', '08:00');
  const { warId } = await h.act(B.baba, 'startSabotage', { truckId: t1, harac: 5000 });
  const defId = `def_${t1}_2026-09-22`;
  assert.ok(!h.get(`wars/${warId}`).gangIds.includes(A.gangId));
  assert.ok(!h.get(`wars/${defId}`).gangIds.includes(A.gangId));
  assert.ok(h.get(`wars/${defId}`).gangIds.includes(B.gangId), 'saldıran savunma gücünü görebilir');
  assert.ok(!h.chat(A.gangId).some((m) => /saldırı altında/.test(m)));
  await h.fails(A.baba, 'payHarac', { warId }); // henüz duyurulmadı
  await h.tickTo('2026-09-22', '12:01');
  assert.ok(h.get(`wars/${warId}`).gangIds.includes(A.gangId));
  assert.ok(h.get(`wars/${defId}`).gangIds.includes(A.gangId));
  assert.ok(h.chat(A.gangId).some((m) => /TIR #\d{4} saldırı altında! Beta \(haraç 5\.000\)/.test(m)));
  await h.internal.clock.runClock('test'); // tekrar duyuru yok
  assert.equal(h.chat(A.gangId).filter((m) => /saldırı altında/.test(m)).length, 1);
});

test('sabotaj başarılı: yük saldırganın deposuna, tır sahibine boş döner; savunma başarılıysa teslim', async () => {
  const h = await createHarness({ dice: [6, 6, 1, 1, 1, 1, 6, 6] });
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta');
  const [t1, t2] = await trucksOnRoad(h, A, 2, 40);
  await h.tickTo('2026-09-22', '09:00');
  const s1 = await h.act(B.baba, 'startSabotage', { truckId: t1 });
  const s2 = await h.act(B.baba, 'startSabotage', { truckId: t2 });
  assert.equal(depotOf(h, B.gangId).reservedUnits, 80, 'gerçek yük kadar yer ayrıldı');
  await h.fails(B.baba, 'rollDice', { warId: s1.warId }); // 12:00 öncesi saldırı yok
  await h.tickTo('2026-09-22', '12:30');
  await h.act(B.baba, 'rollDice', { warId: s1.warId }); // 12 × 60k
  await h.act(A.baba, 'rollDice', { warId: `def_${t1}_2026-09-22` }); // 2 × 60k
  h.at('2026-09-22', '18:30');
  await h.act(B.baba, 'rollDice', { warId: s2.warId }); // 2 × 60k
  await h.act(A.baba, 'rollDice', { warId: `def_${t2}_2026-09-22` }); // 12 × 60k
  await h.tickTo('2026-09-23', '00:05');
  const depB = depotOf(h, B.gangId);
  const depA = depotOf(h, A.gangId);
  assert.equal(depB.items.yasakliMadde, 40, 't1 yükü B deposunda');
  assert.equal(depB.usedUnits, 40);
  assert.equal(depB.reservedUnits, 0, 'saldırı yeri serbest');
  assert.equal(depA.items.yasakliMadde, 40, 't2 savunuldu, A deposunda');
  assert.equal(depA.reservedUnits, 0);
  assert.equal(depA.usedUnits, 40);
  assert.equal(h.get(`trucks/${t1}`).status, 'idle');
  assert.equal(h.get(`trucks/${t1}`).gangId, A.gangId, 'tır çalınmaz, sahibine döner');
  assert.equal(h.get(`trucks/${t1}`).lastTrip.outcome, 'stolen');
  assert.equal(h.get(`wars/${s1.warId}`).result.won, true);
  assert.equal(h.get(`wars/${s2.warId}`).result.won, false);
  assert.ok(h.chat(B.gangId).some((m) => /sabotajı BAŞARILI/.test(m)));
});

test('haraç: alt/üst sınır yok; 21:00e kadar (v38); en güçlünün haracı ödenince sıradaki en güçlü esas alınır', async () => {
  const h = await createHarness({ dice: [6, 6, 1, 1, 2, 2] });
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta');
  const C = await setupTradeGang(h, 'Gama');
  const [t1, t2] = await trucksOnRoad(h, A, 2, 10);
  await h.tickTo('2026-09-22', '09:00');
  const huge = 999_000_000; // üst sınır yok
  const sB = await h.act(B.baba, 'startSabotage', { truckId: t1, harac: 40_000 });
  const sC = await h.act(C.baba, 'startSabotage', { truckId: t1, harac: huge });
  await h.act(C.baba, 'startSabotage', { truckId: t2, harac: 0 });
  await h.fails(B.baba, 'startSabotage', { truckId: t2, harac: -5 });
  await h.tickTo('2026-09-22', '12:30');
  await h.act(B.baba, 'rollDice', { warId: sB.warId }); // 12 × 60k = 720k (en güçlü)
  await h.act(C.baba, 'rollDice', { warId: sC.warId }); // 2 × 60k = 120k
  await h.act(A.baba, 'rollDice', { warId: `def_${t1}_2026-09-22` }); // 4 × 60k = 240k
  const kasaB = h.state(B.gangId).kasa;
  await h.fails(A.ids[1], 'payHarac', { warId: sB.warId }); // Kıdemli ödeyemez
  await h.act(A.ids[0], 'payHarac', { warId: sB.warId });
  assert.equal(h.get(`wars/${sB.warId}`).status, 'cancelled_harac');
  assert.equal(h.state(B.gangId).kasa, kasaB + 40_000);
  assert.equal(h.get(`wars/def_${t1}_2026-09-22`).status, 'active', 'v74: C hâlâ saldırıyor → savunma sürer');
  await h.fails(A.baba, 'payHarac', { warId: sB.warId }); // ikinci ödeme yok
  // v38: son ödeme son dilim (21:00) başlayana kadar
  h.at('2026-09-22', '18:00');
  const stillOk = await h.fails(A.baba, 'payHarac', { warId: sC.warId }); // 18:00'de hâlâ açık (kasa yetmez → süre hatası değil)
  assert.doesNotMatch(stillOk.message, /kapandı/);
  h.at('2026-09-22', '21:00');
  const late = await h.fails(A.baba, 'payHarac', { warId: sC.warId });
  assert.match(late.message, /21:00/);
  await h.tickTo('2026-09-23', '00:05');
  // B çekildi → C (120k) < savunma (240k) → tır güvenle ulaştı
  assert.equal(h.get(`trucks/${t1}`).lastTrip.outcome, 'delivered');
  assert.equal(depotOf(h, B.gangId).reservedUnits, 0);
});

test('depo yeri tırın GERÇEK yüküyle: 1 arabası olan 100lük depoya 100 yasaklı madde sığmaz → sabotaj yok', async () => {
  const h = await createHarness();
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta', { depot: 0 });
  const [big] = await trucksOnRoad(h, A, 1, 100);
  await h.giveRoute(A.gangId, 'araba', 5_000_000);
  const small = (await buyTruckAnyDay(h, A.gangId, A.baba)).truckId;
  await h.act(A.baba, 'placeOrder', { truckId: small, product: 'araba', items: { 'araba:1': 9 } }); // aynı gün 05:30
  await h.db.doc(`gangWorlds/test/gangs/${B.gangId}/private/depot`).set({ items: { 'araba:1': 1 }, capacity: 100, usedUnits: 10, reservedUnits: 0 });
  await h.tickTo('2026-09-22', '09:00');
  const q = await h.act(B.baba, 'quoteSabotage', { truckId: big });
  assert.equal(q.canReceive, false);
  const err = await h.fails(B.baba, 'startSabotage', { truckId: big });
  assert.match(err.message, /yer yok/);
  const q2 = await h.act(B.baba, 'quoteSabotage', { truckId: small }); // 90 yer = 9 araba sığar
  assert.equal(q2.canReceive, true);
  await h.act(B.baba, 'startSabotage', { truckId: small });
});

test('müttefik savunmaya güç ekler (12:00 duyurusuyla görür); müttefike sabotaj yapılamaz', async () => {
  const h = await createHarness({ dice: [3, 3, 6, 6, 5, 5] });
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta');
  const C = await setupTradeGang(h, 'Gama');
  const { allianceId } = await h.act(A.baba, 'requestAlliance', { targetGangId: C.gangId });
  await h.act(C.ids[0], 'respondAlliance', { allianceId, accept: true }); // Sağ Kol kabul edebilir
  const [t1] = await trucksOnRoad(h, A, 1);
  await h.tickTo('2026-09-22', '09:00');
  const err = await h.fails(C.baba, 'startSabotage', { truckId: t1 });
  assert.match(err.message, /İttifak/);
  const { warId } = await h.act(B.baba, 'startSabotage', { truckId: t1 });
  await h.tickTo('2026-09-22', '13:00');
  assert.ok(h.get(`wars/def_${t1}_2026-09-22`).gangIds.includes(C.gangId));
  assert.ok(h.chat(C.gangId).some((m) => /Müttefik Alfa/.test(m)));
  await h.act(B.baba, 'rollDice', { warId }); // 6×60k=360k
  await h.act(A.baba, 'rollDice', { warId: `def_${t1}_2026-09-22` }); // 12×60k = 720k
  await h.act(C.baba, 'rollDice', { warId: `def_${t1}_2026-09-22` }); // müttefik: 10×60k
  const x = await h.persona({ displayName: 'Yabancı', gold: 1, power: 5000, reputation: 1 });
  await h.act(x, 'joinGang', { gangId: B.gangId });
  await h.fails(x, 'rollDice', { warId: `def_${t1}_2026-09-22` });
  await h.tickTo('2026-09-23', '00:05');
  assert.equal(h.get(`wars/def_${t1}_2026-09-22`).result.defensePower, 720_000 + 600_000);
  assert.equal(h.get(`trucks/${t1}`).lastTrip.outcome, 'delivered');
});

test('v38: sabotajda günde 4 dilim (12·15·18·21): 12:00 öncesi zar yok; dilim başına 1 saldırı, farklı savaşlar dahil', async () => {
  const h = await createHarness();
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta');
  const [t1, t2] = await trucksOnRoad(h, A, 2);
  await h.tickTo('2026-09-22', '09:00');
  const s1 = (await h.act(B.baba, 'startSabotage', { truckId: t1 })).warId;
  const s2 = (await h.act(B.baba, 'startSabotage', { truckId: t2 })).warId;
  const early = await h.fails(B.baba, 'rollDice', { warId: s1 });
  assert.match(early.message, /başlamadı/);
  await h.tickTo('2026-09-22', '12:00');
  await h.act(B.baba, 'rollDice', { warId: s1 });
  const same = await h.fails(B.baba, 'rollDice', { warId: s2 }); // aynı dilimde başka sabotaj da yok
  assert.match(same.message, /dilimde/);
  h.at('2026-09-22', '14:59');
  await h.fails(B.baba, 'rollDice', { warId: s1 });
  for (const [t, w] of [['15:00', s2], ['18:00', s1], ['21:00', s2]]) {
    h.at('2026-09-22', t);
    await h.act(B.baba, 'rollDice', { warId: w }); // yeni dilimde yeni saldırı
    await h.fails(B.baba, 'rollDice', { warId: w === s1 ? s2 : s1 });
  }
  const slots = Object.keys(h.db._dump('gangWorlds/test/slots/')).filter((k) => k.includes(B.baba));
  assert.equal(slots.length, 4, 'sabotaj gününde en fazla 4 saldırı');
});

test('v67: 09:00 siparişi → 12:00 kalkış → 18:00e kadar sabotaj → 18:00 duyuru ve saldırı → haraç 21:00e kadar → 00:00 sonuç', async () => {
  const h = await createHarness({ dice: [6, 6, 1, 1] });
  const A = await setupTradeGang(h, 'Alfa');
  const B = await setupTradeGang(h, 'Beta');
  await h.giveRoute(A.gangId, 'yasakliMadde', 5_000_000);
  const { truckId } = await h.act(A.baba, 'buyTruck');
  await h.act(A.baba, 'placeOrder', { truckId, product: 'yasakliMadde', items: { yasakliMadde: 30 } }); // Pzt 09:00
  assert.match((await h.fails(B.baba, 'startSabotage', { truckId })).message, /yolda değil/, 'kalkıştan önce sabotaj yok');
  await h.tickTo('2026-09-21', '17:59');
  const q = await h.act(B.baba, 'quoteSabotage', { truckId });
  assert.equal(q.open, true);
  assert.equal(q.attackAtMs, ist('2026-09-21', '18:00'));
  const { warId } = await h.act(B.baba, 'startSabotage', { truckId, harac: 1000 });
  assert.equal(h.get(`wars/${warId}`).startsAtMs, ist('2026-09-21', '18:00'));
  assert.match((await h.fails(B.baba, 'rollDice', { warId })).message, /başlamadı/);
  assert.ok(!h.chat(A.gangId).some((m) => /saldırı altında/.test(m)));
  const C = await setupTradeGang(h, 'Gama');
  h.at('2026-09-21', '18:00');
  assert.match((await h.fails(C.baba, 'startSabotage', { truckId })).message, /6 saat/);
  await h.tickTo('2026-09-21', '18:01');
  assert.ok(h.chat(A.gangId).some((m) => /saldırı altında! .*Savunma 18:00–24:00/.test(m)));
  await h.act(B.baba, 'rollDice', { warId });
  await h.act(A.baba, 'rollDice', { warId: `def_${truckId}_2026-09-21` });
  h.at('2026-09-21', '20:59');
  const kA = h.state(A.gangId).kasa;
  const paid = await h.act(A.baba, 'payHarac', { warId });
  assert.equal(h.state(A.gangId).kasa, kA - 1000);
  // v74: saldıran kalmadı → savunma savaşı da hemen biter
  assert.equal(paid.defenseEnded, true);
  const defId = `def_${truckId}_2026-09-21`;
  assert.equal(h.get(`wars/${defId}`).status, 'ended_paid');
  assert.deepEqual(h.get(`wars/${defId}`).activeGangIds, []);
  assert.match((await h.fails(A.ids[0], 'rollDice', { warId: defId })).message, /aktif değil/);
  await h.tickTo('2026-09-22', '00:05');
  assert.equal(h.get(`trucks/${truckId}`).lastTrip.outcome, 'delivered');
  assert.equal(depotOf(h, A.gangId).items.yasakliMadde, 30);
});
