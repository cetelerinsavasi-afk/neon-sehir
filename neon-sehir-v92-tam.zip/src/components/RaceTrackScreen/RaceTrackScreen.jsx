import { useEffect, useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import SignInPrompt from '../SignInPrompt/SignInPrompt';
import RaceLobby, { TrainingLobby } from './RaceLobby';
import ChampionshipScreen from './ChampionshipScreen';
import { warmUpRaceHub } from '../../services/gameActions';
import './RaceTrackScreen.css';

const CARDS = [
  { id: 'championship', label: 'Şampiyona', emoji: '🏆', desc: 'Gece pistinde kronometreye karşı sür; günün en hızlısı ödülü kapar.' },
  { id: 'bet', label: 'Bahisli Yarış', emoji: '🏁', desc: 'Başka bir oyuncuyla aynı anda yarış; kısa sürede bitiren bahsi alır.' },
  { id: 'training', label: 'Antrenman', emoji: '🎓', desc: '10 seviye: her seviyede bir üst galeri aracını süren bota karşı yarış.' },
];

// Aktif bir yarışın (kurdum/katıldım/devam ediyor) tam ekran gösterimi
// artık App.jsx seviyesinde (RaceFullScreen ile) yönetiliyor — bu bileşen
// SADECE lobiyi gösterir. Oda kurulur/katılınır katılınmaz onEnterRace
// çağrılıp App.jsx'e devrediliyor.
// initialSelected/onModeChange — kullanıcı revizesi: "şampiyonadan
// çıkınca direkt yarış ana ekranına değil, şampiyona lobisine dönsün".
// Hangi lobide olduğumuzu (championship/bet/training) App.jsx seviyesinde
// hatırlıyoruz (bkz. GameShell içindeki raceLobbyMode) — yarıştan
// çıkılıp bu ekran yeniden açıldığında kaldığımız lobide devam ediyoruz.
export default function RaceTrackScreen({ onEnterRace, initialSelected = null, onModeChange }) {
  const { user } = useAuth();
  const [selected, setSelectedState] = useState(initialSelected);

  const setSelected = (value) => {
    setSelectedState(value);
    onModeChange?.(value);
  };

  // Kullanıcı yarış sekmesine girer girmez (henüz oda bile kurmadan)
  // ortak yarış Cloud Function'ını ısıtmaya başlıyoruz — bkz.
  // gameActions.js içindeki warmUpRaceHub notu. RaceRoom.jsx'te bir kez
  // daha çağrılır (garanti olsun diye), maliyeti yok.
  useEffect(() => {
    if (user) warmUpRaceHub();
  }, [user]);

  if (!user) {
    return <SignInPrompt message="Yarış pistine girmek için giriş yapmalısın." />;
  }

  if (selected) {
    return (
      <div className="race-detail">
        <button className="race-back-btn" onClick={() => setSelected(null)}>
          ← Geri
        </button>
        {selected === 'championship' && <ChampionshipScreen onEnterRace={onEnterRace} />}
        {selected === 'bet' && <RaceLobby myUid={user.uid} onEnterRoom={onEnterRace} />}
        {selected === 'training' && <TrainingLobby onEnterRoom={onEnterRace} />}
      </div>
    );
  }

  return (
    <div className="race-picker">
      {CARDS.map((c) => (
        <button key={c.id} className="race-picker-card" onClick={() => setSelected(c.id)}>
          <span className="race-picker-emoji">{c.emoji}</span>
          <span className="race-picker-title">{c.label}</span>
          <span className="race-picker-desc">{c.desc}</span>
        </button>
      ))}
    </div>
  );
}
