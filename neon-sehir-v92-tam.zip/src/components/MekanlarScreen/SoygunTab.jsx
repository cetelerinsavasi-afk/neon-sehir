import { useEffect, useState } from 'react';
import { useWeapons } from '../../hooks/useWeapons';
import { useOpenHeistPlanCounts } from '../../hooks/useOpenHeistPlanCounts';
import { useMyActiveHeistPlans } from '../../hooks/useMyActiveHeistPlan';
import HeistPanel, { HEIST_LABELS } from '../HeistPanel/HeistPanel';
import GuestOverlay from '../GuestOverlay/GuestOverlay';
import { INITIAL_LIFE_DAYS } from '../VehicleCard/VehicleCard';
import './MekanlarScreen.css';

// SoygunTab — eskiden HeistScreen.jsx'in TAMAMIYDI (kendi backdrop/başlık/
// kapatma çerçevesiyle). Artık "Mekanlar" ekranının bir sekmesi (bkz.
// MekanlarScreen.jsx) — dış çerçeve (backdrop/başlık/sekme çubuğu/kapatma)
// yukarı taşındı, burada SADECE hedef listesi + ekip planları + detay
// paneli kalıyor. Davranış eskisiyle BİREBİR aynı (yeni istek: "soygun
// kısmı şu ankiyle aynı olacak") — tek görsel fark, her hedefin artık bir
// emojisi olması (bkz. HEIST_LABELS).
export default function SoygunTab({ initialTarget }) {
  const { weapons } = useWeapons();
  const planCounts = useOpenHeistPlanCounts();
  const myActivePlans = useMyActiveHeistPlans();
  const [selected, setSelected] = useState(initialTarget || null);
  const [showMyPlans, setShowMyPlans] = useState(false);

  useEffect(() => {
    if (initialTarget) {
      setSelected(initialTarget);
      setShowMyPlans(false);
    }
  }, [initialTarget]);

  // KULLANICI REVİZESİ (BUG DÜZELTMESİ): ömrü (lifeDays) 0 olan bir silah —
  // tamir hakkı kalmış olsa bile — güç hesabına dahil edilmemeli. Ayrıca
  // 2. el sitesinde satılmış/satışa çıkarılmış (listed: true) bir silah da
  // artık fiilen elimizde değildir, onun da gücü sayılmamalı (bkz.
  // functions/index.js getMaxWeaponPower'daki aynı düzeltme — burası
  // ekranın sunucuyla TUTARLI göstermesi için).
  const myPower = weapons.reduce(
    (max, w) => (!w.listed && (w.lifeDays ?? INITIAL_LIFE_DAYS) > 0 ? Math.max(max, w.power || 0) : max),
    0
  );

  return (
    <div className="mekanlar-soygun-tab">
      <div className="heist-screen-header">
        <p className="heist-screen-power">
          Gücün: <strong>{myPower.toLocaleString('tr-TR')}</strong>
        </p>
        {myActivePlans.length > 0 && (
          <button
            className="heist-screen-myplan-btn"
            onClick={() => {
              if (myActivePlans.length === 1) {
                setSelected(myActivePlans[0].target);
                setShowMyPlans(false);
              } else {
                setSelected(null);
                setShowMyPlans(true);
              }
            }}
          >
            Ekip Soygunlarım{myActivePlans.length > 1 ? ` (${myActivePlans.length})` : ''}
          </button>
        )}
      </div>

      <GuestOverlay>
        <>
          {showMyPlans && !selected && (
            <div className="heist-screen-list">
              <p className="heist-screen-myplans-hint">
                Şu an {myActivePlans.length} farklı hedefte açık ekip soygun planın var:
              </p>
              {myActivePlans.map((p) => {
                const meta = HEIST_LABELS[p.target];
                return (
                  <button
                    key={p.planId}
                    className="heist-target-card"
                    onClick={() => {
                      setSelected(p.target);
                      setShowMyPlans(false);
                    }}
                  >
                    <span className="heist-target-name">
                      {meta?.emoji ? `${meta.emoji} ` : ''}
                      {meta?.title || p.target}
                    </span>
                    {meta && (
                      <span className="heist-target-meta">
                        Güvenlik: {meta.requiredPower.toLocaleString('tr-TR')} · Ödül:{' '}
                        {meta.reward.toLocaleString('tr-TR')} altın · Şüphe: +{meta.suspicionCost}
                      </span>
                    )}
                  </button>
                );
              })}
              <button className="heist-screen-back" onClick={() => setShowMyPlans(false)}>
                ← Tüm hedefler
              </button>
            </div>
          )}

          {!selected && !showMyPlans && (
            <div className="heist-screen-list">
              {Object.entries(HEIST_LABELS).map(([target, meta]) => (
                <button key={target} className="heist-target-card" onClick={() => setSelected(target)}>
                  <span className="heist-target-name">
                    {meta.emoji ? `${meta.emoji} ` : ''}
                    {meta.title}
                    {planCounts[target] > 0 && (
                      <span className="heist-target-plan-badge">({planCounts[target]})</span>
                    )}
                  </span>
                  <span className="heist-target-meta">
                    Güvenlik: {meta.requiredPower.toLocaleString('tr-TR')} · Ödül:{' '}
                    {meta.reward.toLocaleString('tr-TR')} altın · Şüphe: +{meta.suspicionCost}
                  </span>
                  <span className={`heist-target-status ${myPower >= meta.requiredPower ? 'ready' : ''}`}>
                    {myPower >= meta.requiredPower ? 'Gücün yetiyor' : 'Ekip gerekir'}
                  </span>
                </button>
              ))}
            </div>
          )}

          {selected && (
            <div className="heist-screen-detail">
              <button
                className="heist-screen-back"
                onClick={() => {
                  setSelected(null);
                  setShowMyPlans(false);
                }}
              >
                ← Tüm hedefler
              </button>
              <HeistPanel target={selected} />
            </div>
          )}
        </>
      </GuestOverlay>
    </div>
  );
}
