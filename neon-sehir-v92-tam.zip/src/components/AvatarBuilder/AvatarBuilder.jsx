import { useEffect, useRef, useState } from 'react';
import {
  AVATAR_OPTIONS,
  DEFAULT_AVATAR,
  SKIN_TONES,
  EYE_COLORS,
  HAIR_COLORS,
  CLOTH_COLORS,
  HAT_COLORS,
  LIP_COLORS,
  BACKGROUND_COLORS,
  PANTS_COLORS,
  SHOE_COLORS,
} from '../../lib/avatarShapes';
import { usePlayer } from '../../hooks/usePlayer';
import { setAvatar, setDisplayName } from '../../services/gameActions';
import AvatarSvg from '../AvatarSvg/AvatarSvg';
import './AvatarBuilder.css';

const OPTION_LABELS = {
  gender: { title: 'Beden Tipi', values: { erkek: 'Erkek', kadin: 'Kadın' } },
  build: { title: 'Vücut Yapısı', values: { zayif: 'Zayıf', standart: 'Standart', iri: 'İri Yarı' } },
  faceShape: {
    title: 'Kafa Tipi',
    values: {
      oval: 'Oval', round: 'Yuvarlak', square: 'Köşeli', heart: 'Kalp', long: 'Uzun', diamond: 'Elmas',
    },
  },
  eyebrowShape: {
    title: 'Kaş',
    values: {
      straight: 'Düz', arched: 'Kemerli', thick: 'Kalın', thin: 'İnce', angled: 'Çatık', unibrow: 'Çatık Birleşik',
    },
  },
  eyeShape: {
    title: 'Göz Şekli',
    values: {
      almond: 'Badem', round: 'Yuvarlak', narrow: 'Dar', wide: 'İri', hooded: 'Kapaklı', downturned: 'Düşük Köşeli',
    },
  },
  eyelash: {
    title: 'Kirpik',
    values: { none: 'Yok', natural: 'Doğal', long: 'Uzun', dramatic: 'Gösterişli' },
  },
  noseShape: {
    title: 'Burun',
    values: {
      small: 'Küçük', straight: 'Düz', wide: 'Geniş', button: 'Ufak Yuvarlak', aquiline: 'Kemerli', flat: 'Basık',
    },
  },
  mouthShape: {
    title: 'Ağız Yapısı',
    values: {
      neutral: 'Nötr', smile: 'Gülümseyen', smirk: 'Yan Gülüş', full: 'Dolgun', thin: 'İnce', open: 'Aralık',
    },
  },
  hairStyle: {
    title: 'Saç Stili',
    values: {
      kel: 'Kel', short: 'Kısa', slick: 'Taramalı', wavy: 'Dalgalı', long: 'Uzun',
      mohawk: 'Mohawk', afro: 'Afro', bun: 'Topuz', braids: 'Örgü', undercut: 'Undercut',
      ponytail: 'At Kuyruğu', curly: 'Kıvırcık', pixie: 'Pixie Kesim',
    },
  },
  facialHair: {
    title: 'Yüz Kılı',
    values: {
      none: 'Yok', mustache: 'Bıyık', goatee: 'Çene Sakalı', short: 'Kısa Sakal',
      full: 'Gür Sakal', sideburns: 'Favori', vandyke: 'Van Dyke',
      chinstrap: 'Çene Bandı Sakal', horseshoe: 'At Nalı Bıyık',
    },
  },
  faceAcc: {
    title: 'Yüz Aksesuarı',
    values: {
      none: 'Yok', sunglasses: 'Güneş Gözlüğü', scar: 'Yara İzi', cigar: 'Puro',
      eyepatch: 'Göz Bandı', mask: 'Kar Maskesi', monocle: 'Monokl',
      freckles: 'Çil', piercing: 'Piercing',
    },
  },
  earring: { title: 'Küpe', values: { yok: 'Yok', sol: 'Sol Kulak', sag: 'Sağ Kulak', cift: 'Çift Kulak' } },
  tattoo: {
    title: 'Dövme',
    values: {
      yok: 'Yok', gozyasi: 'Gözyaşı', yildiz: 'Yıldız', boyunsembol: 'Boyun Sembolü',
      boyunyazi: 'Boyun Yazısı', yuzsembol: 'Yüz Sembolü', kolyazi: 'Boyun Yazısı 2',
    },
  },
  clothing: {
    title: 'Kombin',
    values: {
      suit: 'Takım Elbise', tuxedo: 'Smokin', leather: 'Deri Mont', hawaii: 'Casino Gömleği',
      jumpsuit: 'İşçi Tulumu', hoodie: 'Kapüşonlu', police: 'Polis Üniforması', vest: 'Yelek',
      tanktop: 'Atlet', trenchcoat: 'Pardösü',
    },
  },
  neckAcc: {
    title: 'Boyun Aksesuarı',
    values: { none: 'Yok', tie: 'Kravat', bow: 'Papyon', chain: 'Altın Zincir', scarf: 'Atkı', dogtag: 'Künye' },
  },
  hat: {
    title: 'Baş Aksesuarı',
    values: {
      none: 'Yok', fedora: 'Fötr Şapka', beret: 'Bere', bandana: 'Bandana', cap: 'Kasket',
      crown: 'Patron Tacı', tophat: 'Silindir Şapka', hoodup: 'Kapüşon (Kapalı)', helmet: 'Motor Kaskı',
      policecap: 'Polis Şapkası', beanie: 'Bere (Yünlü)', headband: 'Kafa Bandı',
    },
  },
  heldItem: {
    title: 'Elde Taşınan',
    values: {
      yok: 'Yok', tabanca: 'Tabanca', bicak: 'Bıçak', sopa: 'Beyzbol Sopası', para: 'Para Destesi',
      canta: 'Çanta', telefon: 'Telefon', kadeh: 'Kadeh',
    },
  },
  shoeStyle: {
    title: 'Ayakkabı Modeli',
    values: { klasik: 'Klasik', spor: 'Spor', bot: 'Bot', sandalet: 'Sandalet' },
  },
};

const COLOR_GROUPS = {
  skin: { title: 'Ten Tonu', colors: SKIN_TONES },
  background: { title: 'Arka Plan', colors: BACKGROUND_COLORS },
  eyeColor: { title: 'Göz Rengi', colors: EYE_COLORS },
  lipColor: { title: 'Dudak Rengi', colors: LIP_COLORS },
  hairColor: { title: 'Saç Rengi', colors: HAIR_COLORS },
  clothColor: { title: 'Kıyafet Rengi', colors: CLOTH_COLORS },
  hatColor: { title: 'Aksesuar Rengi', colors: HAT_COLORS },
  pantsColor: { title: 'Pantolon Rengi', colors: PANTS_COLORS },
  shoeColor: { title: 'Ayakkabı Rengi', colors: SHOE_COLORS },
};

const ROW_ORDER = [
  { type: 'option', field: 'gender' },
  { type: 'option', field: 'build' },
  { type: 'option', field: 'faceShape' },
  { type: 'color', field: 'skin' },
  { type: 'color', field: 'background' },
  { type: 'option', field: 'eyebrowShape' },
  { type: 'option', field: 'eyeShape' },
  { type: 'color', field: 'eyeColor' },
  { type: 'option', field: 'eyelash' },
  { type: 'option', field: 'noseShape' },
  { type: 'option', field: 'mouthShape' },
  { type: 'color', field: 'lipColor' },
  { type: 'option', field: 'hairStyle' },
  { type: 'color', field: 'hairColor' },
  { type: 'option', field: 'facialHair' },
  { type: 'option', field: 'faceAcc' },
  { type: 'option', field: 'earring' },
  { type: 'option', field: 'tattoo' },
  { type: 'option', field: 'clothing' },
  { type: 'color', field: 'clothColor' },
  { type: 'color', field: 'pantsColor' },
  { type: 'option', field: 'shoeStyle' },
  { type: 'color', field: 'shoeColor' },
  { type: 'option', field: 'neckAcc' },
  { type: 'option', field: 'hat' },
  { type: 'color', field: 'hatColor' },
  { type: 'option', field: 'heldItem' },
];

function OptionRow({ title, values, current, onSelect }) {
  return (
    <div className="avb-row">
      <p className="avb-row-title">{title}</p>
      <div className="avb-opt-grid">
        {Object.entries(values).map(([val, label]) => (
          <button
            key={val}
            className={`avb-opt-btn${current === val ? ' active' : ''}`}
            onClick={() => onSelect(val)}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}

function ColorRow({ title, colors, current, onSelect }) {
  return (
    <div className="avb-row">
      <p className="avb-row-title">{title}</p>
      <div className="avb-swatch-grid">
        {colors.map((c) => (
          <button
            key={c}
            className={`avb-swatch${current === c ? ' active' : ''}`}
            style={{ background: c }}
            onClick={() => onSelect(c)}
          />
        ))}
      </div>
    </div>
  );
}

function randomFrom(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

export default function AvatarBuilder({ onBack }) {
  const { player } = usePlayer();
  const [avatar, setLocalAvatar] = useState(DEFAULT_AVATAR);
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);
  const [ok, setOk] = useState(false);
  // Tam vücut önizlemesinde yürüyüşü test edebilmek için: kullanıcı
  // "Yürüyüşü Dene" butonuna basınca 'walk1'/'walk2' karelerini
  // değiştirerek basit bir animasyon oynatıyoruz (ParkWorld'de
  // kullanılacak aynı iki kare).
  const [walking, setWalking] = useState(false);
  const [walkFrame, setWalkFrame] = useState('idle');
  useEffect(() => {
    if (!walking) {
      setWalkFrame('idle');
      return undefined;
    }
    const id = setInterval(() => {
      setWalkFrame((prev) => (prev === 'walk1' ? 'walk2' : 'walk1'));
    }, 260);
    return () => clearInterval(id);
  }, [walking]);

  // player Firestore'dan ASENKRON geliyor — component ilk mount olduğunda
  // henüz yüklenmemiş olabilir. useState'in başlangıç değeri sadece BİR
  // kez okunduğu için, player sonradan gelirse eski koddaki gibi hep
  // DEFAULT_AVATAR'da kalıyordu. Burada player ilk geldiğinde TEK SEFER
  // senkronize ediyoruz; sonraki oturum içi düzenlemeler asla ezilmiyor.
  const syncedOnce = useRef(false);
  useEffect(() => {
    if (!syncedOnce.current && player) {
      if (player.avatar) setLocalAvatar(player.avatar);
      syncedOnce.current = true;
    }
  }, [player]);

  const update = (field, value) => setLocalAvatar((prev) => ({ ...prev, [field]: value }));

  const randomize = () => {
    const next = { ...DEFAULT_AVATAR };
    Object.entries(AVATAR_OPTIONS).forEach(([field, values]) => {
      next[field] = randomFrom(values);
    });
    next.skin = randomFrom(SKIN_TONES);
    next.background = randomFrom(BACKGROUND_COLORS);
    next.eyeColor = randomFrom(EYE_COLORS);
    next.lipColor = randomFrom(LIP_COLORS);
    next.hairColor = randomFrom(HAIR_COLORS);
    next.clothColor = randomFrom(CLOTH_COLORS);
    next.hatColor = randomFrom(HAT_COLORS);
    next.pantsColor = randomFrom(PANTS_COLORS);
    next.shoeColor = randomFrom(SHOE_COLORS);
    setLocalAvatar(next);
  };

  const handleSave = async () => {
    setBusy(true);
    setError(null);
    setOk(false);
    try {
      await setAvatar(avatar);
      if (name.trim()) {
        await setDisplayName(name.trim());
        setName('');
      }
      setOk(true);
    } catch (err) {
      setError(err.message || 'Kaydedilemedi.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="avb-builder">
      <div className="avb-sticky-header">
        <div className="avb-header-buttons-row">
          <button className="avb-header-btn" onClick={onBack}>
            ← Profil
          </button>
          <button className="avb-header-btn primary" disabled={busy} onClick={handleSave}>
            {busy ? '…' : '💾 Kaydet'}
          </button>
        </div>
        <div className="avb-header-preview">
          <AvatarSvg avatar={avatar} variant="full" pose={walkFrame} />
        </div>
      </div>

      {/* v78: takılı aksesuar aynı yuvadaki avatar parçasını gizler */}
      {(avatar?.acc?.head || avatar?.acc?.face || avatar?.acc?.neck) && (
        <p className="avb-acc-note">
          🐾 Takılı aksesuarın var: {[avatar.acc.head && 'şapka', avatar.acc.face && 'yüz aksesuarı', avatar.acc.neck && 'boyun aksesuarı'].filter(Boolean).join(', ')} seçimin aksesuarı çıkarınca görünür (Profil › Aksesuarlar).
        </p>
      )}
      {ok && <p className="avb-success">Kaydedildi!</p>}
      {error && <p className="avb-error">{error}</p>}

      <div className="avb-header-buttons-row">
        <button className="avb-random-btn" onClick={randomize}>
          🎲 Rastgele
        </button>
        <button className="avb-header-btn" onClick={() => setWalking((w) => !w)}>
          {walking ? '⏹ Durdur' : '🚶 Yürüyüşü Dene'}
        </button>
      </div>

      <div className="avb-row">
        <p className="avb-row-title">Kod Adı (Oyun İçi İsmin)</p>
        <p className="avb-hint">
          Şu anki adın: <strong>{player?.displayName || '—'}</strong>
        </p>
        <input
          type="text"
          className="avb-name-input"
          placeholder="ör. KARA YILMAZ"
          value={name}
          onChange={(e) => setName(e.target.value)}
          maxLength={20}
        />
      </div>

      {ROW_ORDER.map(({ type, field }) => {
        if (type === 'option') {
          const { title, values } = OPTION_LABELS[field];
          return (
            <OptionRow
              key={field}
              title={title}
              values={values}
              current={avatar[field]}
              onSelect={(v) => update(field, v)}
            />
          );
        }
        const { title, colors } = COLOR_GROUPS[field];
        return (
          <ColorRow
            key={field}
            title={title}
            colors={colors}
            current={avatar[field]}
            onSelect={(v) => update(field, v)}
          />
        );
      })}
    </div>
  );
}
