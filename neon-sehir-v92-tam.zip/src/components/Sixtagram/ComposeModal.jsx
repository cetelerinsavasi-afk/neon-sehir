import { useEffect, useMemo, useState } from 'react';
import { X } from 'lucide-react';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../../firebase';
import { usePlayer } from '../../hooks/usePlayer';
import { useVehicles } from '../../hooks/useVehicles';
import { useRecentFutbolBets } from '../../hooks/useRecentFutbolBets';
import { useTodayFootballMatches } from '../../hooks/useTodayFootballMatches';
import { useLeagueLastMatches } from '../../hooks/useLeagueLastMatches';
import { useFutbolLeagues } from '../../hooks/useFutbolLeagues';
import { useFutbolTeams } from '../../hooks/useFutbolTeams';
import { useFutbolMatches } from '../../hooks/useFutbolMatches';
import { ROUND_LABELS as CUP_ROUND_LABELS } from '../FutbolScreen/FutbolCupBetting';
import { useInvestmentHistory } from '../../hooks/useInvestmentHistory';
import { useInvestmentPrices } from '../../hooks/useInvestmentPrices';
import { useMessages } from '../../hooks/useMessages';
import { useLottery } from '../../hooks/useLottery';
import { useFlappyLeaderboard, useMyFlappyBest } from '../../hooks/useFlappyBird';
import { useInventory } from '../../hooks/useInventory';
import { useAuth } from '../../contexts/AuthContext';
import { vehicleImage, vehicleDisplayName } from '../VehicleCard/VehicleCard';
import { createSixtagramPost } from '../../services/gameActions';
import { INTERVIEW_LOCATIONS } from '../../lib/interviewLocations';
import PostAttachment from './PostAttachment';
import DrawingPad from './DrawingPad';
import './ComposeModal.css';

const MAX_LEN = 280;
// INTERVIEW_MAX_LEN — functions/index.js'teki INTERVIEW_MAX_TEXT_LEN ile
// AYNI (madde 1: RÖPORTAJ). Sunucu zaten kendi tarafında kırpıyor, bu
// sadece karaktör sayacı için istemci tarafı ikizi.
const INTERVIEW_MAX_LEN = 500;

const ASSET_OPTIONS = [
  { id: 'diamond', label: 'Elmas', field: 'diamondPrice' },
  { id: 'stock', label: 'Hisse Senedi', field: 'stockPrice' },
  { id: 'crypto', label: 'Kripto', field: 'cryptoPrice' },
];

// SIXTAGRAM_MATERIAL_LABELS — functions/index.js'teki AYNI sabitin
// istemci tarafı ikizi (SADECE önizleme için — gerçek veri/etiketler
// yine sunucudan gelir, bkz. buildSixtagramAttachment).
const SIXTAGRAM_MATERIAL_LABELS = {
  tamirMalzemesi: { label: 'Tamir Malzemesi', emoji: '🔧' },
  silahUpgrade: { label: 'Silah Geliştirme Malzemesi', emoji: '🔫' },
  arabaGelistirme: { label: 'Araba Geliştirme Malzemesi', emoji: '🚗' },
  yasakliMadde: { label: 'Yasaklı Madde', emoji: '💊' },
};

function istanbulDateKeyOffset(offsetDays) {
  return new Intl.DateTimeFormat('en-CA', {
    timeZone: 'Europe/Istanbul',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
  }).format(new Date(Date.now() + offsetDays * 24 * 60 * 60 * 1000));
}

export default function ComposeModal({ onClose, onPosted }) {
  const [text, setText] = useState('');
  const [pickerOpen, setPickerOpen] = useState(false);
  // subPicker: 'vehicle' | 'iddaa' | 'investment' | 'upcomingMatches' | 'lastMatches' | 'interview' | null
  const [subPicker, setSubPicker] = useState(null);
  // interviewLocationId/interviewText — RÖPORTAJ (madde 1) taslağı: mekan +
  // söylenecek metin seçimi, "Devam" ile attachmentDraft'a dönüşür.
  const [interviewLocationId, setInterviewLocationId] = useState(null);
  const [interviewText, setInterviewText] = useState('');
  const [pendingLeagueId, setPendingLeagueId] = useState(null);
  const [pendingLastMatchesLeagueId, setPendingLastMatchesLeagueId] = useState(null);
  // attachmentDraft — SUNUCUYA gidecek minimal seçim (örn. { type:
  // 'vehicle', vehicleId }). Sunucu gerçek veriyi kendisi okuyup
  // doğrulayarak gömer (bkz. functions/index.js buildSixtagramAttachment).
  const [attachmentDraft, setAttachmentDraft] = useState(null);
  // attachmentPreview — SADECE burada, istemcide, "paylaşmadan önce nasıl
  // görüneceğini" göstermek için — zaten elimizdeki canlı veriden inşa
  // edilir, PostAttachment'ın beklediği şekille birebir aynı.
  const [attachmentPreview, setAttachmentPreview] = useState(null);
  const [error, setError] = useState('');
  const [posting, setPosting] = useState(false);
  const [betPreviewLoading, setBetPreviewLoading] = useState(false);
  // v72 — "Resim Çiz" editörü (null = kapalı; {} = yeni tuval; çizim = düzenle)
  const [drawing, setDrawing] = useState(null);

  const { user } = useAuth();
  const { player } = usePlayer();
  const { vehicles: allVehicles } = useVehicles();
  // Kullanıcı revizesi: "sixtagramda arabamı paylaşmak istediğimde de
  // sattığım arabalar listeleniyor" — 2. elde listelenmiş (satılmış veya
  // satışa çıkarılmış) araçlar artık elimizde fiilen yok, seçim listesinde
  // gösterilmemeli (bkz. HomeScreen.jsx'teki aynı `!v.listed` filtresi).
  const vehicles = allVehicles.filter((v) => !v.listed);
  const { bets } = useRecentFutbolBets();
  const { matches: todayMatches } = useTodayFootballMatches();
  const { leagues } = useFutbolLeagues();  const { history: investmentHistory } = useInvestmentHistory();
  const { prices: investmentPrices } = useInvestmentPrices();
  const { messages } = useMessages();
  const { yesterday: lotteryYesterday } = useLottery();
  const { best: flappyBest } = useMyFlappyBest();
  const { inventory } = useInventory();
  // flappyTop10 — SADECE önizleme için: ilk 10'un TAMAMI dolu geldiyse
  // (yani ortada en az 10 farklı oyuncu var demektir) ve kendi uid'im bu
  // listedeyse, sırayı orada bulunduğum index+1 olarak tahmin ediyoruz.
  // GERÇEK/nihai sıra yine sunucuda (buildSixtagramAttachment,
  // flappyScores üzerinde sayım sorgusuyla) hesaplanır — bu sadece
  // paylaşmadan önceki önizlemenin sunucuyla aynı görünmesi için.
  const { top10: flappyTop10 } = useFlappyLeaderboard();

  const pendingLeague = leagues.find((l) => l.id === pendingLeagueId) || null;
  const { teams: pendingTeams } = useFutbolTeams(pendingLeagueId);
  const { matches: pendingLeagueMatches, loading: pendingMatchesLoading } = useFutbolMatches(
    pendingLeagueId,
    pendingLeague?.season
  );

  const pendingLastMatchesLeague = leagues.find((l) => l.id === pendingLastMatchesLeagueId) || null;
  const { matches: pendingLastMatches, loading: pendingLastMatchesLoading } =
    useLeagueLastMatches(pendingLastMatchesLeagueId);

  const pendingUpcoming = useMemo(() => {
    if (!pendingLeague) return null;
    const round = pendingLeague.currentRound || 1;
    const scheduled = pendingLeagueMatches
      .filter((m) => m.round === round && m.status === 'scheduled')
      .slice(0, 4);
    if (!scheduled.length) return [];
    const teamById = Object.fromEntries(pendingTeams.map((t) => [t.id, t]));
    return scheduled.map((m) => ({
      homeName: teamById[m.homeTeamId]?.name || '?',
      awayName: teamById[m.awayTeamId]?.name || '?',
      homeLogo: teamById[m.homeTeamId]?.logo || null,
      awayLogo: teamById[m.awayTeamId]?.logo || null,
    }));
  }, [pendingLeague, pendingLeagueMatches, pendingTeams]);

  // pendingLeagueId seçilip veri geldiğinde otomatik olarak eki oluştur.
  useEffect(() => {
    if (!pendingLeagueId || !pendingLeague || pendingMatchesLoading) return;
    if (pendingUpcoming === null) return;
    if (pendingUpcoming.length === 0) return; // boşsa kullanıcı başka lig seçsin
    setAttachmentDraft({ type: 'upcomingMatches', leagueId: pendingLeagueId });
    setAttachmentPreview({
      type: 'upcomingMatches',
      leagueName: pendingLeague.name,
      round: pendingLeague.currentRound || 1,
      matches: pendingUpcoming,
    });
    setSubPicker(null);
    setPickerOpen(false);
    setPendingLeagueId(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingLeagueId, pendingLeague, pendingMatchesLoading, pendingUpcoming]);

  // pendingLastMatchesLeagueId seçilip veri geldiğinde otomatik olarak
  // eki oluştur (yukarıdakiyle aynı desen, "Sıradaki Maçlar" yerine
  // "Son Oynanan Maçlar" için).
  useEffect(() => {
    if (!pendingLastMatchesLeagueId || !pendingLastMatchesLeague || pendingLastMatchesLoading) return;
    if (pendingLastMatches.length === 0) return; // boşsa kullanıcı başka lig seçsin
    setAttachmentDraft({ type: 'lastMatches', leagueId: pendingLastMatchesLeagueId });
    setAttachmentPreview({
      type: 'lastMatches',
      leagueName: pendingLastMatchesLeague.name,
      matches: pendingLastMatches.map((m) => ({
        homeName: m.homeName,
        awayName: m.awayName,
        homeScore: m.homeScore,
        awayScore: m.awayScore,
        homeLogo: m.homeLogo || null,
        awayLogo: m.awayLogo || null,
      })),
    });
    setSubPicker(null);
    setPickerOpen(false);
    setPendingLastMatchesLeagueId(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pendingLastMatchesLeagueId, pendingLastMatchesLeague, pendingLastMatchesLoading, pendingLastMatches]);

  const todayDateKey = istanbulDateKeyOffset(0);
  const yesterdayDateKey = istanbulDateKeyOffset(-1);
  const recentFines = messages.filter(
    (m) =>
      m.type === 'capture_penalty' &&
      (m.dateKey === todayDateKey || m.dateKey === yesterdayDateKey)
  );

  const avatarAvailable = Boolean(player?.avatar);
  const vehicleAvailable = vehicles.length > 0;
  const iddaaAvailable = bets.length > 0;
  const lastMatchesAvailable = todayMatches.length > 0;
  const fineAvailable = recentFines.length > 0;
  const debtAvailable = (player?.debtToState || 0) > 0;
  // lotteryWinAvailable (madde 9) — dünün piyango kazananı GERÇEKTEN
  // ben miyim (useLottery'nin yesterday'i zaten lottery/{dünün tarihi}
  // dokümanı, sunucudaki AYNI winnerUid alanı).
  const lotteryWinAvailable = Boolean(user && lotteryYesterday?.winnerUid === user.uid && lotteryYesterday?.winnerAmount);
  // flappyScoreAvailable (madde 10) — hiç Flappy Kuş oynamadıysan (rekor
  // 0) paylaşacak bir şey yok.
  const flappyScoreAvailable = flappyBest > 0;
  // KULLANICI İSTEĞİ: "saygınlık seviyemiz, şüphe seviyemiz, elimizdeki
  // para, yatırımlardaki paramız, yaptığımız soygunlar, elimizdeki
  // malzemeler ... paylaşabilelim" — yeni paylaşılabilir istatistik
  // türleri. Saygınlık/şüphe/para her zaman (0 olsa bile) paylaşılabilir;
  // diğerleri (yatırım/soygun/malzeme) paylaşacak bir şey yoksa gizlenir.
  const investmentPortfolioAvailable =
    (player?.diamondHoldings || 0) > 0 || (player?.stockHoldings || 0) > 0 || (player?.cryptoHoldings || 0) > 0;
  const heistAvailable = (player?.heistSuccessCount || 0) > 0;
  const materialsAvailable = Object.values(inventory || {}).some((qty) => qty > 0);

  const ATTACHMENT_TYPES = [
    // "Röportaj Yap" — KULLANICI İSTEĞİ: görsel ekle seçeneklerinin en
    // üstünde olacak, bu yüzden listenin ilk elemanı (madde 1).
    // v72 — boş tuvale çizip tablo paylaş
    { id: 'drawing', label: 'Resim Çiz', emoji: '🎨', available: true },
    { id: 'interview', label: 'Röportaj Yap', emoji: '🎤', available: avatarAvailable },
    { id: 'avatar', label: 'Avatarım', emoji: '🧑', available: avatarAvailable },
    { id: 'vehicle', label: 'Arabam', emoji: '🚗', available: vehicleAvailable },
    { id: 'iddaa', label: 'İddaa Kuponum', emoji: '🎟️', available: iddaaAvailable },
    { id: 'lastMatches', label: 'Son Oynanan Maçlar', emoji: '⚽', available: lastMatchesAvailable },
    { id: 'upcomingMatches', label: 'Sıradaki Maçlar', emoji: '🔜', available: leagues.length > 0 },
    { id: 'reputation', label: 'Saygınlığım', emoji: '🌟', available: true },
    { id: 'suspicion', label: 'Şüphe Seviyem', emoji: '🚔', available: true },
    { id: 'gold', label: 'Param', emoji: '💰', available: true },
    { id: 'investmentPortfolio', label: 'Yatırım Portföyüm', emoji: '💹', available: investmentPortfolioAvailable },
    { id: 'heist', label: 'Soygunlarım', emoji: '🥷', available: heistAvailable },
    { id: 'materials', label: 'Malzemelerim', emoji: '📦', available: materialsAvailable },
    { id: 'investment', label: 'Yatırım Grafiği', emoji: '📈', available: true },
    { id: 'fine', label: 'Cezam', emoji: '🚨', available: fineAvailable },
    { id: 'debt', label: 'Toplam Borcum', emoji: '💸', available: debtAvailable },
    { id: 'lotteryWin', label: 'Piyango Kazancım', emoji: '🏆', available: lotteryWinAvailable },
    { id: 'flappyScore', label: 'Flappy Kuş Rekorum', emoji: '🐦', available: flappyScoreAvailable },
  ];

  const setAttachment = (draft, preview) => {
    setAttachmentDraft(draft);
    setAttachmentPreview(preview);
    setSubPicker(null);
    setPickerOpen(false);
  };

  const chooseType = (typeId) => {
    setError('');
    if (typeId === 'drawing') {
      setDrawing(attachmentDraft?.type === 'drawing' ? attachmentDraft : {});
      setPickerOpen(false);
      return;
    }
    if (typeId === 'vehicle' || typeId === 'iddaa' || typeId === 'investment') {
      setSubPicker(typeId);
      return;
    }
    if (typeId === 'interview') {
      setSubPicker('interview');
      setInterviewLocationId(null);
      setInterviewText('');
      return;
    }
    if (typeId === 'upcomingMatches') {
      setSubPicker('upcomingMatches');
      setPendingLeagueId(null);
      return;
    }
    if (typeId === 'lastMatches') {
      setSubPicker('lastMatches');
      setPendingLastMatchesLeagueId(null);
      return;
    }
    if (typeId === 'avatar') {
      setAttachment({ type: 'avatar' }, { type: 'avatar', avatar: player.avatar });
      return;
    }
    if (typeId === 'fine') {
      const totalAmount = recentFines.reduce((sum, m) => sum + (m.penaltyAmount || 0), 0);
      setAttachment({ type: 'fine' }, { type: 'fine', totalAmount, count: recentFines.length });
      return;
    }
    if (typeId === 'debt') {
      setAttachment(
        { type: 'debt' },
        { type: 'debt', amount: player?.debtToState || 0 }
      );
      return;
    }
    if (typeId === 'lotteryWin') {
      setAttachment(
        { type: 'lotteryWin' },
        { type: 'lotteryWin', amount: lotteryYesterday?.winnerAmount || 0 }
      );
      return;
    }
    if (typeId === 'flappyScore') {
      const idx = user ? flappyTop10.findIndex((s) => s.id === user.uid) : -1;
      const rankPreview = idx !== -1 && flappyTop10.length >= 10 ? idx + 1 : null;
      setAttachment(
        { type: 'flappyScore' },
        { type: 'flappyScore', score: flappyBest, rank: rankPreview }
      );
      return;
    }
    if (typeId === 'reputation') {
      setAttachment({ type: 'reputation' }, { type: 'reputation', value: player?.reputation || 0 });
      return;
    }
    if (typeId === 'suspicion') {
      setAttachment({ type: 'suspicion' }, { type: 'suspicion', value: player?.suspicion || 0 });
      return;
    }
    if (typeId === 'gold') {
      setAttachment({ type: 'gold' }, { type: 'gold', amount: player?.gold || 0 });
      return;
    }
    if (typeId === 'investmentPortfolio') {
      // Önizleme sunucudaki (buildSixtagramAttachment) AYNI hesabın
      // istemci tarafı ikizi — gerçek/nihai değer yine sunucuda okunur.
      let totalValue = 0;
      let totalCostBasis = 0;
      const breakdown = ASSET_OPTIONS.map(({ id: asset, label: assetLabel }) => {
        const holdingsField = { diamond: 'diamondHoldings', stock: 'stockHoldings', crypto: 'cryptoHoldings' }[asset];
        const costBasisField = { diamond: 'diamondCostBasis', stock: 'stockCostBasis', crypto: 'cryptoCostBasis' }[asset];
        const priceField = { diamond: 'diamondPrice', stock: 'stockPrice', crypto: 'cryptoPrice' }[asset];
        const holdings = player?.[holdingsField] || 0;
        const value = holdings * (investmentPrices?.[priceField] || 0);
        totalValue += value;
        totalCostBasis += player?.[costBasisField] || 0;
        return { asset, assetLabel, holdings, value };
      });
      setAttachment(
        { type: 'investmentPortfolio' },
        {
          type: 'investmentPortfolio',
          totalValue: Math.round(totalValue),
          totalCostBasis: Math.round(totalCostBasis),
          gain: Math.round(totalValue - totalCostBasis),
          breakdown,
        }
      );
      return;
    }
    if (typeId === 'heist') {
      setAttachment(
        { type: 'heist' },
        { type: 'heist', count: player?.heistSuccessCount || 0, totalEarnings: player?.heistTotalEarnings || 0 }
      );
      return;
    }
    if (typeId === 'materials') {
      const items = Object.entries(inventory || {})
        .filter(([, qty]) => qty > 0)
        .map(([materialType, quantity]) => ({
          materialType,
          quantity,
          ...(SIXTAGRAM_MATERIAL_LABELS[materialType] || { label: materialType, emoji: '📦' }),
        }))
        .sort((a, b) => b.quantity - a.quantity);
      setAttachment({ type: 'materials' }, { type: 'materials', items });
    }
  };

  const chooseVehicle = (vehicle) => {
    setAttachment(
      { type: 'vehicle', vehicleId: vehicle.id },
      {
        type: 'vehicle',
        catalogId: vehicle.catalogId,
        model: vehicleDisplayName(vehicle),
        gearLevel: vehicle.gearLevel,
        gearUpgraded: !!vehicle.gearUpgraded,
        tankUpgraded: !!vehicle.tankUpgraded,
        lifeDays: vehicle.lifeDays ?? null,
      }
    );
  };

  // chooseBet — hem lig hem kupa kuponu için AYNI akış (KULLANICI İSTEĞİ:
  // "kupa maçıyla alakalı her şeyi neden lig maçlarından farklı yapmak
  // zorunda hissediyorsun"). `bet.isCup` (bkz. useRecentFutbolBets) hangi
  // koleksiyondan geldiğini söylüyor — önizleme için maç/takım verisi FARKLI
  // koleksiyonlardan okunuyor ama sonuçta AYNI şekle (predictions[]) dönüşüyor.
  const chooseBet = async (bet) => {
    setError('');
    setSubPicker(null);
    setPickerOpen(false);
    setAttachmentDraft({ type: 'iddaa', betId: bet.id });
    setBetPreviewLoading(true);
    // Kuponun GERÇEK içeriğini (maç isimleri + tahminler + varsa sonuç)
    // burada da çekiyoruz ki "sonuç bekleyen" bir kupon bile paylaşmadan
    // önce tam olarak nasıl görüneceğini göstersin — sunucu tarafındaki
    // buildSixtagramAttachment ile aynı mantık, sadece istemcide.
    try {
      // KULLANICI REVİZESİ (Çoklu Maç Kuponu): kupon artık 1 ya da daha
      // fazla maça yapılmış bir bahis olabilir (bet.selections) — bu
      // revizeden ÖNCEKİ tekil (bet.matchId/bet.pick) eski kuponlarla da
      // uyumlu olsun diye ikisini de tek bir "predictionList" haline
      // normalize ediyoruz (functions/index.js'teki futbolBetSelections ile
      // AYNI mantık, istemci tarafı ikizi).
      const predictionList =
        Array.isArray(bet.selections) && bet.selections.length > 0
          ? bet.selections
          : bet.matchId
            ? [{ matchId: bet.matchId, pick: bet.pick }]
            : [];

      let predictions;
      let leagueName;
      let roundLabel;

      if (bet.isCup) {
        // Kupa maçı dokümanı (futbolCupMatches) takım adını/skorunu zaten
        // kendi üstünde taşıyor — ayrı bir futbolTeams join'i gerekmiyor.
        const matchSnaps = await Promise.all(
          predictionList.map((p) => getDoc(doc(db, 'futbolCupMatches', p.matchId)))
        );
        const matchById = {};
        matchSnaps.forEach((s) => {
          if (s.exists()) matchById[s.id] = s.data();
        });
        leagueName = 'Neon Kupası';
        roundLabel = CUP_ROUND_LABELS[bet.round] || bet.round;
        predictions = predictionList.map((p) => {
          const m = matchById[p.matchId] || {};
          // Kupa maçında beraberlik yok — eşitlik penaltılara gidip
          // winnerTeamId'yi belirliyor (bkz. functions/index.js
          // futbolCupMatchOutcome), skor karşılaştırması değil bu kullanılıyor.
          let correct = null;
          if (m.status === 'finished' && m.winnerTeamId) {
            const outcome = m.winnerTeamId === m.homeTeamId ? 'home' : 'away';
            correct = outcome === p.pick;
          }
          return {
            homeName: m.homeTeamName || '?',
            awayName: m.awayTeamName || '?',
            pick: p.pick,
            homeScore: m.status === 'finished' ? m.homeScore : null,
            awayScore: m.status === 'finished' ? m.awayScore : null,
            correct,
          };
        });
      } else {
        const leagueSnap = await getDoc(doc(db, 'futbolLeagues', bet.leagueId));
        const matchSnaps = await Promise.all(
          predictionList.map((p) => getDoc(doc(db, 'futbolMatches', p.matchId)))
        );
        const matchById = {};
        matchSnaps.forEach((s) => {
          if (s.exists()) matchById[s.id] = s.data();
        });
        const teamIds = new Set();
        matchSnaps.forEach((s) => {
          if (s.exists()) {
            teamIds.add(s.data().homeTeamId);
            teamIds.add(s.data().awayTeamId);
          }
        });
        const teamSnaps = await Promise.all(
          [...teamIds].map((id) => getDoc(doc(db, 'futbolTeams', id)))
        );
        const teamById = {};
        teamSnaps.forEach((s) => {
          if (s.exists()) teamById[s.id] = s.data();
        });

        leagueName = leagueSnap.exists() ? leagueSnap.data().name || null : null;
        roundLabel = bet.round;
        predictions = predictionList.map((p) => {
          const m = matchById[p.matchId] || {};
          const home = teamById[m.homeTeamId] || {};
          const away = teamById[m.awayTeamId] || {};
          let correct = null;
          if (m.status === 'finished' && m.homeScore != null && m.awayScore != null) {
            const actual =
              m.homeScore === m.awayScore ? 'draw' : m.homeScore > m.awayScore ? 'home' : 'away';
            correct = actual === p.pick;
          }
          return {
            homeName: home.name || '?',
            awayName: away.name || '?',
            pick: p.pick,
            homeScore: m.status === 'finished' ? m.homeScore : null,
            awayScore: m.status === 'finished' ? m.awayScore : null,
            correct,
          };
        });
      }

      setAttachmentPreview({
        type: 'iddaa',
        isCup: !!bet.isCup,
        leagueName,
        round: roundLabel,
        stake: bet.stake,
        status: bet.status,
        payout: bet.payout || 0,
        odds: bet.odds ?? null,
        potentialPayout: bet.potentialPayout ?? null,
        predictions,
      });
    } catch (err) {
      console.error('Kupon önizleme hatası:', err);
      // Önizleme yüklenemese bile paylaşım engellenmesin — sunucu
      // paylaşırken içeriği zaten kendisi doğru şekilde üretecek.
      setAttachmentPreview({
        type: 'iddaa',
        isCup: !!bet.isCup,
        leagueName: null,
        round: bet.isCup ? CUP_ROUND_LABELS[bet.round] || bet.round : bet.round,
        stake: bet.stake,
        status: bet.status,
        payout: bet.payout || 0,
        odds: bet.odds ?? null,
        potentialPayout: bet.potentialPayout ?? null,
        predictions: [],
      });
    } finally {
      setBetPreviewLoading(false);
    }
  };

  const chooseAsset = (asset) => {
    const points = investmentHistory
      .map((h) => h[asset.field])
      .filter((p) => typeof p === 'number');
    const current = investmentPrices[asset.field] ?? points[points.length - 1] ?? 0;
    setAttachment(
      { type: 'investment', asset: asset.id },
      { type: 'investment', asset: asset.id, assetLabel: asset.label, current, points }
    );
  };

  // confirmInterview — RÖPORTAJ (madde 1) taslağını (mekan + metin)
  // attachmentDraft'a dönüştürür. Önizleme, "Avatarım" ekiyle AYNI mantıkla
  // (bkz. chooseType('avatar')) elimizdeki player.avatar/displayName'den
  // kuruluyor — GERÇEK/nihai veri yine sunucuda okunup gömülüyor (bkz.
  // functions/index.js buildSixtagramAttachment, type === 'interview').
  const confirmInterview = () => {
    const cleanText = interviewText.trim().slice(0, INTERVIEW_MAX_LEN);
    if (!interviewLocationId || !cleanText) return;
    setAttachment(
      { type: 'interview', locationId: interviewLocationId, text: cleanText },
      {
        type: 'interview',
        locationId: interviewLocationId,
        text: cleanText,
        avatar: player?.avatar || null,
        displayName: player?.displayName || 'Oyuncu',
      }
    );
  };

  const removeAttachment = () => {
    setAttachmentDraft(null);
    setAttachmentPreview(null);
  };

  const handleSubmit = async () => {
    if (!text.trim() && !attachmentDraft) {
      setError('Bir şeyler yaz ya da bir ek ekle.');
      return;
    }
    setError('');
    setPosting(true);
    try {
      await createSixtagramPost(text.trim(), attachmentDraft);
      onPosted?.();
      onClose();
    } catch (err) {
      console.error('Sixtagram paylaşım hatası:', err);
      setError(err.message || 'Paylaşılamadı, tekrar dene.');
    } finally {
      setPosting(false);
    }
  };

  return (
    <div className="six-compose-backdrop" onClick={onClose}>
      <div className="six-compose" onClick={(e) => e.stopPropagation()}>
        <div className="six-compose-head">
          <p className="six-compose-title">Yeni Gönderi</p>
          <button className="six-compose-close" onClick={onClose}>
            <X size={18} />
          </button>
        </div>

        <textarea
          className="six-compose-textarea"
          placeholder="Neler oluyor?"
          value={text}
          maxLength={MAX_LEN}
          onChange={(e) => setText(e.target.value)}
          rows={4}
        />
        <p className="six-compose-counter">
          {text.length}/{MAX_LEN}
        </p>

        {attachmentPreview && (
          <div className="six-compose-preview">
            <div className="six-compose-preview-head">
              <span>Önizleme</span>
              <button className="six-compose-remove-btn" onClick={removeAttachment}>
                <X size={14} /> Kaldır
              </button>
            </div>
            {attachmentPreview.type === 'drawing' && (
              <button className="six-compose-remove-btn six-compose-edit-drawing" onClick={() => setDrawing(attachmentDraft)}>
                ✏️ Çizimi düzenle
              </button>
            )}
            {betPreviewLoading && attachmentPreview.type === 'iddaa' ? (
              <p className="six-compose-note">Kupon yükleniyor…</p>
            ) : (
              <PostAttachment attachment={attachmentPreview} />
            )}
          </div>
        )}

        {error && <p className="six-compose-error">{error}</p>}

        <div className="six-compose-footer">
          <button className="six-compose-image-btn" onClick={() => setPickerOpen((v) => !v)}>
            🖼️ Görsel Ekle
          </button>
          <button className="six-compose-submit" onClick={handleSubmit} disabled={posting}>
            {posting ? 'Paylaşılıyor…' : 'Paylaş'}
          </button>
        </div>

        {pickerOpen && !subPicker && (
          <div className="six-compose-picker">
            {ATTACHMENT_TYPES.map((t) => (
              <button
                key={t.id}
                className="six-compose-picker-item"
                disabled={!t.available}
                onClick={() => chooseType(t.id)}
              >
                <span className="six-compose-picker-emoji">{t.emoji}</span>
                <span>{t.label}</span>
                {!t.available && <span className="six-compose-picker-none">yok</span>}
              </button>
            ))}
            {!lastMatchesAvailable && (
              <p className="six-compose-sublist-empty">
                "Son Oynanan Maçlar" henüz hiç maç sonuçlanmadıysa (oyunun ilk gününde, 19:00'dan
                önce) görünmez — bir maç sonuçlandıktan sonra bir sonraki gün 19:00'a kadar (24
                saat boyunca) burada kalır.
              </p>
            )}
          </div>
        )}

        {subPicker === 'interview' && (
          <div className="six-compose-sublist">
            <p className="six-compose-sublist-title">Röportajı hangi mekanda yapıyorsun?</p>
            <div className="six-compose-location-grid">
              {INTERVIEW_LOCATIONS.map((loc) => (
                <button
                  key={loc.id}
                  className={`six-compose-location-btn${interviewLocationId === loc.id ? ' active' : ''}`}
                  onClick={() => setInterviewLocationId(loc.id)}
                >
                  <span className="six-compose-location-emoji">{loc.emoji}</span>
                  <span>{loc.label}</span>
                </button>
              ))}
            </div>
            <p className="six-compose-sublist-title">Röportajda ne söylemek istiyorsun?</p>
            <textarea
              className="six-compose-textarea six-compose-interview-textarea"
              placeholder="Röportajda söylemek istediğin şeyi yaz..."
              value={interviewText}
              maxLength={INTERVIEW_MAX_LEN}
              onChange={(e) => setInterviewText(e.target.value)}
              rows={4}
            />
            <p className="six-compose-counter">
              {interviewText.length}/{INTERVIEW_MAX_LEN}
            </p>
            <div className="six-compose-sublist-actions">
              <button className="six-compose-sublist-back" onClick={() => setSubPicker(null)}>
                ← Geri
              </button>
              <button
                className="six-compose-submit"
                disabled={!interviewLocationId || !interviewText.trim()}
                onClick={confirmInterview}
              >
                Röportajı Hazırla
              </button>
            </div>
          </div>
        )}

        {subPicker === 'vehicle' && (
          <div className="six-compose-sublist">
            <p className="six-compose-sublist-title">Hangi araban?</p>
            {vehicles.length === 0 && (
              <p className="six-compose-sublist-empty">Henüz bir araban yok.</p>
            )}
            {vehicles.map((v) => (
              <button key={v.id} className="six-compose-sublist-item" onClick={() => chooseVehicle(v)}>
                {vehicleImage(v.catalogId) && (
                  <img src={vehicleImage(v.catalogId)} alt={vehicleDisplayName(v)} />
                )}
                <span>{vehicleDisplayName(v)}</span>
              </button>
            ))}
            <button className="six-compose-sublist-back" onClick={() => setSubPicker(null)}>
              ← Geri
            </button>
          </div>
        )}

        {subPicker === 'iddaa' && (
          <div className="six-compose-sublist">
            <p className="six-compose-sublist-title">Hangi kupon?</p>
            {bets.length === 0 && (
              <p className="six-compose-sublist-empty">Henüz bir kuponun yok.</p>
            )}
            {bets.map((b) => (
              <button key={b.id} className="six-compose-sublist-item" onClick={() => chooseBet(b)}>
                <span>
                  {b.isCup ? `🏆 ${CUP_ROUND_LABELS[b.round] || b.round}` : `${b.round}. Hafta`} ·{' '}
                  {b.stake.toLocaleString('tr-TR')} altın ·{' '}
                  {b.status === 'pending' ? 'Bekliyor' : b.status === 'won' ? 'Kazandı' : 'Kaybetti'}
                </span>
              </button>
            ))}
            <button className="six-compose-sublist-back" onClick={() => setSubPicker(null)}>
              ← Geri
            </button>
          </div>
        )}

        {subPicker === 'investment' && (
          <div className="six-compose-sublist">
            <p className="six-compose-sublist-title">Hangi piyasa?</p>
            {ASSET_OPTIONS.map((a) => (
              <button key={a.id} className="six-compose-sublist-item" onClick={() => chooseAsset(a)}>
                <span>{a.label}</span>
              </button>
            ))}
            <button className="six-compose-sublist-back" onClick={() => setSubPicker(null)}>
              ← Geri
            </button>
          </div>
        )}

        {subPicker === 'lastMatches' && (
          <div className="six-compose-sublist">
            <p className="six-compose-sublist-title">Hangi lig?</p>
            {pendingLastMatchesLeagueId && (
              <p className="six-compose-sublist-empty">
                {pendingLastMatchesLoading
                  ? 'Yükleniyor…'
                  : pendingLastMatches.length === 0
                    ? 'Bu ligde son 24 saatte sonuçlanan bir maç yok, başka bir lig dene.'
                    : ''}
              </p>
            )}
            {leagues.map((l) => (
              <button
                key={l.id}
                className="six-compose-sublist-item"
                onClick={() => setPendingLastMatchesLeagueId(l.id)}
              >
                <span>{l.name}</span>
              </button>
            ))}
            <button
              className="six-compose-sublist-back"
              onClick={() => {
                setSubPicker(null);
                setPendingLastMatchesLeagueId(null);
              }}
            >
              ← Geri
            </button>
          </div>
        )}

        {subPicker === 'upcomingMatches' && (
          <div className="six-compose-sublist">
            <p className="six-compose-sublist-title">Hangi lig?</p>
            {pendingLeagueId && (
              <p className="six-compose-sublist-empty">
                {pendingMatchesLoading || pendingUpcoming === null
                  ? 'Yükleniyor…'
                  : pendingUpcoming.length === 0
                    ? 'Bu ligde şu an bekleyen maç yok, başka bir lig dene.'
                    : ''}
              </p>
            )}
            {leagues.map((l) => (
              <button
                key={l.id}
                className="six-compose-sublist-item"
                onClick={() => setPendingLeagueId(l.id)}
              >
                <span>{l.name}</span>
              </button>
            ))}
            <button
              className="six-compose-sublist-back"
              onClick={() => {
                setSubPicker(null);
                setPendingLeagueId(null);
              }}
            >
              ← Geri
            </button>
          </div>
        )}
      </div>
      {drawing && (
        <DrawingPad
          initial={drawing}
          onCancel={() => setDrawing(null)}
          onDone={(d) => {
            setDrawing(null);
            setAttachment(d, d);
          }}
        />
      )}
    </div>
  );
}
