import { lazy, Suspense, useEffect, useRef } from 'react';
import AvatarSvg from '../AvatarSvg/AvatarSvg';
import FutbolCrest from '../FutbolScreen/FutbolCrest';
import PriceChart from '../PriceChart/PriceChart';
import '../PriceChart/PriceChart.css';
import { vehicleImage } from '../VehicleCard/VehicleCard';
import { buildFullAvatarSvgMarkup, DEFAULT_AVATAR } from '../../lib/avatarShapes';
import { createAvatarImageCache, renderPhotoFrame as parkRenderPhotoFrame } from '../../lib/parkScene';
import {
  createAvatarImageCache as createAvatarImageCache2, renderPhotoFrame, INTERIOR_AVATAR_SCALE,
} from '../../lib/canvasWorldKit';
import { drawBankSceneBackground } from '../BankWorldScreen/BankWorldScreen';
import { drawKarakolSceneBackground } from '../KarakolWorldScreen/KarakolWorldScreen';
import { drawMosqueSceneBackground } from '../MosqueWorldScreen/MosqueWorldScreen';
import { drawCasinoSceneBackground } from '../CasinoWorldScreen/CasinoWorldScreen';
import { drawDealershipSceneBackground } from '../CarDealershipWorldScreen/CarDealershipWorldScreen';
import { drawWeaponShopSceneBackground } from '../WeaponShopWorldScreen/WeaponShopWorldScreen';
import { drawGarageSceneBackground } from '../TuningGarageWorldScreen/TuningGarageWorldScreen';
import InterviewPlayer from '../Broadcast/InterviewPlayer';
import DrawingView from './DrawingView';
import './PostAttachment.css';
import { vehicleRaceLine } from '../RaceTrackScreen/CarStats';

// v66 — ev fotoğrafı: three.js'i ana pakete sokmamak için tembel yüklenir.
const HousePhoto = lazy(() => import('../HouseScreen/HousePhoto'));

// Tüm parkPhoto kartları arasında paylaşılan avatar görsel önbelleği —
// aynı avatarı tekrar tekrar SVG'den <img>'e çevirmemek için (bkz.
// lib/parkScene.js createAvatarImageCache).
const parkPhotoImageCache = createAvatarImageCache(buildFullAvatarSvgMarkup, DEFAULT_AVATAR, { maxSize: 400 });

// interiorPhoto kartları için ayrı önbellek (parkPhoto'yla karıştırmamak
// için) — aynı jenerik createAvatarImageCache, sadece ayrı bir örnek.
const interiorPhotoImageCache = createAvatarImageCache2(buildFullAvatarSvgMarkup, DEFAULT_AVATAR, { maxSize: 400 });

// locationId -> mekanın kendi drawXxxSceneBackground'ı (bkz. madde 11/12) —
// her mekan zaten kendi WorldScreen dosyasında dışa açık, burada sadece
// eşleniyor; tekrar kod YOK.
// DÜZELTME ("npcler gözükmüyor" hata raporu, Camii): drawMosqueSceneBackground
// diğer mekanlardan farklı olarak imam/dilenci NPC'lerini SABİT/gömülü
// tutmuyor — üçüncü bir `{ imam, beggars }` parametresi bekliyor.
//
// 2. DÜZELTME ("dilencinin/imamın süresi bitince fotoğraftan da kayboluyor"):
// bu `extra` bir ara sürümde useImamState/useBeggars ile CANLI dolduruluyordu
// — bu da paylaşılan (geçmiş) bir fotoğrafın, imam azledilince/dilencinin
// günü bitince ANINDA değişmesine yol açıyordu (fotoğraf hiçbir zaman bir
// "an"ı dondurmuyordu). Artık imam/dilenci verisi fotoğraf ÇEKİLDİĞİ anda
// sunucuda dondurulup doğrudan post'un attachment'ına gömülüyor (bkz.
// functions/index.js buildMosqueNpcSnapshot) — burada SADECE o gömülü veri
// (attachment.imam/attachment.beggars) okunuyor, canlı dinleyici YOK.
const INTERIOR_BACKGROUNDS = {
  banka: (ctx, getAvatarImage) => drawBankSceneBackground(ctx, getAvatarImage),
  karakol: (ctx, getAvatarImage) => drawKarakolSceneBackground(ctx, getAvatarImage),
  camii: (ctx, getAvatarImage, extra) => drawMosqueSceneBackground(ctx, getAvatarImage, extra),
  gazino: (ctx, getAvatarImage) => drawCasinoSceneBackground(ctx, getAvatarImage),
  araba_galerisi: (ctx, getAvatarImage) => drawDealershipSceneBackground(ctx, getAvatarImage),
  silah_magazasi: (ctx, getAvatarImage) => drawWeaponShopSceneBackground(ctx, getAvatarImage),
  modifiye_garaji: (ctx, getAvatarImage) => drawGarageSceneBackground(ctx, getAvatarImage),
};

// v52 DÜZELTME — fotoğraf kareleri:
//  1) Çizim, karedeki TÜM avatarlar yüklenene kadar sürer (eskiden sabit 90
//     kare ≈ 1,5 sn sonra duruyordu; o ana kadar yüklenmeyen avatar hiç
//     görünmüyordu). Güvenlik sınırı ~10 sn; hepsi yüklenince son bir kare
//     daha çizilip durulur.
//  2) Beğeni/yorum gibi etkileşimlerde gönderi belgesi yeniden gelir ve
//     `entities` YENİ bir dizi olur; içerik aynıysa çizim baştan başlatılmaz
//     (eskiden her etkileşimde kare sıfırdan, avatarsız çiziliyordu).
const PHOTO_MAX_FRAMES = 600;
function usePhotoDraw(canvasRef, contentKey, paint) {
  const paintRef = useRef(paint);
  paintRef.current = paint;
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return undefined;
    const ctx = canvas.getContext('2d');
    let raf;
    let frames = 0;
    let settled = 0;
    const draw = () => {
      let missing = false;
      // İzleyen sarmalayıcı: bu karede hazır olmayan avatar var mı?
      const track = (cache) => (avatar, pose) => {
        const img = cache(avatar, pose);
        if (!img) missing = true;
        return img;
      };
      paintRef.current(ctx, canvas, track);
      frames += 1;
      settled = missing ? 0 : settled + 1;
      if (frames < PHOTO_MAX_FRAMES && settled < 2) raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [canvasRef, contentKey]);
}

// InteriorPhotoCanvas — Banka/Karakol/Camii/Gazino'da çekilen fotoğrafı,
// ParkPhotoCanvas'la AYNI mantıkla ama girilebilir mekanın kendi gerçek
// arka planıyla render eder. `extra` — SADECE Camii'nin ihtiyaç duyduğu,
// fotoğraf çekildiği anda DONDURULMUŞ `{ imam, beggars }` verisi (bkz.
// yukarıdaki DÜZELTME notu ve attachment.type === 'interiorPhoto' render'ı),
// diğer mekanlar için `undefined` (kendi NPC'leri zaten gömülü/sabit).
//
// DÜZELTME (genel, TÜM mekanlar): `focalScale` eskiden hiç verilmiyordu,
// yani `renderPhotoFrame`'in varsayılanı (1) kullanılıyordu — oysa her
// mekanın kendi canlı kamera önizlemesi (renderCameraPreview) her zaman
// `AVATAR_SCALE` (INTERIOR_AVATAR_SCALE, 1.42) veriyordu. Bu fark, dikey
// kadraj kaymasına (CAMERA_VERTICAL_LIFT * focalScale) ve kadraj kenarındaki
// NPC'lerin paylaşılan fotoğrafta canlı önizlemedekinden farklı/dışarıda
// kalmasına sebep oluyordu — artık burada da aynı sabit kullanılıyor.
function InteriorPhotoCanvas({ locationId, entities, originX, originY, extra }) {
  const canvasRef = useRef(null);
  const drawBackground = INTERIOR_BACKGROUNDS[locationId];
  const contentKey = JSON.stringify([locationId, entities, originX, originY, extra]);
  usePhotoDraw(canvasRef, contentKey, (ctx, canvas, track) => {
    if (!entities?.length || !drawBackground) return;
    const get = track(interiorPhotoImageCache);
    renderPhotoFrame(ctx, {
      width: canvas.width,
      height: canvas.height,
      originX: originX ?? 0,
      originY: originY ?? 0,
      entities,
      getAvatarImage: get,
      drawBackground: (bgCtx) => drawBackground(bgCtx, get, extra),
      focalScale: INTERIOR_AVATAR_SCALE,
    });
  });

  return <canvas ref={canvasRef} width={320} height={320} className="post-att-parkphoto-canvas" />;
}


// ParkPhotoCanvas — kamera karesini GERÇEK park sahnesinden (aynı
// lib/parkScene.js çizim kodu, ParkWorldScreen'deki canlı önizlemeyle
// BİREBİR aynı) render eder. Avatar SVG'leri ilk açılışta asenkron
// yüklendiği için birkaç kare boyunca yeniden çizip önbelleğin
// dolmasını bekliyoruz, sonra duruyoruz (feed'de çok sayıda kart olsa
// bile sonsuz bir animasyon döngüsü çalıştırmamak için).
function ParkPhotoCanvas({ entities, originX, originY }) {
  const canvasRef = useRef(null);
  const contentKey = JSON.stringify([entities, originX, originY]);
  usePhotoDraw(canvasRef, contentKey, (ctx, canvas, track) => {
    if (!entities?.length) return;
    // DÜZELTME (madde 16): originX/originY artık sunucudan (fotoğrafı
    // çekenin GERÇEK parkPresence konumu) geliyor — eskiden sabit 0,0
    // kullanılıyordu, bu da arka planın her zaman dünya orijinine yakın
    // (parkın üst tarafı) yanlış bir köşeyi göstermesine yol açıyordu.
    parkRenderPhotoFrame(ctx, {
      width: canvas.width,
      height: canvas.height,
      originX: originX ?? 0,
      originY: originY ?? 0,
      entities,
      getAvatarImage: track(parkPhotoImageCache),
      focalScale: INTERIOR_AVATAR_SCALE,
    });
  });

  return <canvas ref={canvasRef} width={320} height={320} className="post-att-parkphoto-canvas" />;
}

// PostAttachment — Sixtagram gönderisine eklenen "görsel"i render eder.
// Hepsi oyunun kendi verisinden (sunucuda doğrulanmış) üretiliyor — dosya
// yükleme YOK, bu yüzden her zaman anında ve tutarlı görünür.
export default function PostAttachment({ attachment }) {
  if (!attachment) return null;

  if (attachment.type === 'avatar') {
    return (
      <div className="post-att post-att-avatar">
        <div className="post-att-avatar-frame">
          <div className="post-att-avatar-inner">
            <AvatarSvg avatar={attachment.avatar} />
          </div>
        </div>
      </div>
    );
  }

  if (attachment.type === 'vehicle') {
    const img = vehicleImage(attachment.catalogId);
    return (
      <div className="post-att post-att-vehicle">
        {img && <img src={img} alt={attachment.model} className="post-att-vehicle-img" />}
        <div className="post-att-vehicle-caption">
          <p className="post-att-vehicle-name">{attachment.model}</p>
          <p className="post-att-vehicle-sub">
            {vehicleRaceLine(attachment)}
          </p>
        </div>
      </div>
    );
  }

  if (attachment.type === 'iddaa') {
    const pickLabel = { home: 'Ev Sahibi', draw: 'Beraberlik', away: 'Deplasman' };
    // KULLANICI İSTEĞİ: "kupa maçıyla alakalı her şeyi neden lig
    // maçlarından farklı yapmak zorunda hissediyorsun" — kupon kartı hem
    // lig hem kupa kuponu için AYNI bileşen; tek fark, kupada `round`
    // sunucudan zaten Türkçe tur adı (ör. "Son 16") olarak geliyor, lig
    // maçında ise haftanın numarası — "N. Hafta" eki SADECE lig için ekleniyor.
    const roundLine = attachment.isCup ? attachment.round : `${attachment.round}. Hafta`;
    return (
      <div className="post-att post-att-card">
        <p className="post-att-card-title">🎟️ İddaa Kuponu</p>
        <p className="post-att-card-line">
          {attachment.leagueName || 'Lig'} · {roundLine} ·{' '}
          {attachment.stake.toLocaleString('tr-TR')} altın
        </p>
        <div className="post-att-predictions">
          {(attachment.predictions || []).map((p, i) => (
            <div
              key={i}
              className={`post-att-prediction-row ${
                p.correct === true ? 'correct' : p.correct === false ? 'wrong' : ''
              }`}
            >
              <span className="post-att-prediction-teams">
                {p.homeName} - {p.awayName}
                {p.homeScore != null && p.awayScore != null && (
                  <span className="post-att-prediction-score">
                    {' '}
                    ({p.homeScore}-{p.awayScore})
                  </span>
                )}
              </span>
              <span className="post-att-prediction-pick">
                {pickLabel[p.pick] || p.pick}
                {p.correct === true && ' ✅'}
                {p.correct === false && ' ❌'}
              </span>
            </div>
          ))}
        </div>
        <p
          className={`post-att-card-status post-att-status-${attachment.status}`}
        >
          {attachment.status === 'pending' &&
            (attachment.potentialPayout != null
              ? `⏳ Sonuç bekleniyor · Oran ${Number(attachment.odds ?? 0).toFixed(1)} · Tutarsa: ${attachment.potentialPayout.toLocaleString('tr-TR')} altın`
              : '⏳ Sonuç bekleniyor')}
          {attachment.status === 'won' &&
            `✅ Kazandı! ${attachment.payout.toLocaleString('tr-TR')} altın`}
          {attachment.status === 'lost' && '❌ Tutmadı'}
        </p>
      </div>
    );
  }

  if (attachment.type === 'lastMatches') {
    return (
      <div className="post-att post-att-card">
        <p className="post-att-card-title">⚽ Son Oynanan Maçlar</p>
        {attachment.leagueName && <p className="post-att-card-line">{attachment.leagueName}</p>}
        <div className="post-att-matches">
          {attachment.matches.map((m, i) => (
            <div key={i} className="post-att-match-row">
              <FutbolCrest logo={m.homeLogo} initials={m.homeName?.[0]} size={22} />
              <span className="post-att-match-team">{m.homeName}</span>
              <span className="post-att-match-score">
                {m.homeScore} - {m.awayScore}
              </span>
              <span className="post-att-match-team">{m.awayName}</span>
              <FutbolCrest logo={m.awayLogo} initials={m.awayName?.[0]} size={22} />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (attachment.type === 'upcomingMatches') {
    return (
      <div className="post-att post-att-card">
        <p className="post-att-card-title">🔜 Sıradaki Maçlar</p>
        <p className="post-att-card-line">
          {attachment.leagueName || 'Lig'} · {attachment.round}. Hafta
        </p>
        <div className="post-att-matches">
          {attachment.matches.map((m, i) => (
            <div key={i} className="post-att-match-row">
              <FutbolCrest logo={m.homeLogo} initials={m.homeName?.[0]} size={22} />
              <span className="post-att-match-team">{m.homeName}</span>
              <span className="post-att-match-vs">vs</span>
              <span className="post-att-match-team">{m.awayName}</span>
              <FutbolCrest logo={m.awayLogo} initials={m.awayName?.[0]} size={22} />
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (attachment.type === 'investment') {
    return (
      <div className="post-att post-att-card">
        <p className="post-att-card-title">📈 {attachment.assetLabel}</p>
        <p className="post-att-card-line">
          Güncel: {attachment.current.toLocaleString('tr-TR')} altın
        </p>
        <PriceChart points={attachment.points} color="#19e8ff" />
      </div>
    );
  }

  if (attachment.type === 'fine') {
    return (
      <div className="post-att post-att-card post-att-fine">
        <p className="post-att-card-title">🚨 Cezam</p>
        <p className="post-att-fine-amount">
          {attachment.totalAmount.toLocaleString('tr-TR')} altın
        </p>
        <p className="post-att-card-line">
          {attachment.count > 1 ? `${attachment.count} kez yakalandım` : 'Yakalandım'}
        </p>
      </div>
    );
  }

  if (attachment.type === 'debt') {
    return (
      <div className="post-att post-att-card post-att-fine">
        <p className="post-att-card-title">💸 Devlete Borcum</p>
        <p className="post-att-fine-amount">{attachment.amount.toLocaleString('tr-TR')} altın</p>
      </div>
    );
  }

  // v82: YAYIN RAPORU (sayılar sunucuda yayın kaydından alınır)
  if (attachment.type === 'streamReport') {
    const d = Math.max(0, Math.floor((attachment.durationMs || 0) / 1000));
    const dur = d >= 3600 ? `${Math.floor(d / 3600)} sa ${Math.floor((d % 3600) / 60)} dk` : `${Math.floor(d / 60)} dk ${d % 60} sn`;
    const n = (v) => Number(v || 0).toLocaleString('tr-TR');
    const medal = ['🥇', '🥈', '🥉'];
    return (
      <div className="post-att post-att-card post-att-stream">
        <p className="post-att-card-title">
          <span className="post-att-stream-live">CANLI</span> Yayın Raporu
        </p>
        {attachment.title && <p className="post-att-stream-title">{attachment.title}</p>}
        {attachment.houseName && <p className="post-att-stream-place">📍 {attachment.houseName}</p>}
        <div className="post-att-stream-grid">
          <div>
            <b>{dur}</b>
            <small>Süre</small>
          </div>
          <div>
            <b>{n(attachment.seen)}</b>
            <small>Kişi izledi</small>
          </div>
          <div>
            <b>{n(attachment.peak)}</b>
            <small>Aynı anda</small>
          </div>
          <div>
            <b>{n(attachment.donated)}</b>
            <small>Altın bağış</small>
          </div>
        </div>
        {Array.isArray(attachment.top) && attachment.top.length > 0 && (
          <div className="post-att-stream-top">
            {attachment.top.map((x, i) => (
              <span key={i}>
                {medal[i]} <b>{x.n}</b> {n(x.a)}
              </span>
            ))}
          </div>
        )}
      </div>
    );
  }

  if (attachment.type === 'lotteryWin') {
    return (
      <div className="post-att post-att-card post-att-lottery-win">
        <p className="post-att-card-title">🏆 Piyango Kazandım!</p>
        <p className="post-att-fine-amount">{attachment.amount.toLocaleString('tr-TR')} altın</p>
      </div>
    );
  }

  if (attachment.type === 'flappyScore') {
    // attachment.rank — SADECE sunucuda (buildSixtagramAttachment,
    // flappyScores koleksiyonu üzerinde sayım sorgusuyla) hesaplanır ve
    // sadece ilk 10'daysam (ve "ilk 10" anlamlıysa) dolu gelir; aksi
    // halde null'dır ve rozet hiç gösterilmez (eski davranışta regresyon
    // yok).
    return (
      <div className="post-att post-att-card post-att-flappy-score">
        <p className="post-att-card-title">🐦 Flappy Kuş Rekorum</p>
        <p className="post-att-fine-amount">{attachment.score}</p>
        {attachment.rank && (
          <p className="post-att-flappy-rank">🏆 {attachment.rank}. sırada!</p>
        )}
      </div>
    );
  }

  if (attachment.type === 'reputation') {
    return (
      <div className="post-att post-att-card post-att-fine">
        <p className="post-att-card-title">🌟 Saygınlığım</p>
        <p className="post-att-fine-amount">{attachment.value}</p>
      </div>
    );
  }

  if (attachment.type === 'suspicion') {
    return (
      <div className="post-att post-att-card post-att-fine">
        <p className="post-att-card-title">🚔 Şüphe Seviyem</p>
        <p className="post-att-fine-amount">%{attachment.value}</p>
      </div>
    );
  }

  if (attachment.type === 'gold') {
    return (
      <div className="post-att post-att-card post-att-lottery-win">
        <p className="post-att-card-title">💰 Param</p>
        <p className="post-att-fine-amount">{attachment.amount.toLocaleString('tr-TR')} altın</p>
      </div>
    );
  }

  if (attachment.type === 'investmentPortfolio') {
    const gainPositive = attachment.gain >= 0;
    return (
      <div className="post-att post-att-card">
        <p className="post-att-card-title">💹 Yatırım Portföyüm</p>
        <p className="post-att-fine-amount">{attachment.totalValue.toLocaleString('tr-TR')} altın</p>
        <p className={`post-att-card-line ${gainPositive ? 'post-att-status-won' : 'post-att-status-lost'}`}>
          {gainPositive ? '📈 +' : '📉 '}
          {attachment.gain.toLocaleString('tr-TR')} altın {gainPositive ? 'kâr' : 'zarar'}
        </p>
        <div className="post-att-predictions">
          {(attachment.breakdown || [])
            .filter((b) => b.holdings > 0)
            .map((b, i) => (
              <div key={i} className="post-att-prediction-row">
                <span className="post-att-prediction-teams">{b.assetLabel}</span>
                <span className="post-att-prediction-pick">{Math.round(b.value).toLocaleString('tr-TR')} altın</span>
              </div>
            ))}
        </div>
      </div>
    );
  }

  if (attachment.type === 'heist') {
    return (
      <div className="post-att post-att-card post-att-lottery-win">
        <p className="post-att-card-title">🥷 Soygunlarım</p>
        <p className="post-att-fine-amount">{attachment.count} başarılı soygun</p>
        <p className="post-att-card-line">
          Toplam {attachment.totalEarnings.toLocaleString('tr-TR')} altın kazandım
        </p>
      </div>
    );
  }

  if (attachment.type === 'materials') {
    return (
      <div className="post-att post-att-card">
        <p className="post-att-card-title">📦 Malzemelerim</p>
        <div className="post-att-predictions">
          {(attachment.items || []).map((item, i) => (
            <div key={i} className="post-att-prediction-row">
              <span className="post-att-prediction-teams">
                {item.emoji} {item.label}
              </span>
              <span className="post-att-prediction-pick">{item.quantity.toLocaleString('tr-TR')} adet</span>
            </div>
          ))}
        </div>
      </div>
    );
  }

  if (attachment.type === 'parkPhoto') {
    // entities[0] her zaman fotoğrafı çeken kişidir (bkz.
    // functions/index.js) — dx/dy ONA göre gerçek göreli ofset, arka
    // plan da onun o anki gerçek konumundan çizilir (bkz. lib/parkScene.js
    // renderPhotoFrame) — rastgele dizilim ya da "sahneye göre renk" YOK.
    const entities = attachment.entities || [];
    if (!entities.length) return null;
    const names = entities.map((p) => p.displayName || 'Oyuncu');
    return (
      <div className="post-att post-att-parkphoto">
        <div className="post-att-parkphoto-frame">
          <ParkPhotoCanvas entities={entities} originX={attachment.originX} originY={attachment.originY} />
        </div>
        <p className="post-att-parkphoto-names">📷 {names.join(' · ')}</p>
      </div>
    );
  }

  if (attachment.type === 'interiorPhoto') {
    // entities[0] her zaman fotoğrafı çeken kişidir (bkz. functions/index.js
    // 'interiorPhoto' dalı). DÜZELTME ("camiide arkadaşımla fotoğraf
    // çekecektim arkadaşım fotoğrafta çıkmıyor"): artık mekandaki YAKINDAKİ
    // gerçek oyuncular da (buildPresenceEntities, sunucu tarafı) entities
    // dizisine ekleniyor — eskiden bu mekanlar tek kişilik sayılıyordu, o
    // varsayım kaldırıldı; NPC'ler ayrıca arka planın bir parçası olarak
    // çiziliyor (bkz. drawXxxSceneBackground).
    const entities = attachment.entities || [];
    if (!entities.length) return null;
    const LOCATION_LABELS = {
      banka: 'Banka', karakol: 'Karakol', camii: 'Cami', gazino: 'Gazino',
      araba_galerisi: 'Araba Galerisi', silah_magazasi: 'Silah Mağazası', modifiye_garaji: 'Modifiye Garajı',
    };
    const label = LOCATION_LABELS[attachment.locationId] || 'Mekan';
    // Camii'nin imam/dilenci NPC'leri — fotoğraf ÇEKİLDİĞİ anda sunucuda
    // dondurulup post'un attachment'ına gömülen veri (bkz. yukarıdaki
    // DÜZELTME notu) — CANLI dinleyici YOK, bu yüzden post bir kez
    // paylaşıldıktan sonra imam azledilse/dilencinin günü bitse bile
    // fotoğraftaki görüntü değişmez. Diğer tüm mekanlar için `extra` gereksiz.
    const extra = attachment.locationId === 'camii'
      ? { imam: attachment.imam || null, beggars: attachment.beggars || [] }
      : undefined;
    const names = entities.map((p) => p.displayName || 'Oyuncu');
    return (
      <div className="post-att post-att-parkphoto">
        <div className="post-att-parkphoto-frame">
          <InteriorPhotoCanvas
            locationId={attachment.locationId}
            entities={entities}
            originX={attachment.originX}
            originY={attachment.originY}
            extra={extra}
          />
        </div>
        <p className="post-att-parkphoto-names">📷 {names.join(' · ')} · {label}</p>
      </div>
    );
  }

  // v72 — "Resim Çiz": oyuncunun çizdiği tablo (fotoğraf gibi kare)
  if (attachment.type === 'drawing') {
    return (
      <div className="post-att post-att-parkphoto">
        <div className="post-att-parkphoto-frame post-att-drawing">
          <DrawingView drawing={attachment} />
        </div>
      </div>
    );
  }

  if (attachment.type === 'housePhoto') {
    const people = attachment.people || [];
    const names = people.map((p) => p.displayName || 'Oyuncu');
    return (
      <div className="post-att post-att-parkphoto">
        <div className="post-att-parkphoto-frame post-att-housephoto">
          <Suspense fallback={<div className="post-att-housephoto-empty">Fotoğraf yükleniyor…</div>}>
            <HousePhoto attachment={attachment} />
          </Suspense>
        </div>
        <p className="post-att-parkphoto-names">
          📷 {names.length ? `${names.join(' · ')} · ` : ''}🏠 {attachment.houseName || 'Ev'}
        </p>
      </div>
    );
  }

  if (attachment.type === 'interview') {
    // RÖPORTAJ (madde 1) — video benzeri oynatma: gerçek mekan arka planı +
    // konuşan avatar + cümle cümle altyazı (bkz. components/Broadcast/).
    return (
      <div className="post-att post-att-interview">
        <InterviewPlayer
          locationId={attachment.locationId}
          text={attachment.text}
          avatar={attachment.avatar}
          displayName={attachment.displayName}
          extra={
            attachment.locationId === 'camii'
              ? { imam: attachment.imam || null, beggars: attachment.beggars || [] }
              : undefined
          }
        />
      </div>
    );
  }

  return null;
}
