// Çeteler ekranının iskeleti: altta 5 iç sekme.
//   Çete:        Çeteler · Sohbet · Savaş · Ticaret · Çetem
//   İstihbarat:  Çeteler · Sohbet · Savaş · Operasyon · İstihbarat
// Çetesi/İstihbaratı olmayan sadece "Çeteler" listesini görür (diğerleri
// kilitli). Üye açınca Savaş sekmesine düşer; hem çetede hem İstihbarattaysa
// önce İstihbarat gösterilir. Çete ↔ İstihbarat geçişi "Çeteler" sekmesinden.
import { useEffect, useRef, useState } from 'react';
import { useGangAlertsCtx } from './alerts';
import { useGangData, useIntelData } from './data';
import { Deadline, Gold, Logo, RankBadge } from './ui';
import { INTEL_LOGO, fmt } from './gangConstants';
import ListTab from './tabs/ListTab';
import ChatTab from './tabs/ChatTab';
import WarsTab from './tabs/WarsTab';
import TradeTab from './tabs/TradeTab';
import CetemTab from './tabs/CetemTab';
import OpsTab from './tabs/OpsTab';
import IntelTab from './tabs/IntelTab';
import { WatchWarsList } from './WatchWars';
import { BiatTag } from './Biat';

const GANG_TABS = [
  { id: 'ceteler', icon: '🏴', label: 'Çeteler' },
  { id: 'sohbet', icon: '💬', label: 'Sohbet' },
  { id: 'savas', icon: '⚔️', label: 'Savaş' },
  { id: 'ticaret', icon: '🚚', label: 'Ticaret' },
  { id: 'cetem', icon: '👥', label: 'Çetem' },
];
const INTEL_TABS = [
  { id: 'ceteler', icon: '🏴', label: 'Çeteler' },
  { id: 'sohbet', icon: '💬', label: 'Sohbet' },
  { id: 'savas', icon: '⚔️', label: 'Savaş' },
  { id: 'operasyon', icon: '🎯', label: 'Operasyon' },
  { id: 'istihbarat', icon: '🕵️', label: 'İstihbarat' },
];

export default function GangShell({ membership }) {
  const ms = membership || {};
  const inGang = Boolean(ms.gangId);
  const inIntel = Boolean(ms.intelRosterId);
  const [org, setOrg] = useState(inGang || !inIntel ? 'gang' : 'intel');
  const [tab, setTab] = useState(inIntel || inGang ? 'savas' : 'ceteler');

  // Oyuncu henüz kendisi bir sekme seçmediyse üyelik bilgisi gelince varsayılana
  // geç (önce çete, çete yoksa İstihbarat; sekme Savaş). Üyelik değişince (katıl/ayrıl/kur)
  // geçersiz kalan görünümü düzelt.
  const picked = useRef(false);
  useEffect(() => {
    if (!picked.current) {
      setOrg(inGang || !inIntel ? 'gang' : 'intel');
      setTab(inIntel || inGang ? 'savas' : 'ceteler');
      return;
    }
    setOrg((o) => (o === 'intel' && !inIntel ? 'gang' : o === 'gang' && !inGang && inIntel ? 'intel' : o));
  }, [inGang, inIntel]);
  const member = org === 'intel' ? inIntel : inGang;
  // Bildirim noktaları: bulunduğun örgütün sekmeleri; diğer örgütte bir şey
  // varsa "Çeteler" sekmesinde (örgüt değiştirme yeri) nokta.
  const alerts = useGangAlertsCtx();
  const cur = alerts ? (org === 'intel' ? alerts.intel : alerts.gang) : {};
  const other = alerts ? (org === 'intel' ? alerts.gang : alerts.intel) : {};
  const dotOf = (id) => (id === 'ceteler' ? Object.values(other || {}).some(Boolean) && (org === 'intel' ? inGang : inIntel) : Boolean(cur?.[id]));
  const activeTab = member ? tab : tab === 'savas' ? 'savas' : 'ceteler';

  const open = (o) => {
    picked.current = true;
    setOrg(o);
    setTab('savas');
  };
  const pick = (t) => {
    picked.current = true;
    setTab(t);
  };

  return (
    <div className="gx-shell">
      <div className="gx-shell-body">
        {org === 'gang' && inGang ? (
          <GangViews membership={ms} tab={activeTab} onOpen={open} />
        ) : org === 'intel' && inIntel ? (
          <IntelViews membership={ms} tab={activeTab} onOpen={open} />
        ) : !member && activeTab === 'savas' ? (
          // v68: çetesi olmayan oyuncu savaşları izleyebilir (katılamaz)
          <div className="gx-page">
            <div className="gx-section-head">
              <span>👁️ Devam eden savaşlar</span>
            </div>
            <WatchWarsList />
          </div>
        ) : (
          <ListTab membership={ms} onOpen={open} />
        )}
      </div>
      <nav className="gx-subnav" role="tablist">
        {(org === 'intel' ? INTEL_TABS : GANG_TABS).map((t) => {
          const locked = !member && t.id !== 'ceteler' && t.id !== 'savas';
          return (
            <button key={t.id} role="tab" aria-selected={activeTab === t.id} className={`gx-subnav-btn${activeTab === t.id ? ' active' : ''}${locked ? ' locked' : ''}`} disabled={locked} onClick={() => pick(t.id)}>
              <span className="gx-subnav-icon" aria-hidden="true">
                {locked ? '🔒' : t.icon}
                {!locked && activeTab !== t.id && dotOf(t.id) && <span className="gx-subnav-dot" />}
              </span>
              <span className="gx-subnav-label">{t.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}

// v39: adına oylama sürerken yetkiler en alt rütbeye iner — neden butonların kapalı olduğunu göster
function UnderVoteBanner({ until, low }) {
  return (
    <div className="gx-undervote">
      <span className="gx-undervote-icon">🗳️</span>
      <span className="gx-undervote-text">
        Adına oylama var · yetkin <b>{low}</b> · oylamayı Savaş sekmesinden izleyebilirsin
      </span>
      <Deadline untilMs={until} />
    </div>
  );
}

function OrgHeader({ logo, name, rank, prestige, kasa, kasaMidnight = false, intel = false, sub }) {
  return (
    <div className={`gx-header${intel ? ' intel' : ''}`} style={{ '--gx-accent': logo?.color || '#19e8ff' }}>
      <Logo logo={logo} size={46} />
      <div className="gx-header-main">
        <div className="gx-header-name">{name}</div>
        <div className="gx-header-row">
          <RankBadge rank={rank} small />
          <span className="gx-prestige">✦ {fmt(prestige)}</span>
          {sub}
        </div>
      </div>
      <div className="gx-header-kasa">
        <span className="dim">Kasa{kasaMidnight && <span className="gx-midnight-chip">🕛 00:00</span>}</span>
        <Gold value={kasa} />
      </div>
    </div>
  );
}

function GangViews({ membership, tab, onOpen }) {
  const d = useGangData(membership);
  if (tab === 'ceteler') return <ListTab membership={membership} onOpen={onOpen} />;
  if (!d.gang) return <div className="gx-loading">Yükleniyor…</div>;
  if (d.gang.status !== 'active') return <div className="gx-loading">Bu çete dağıldı.</div>;
  return (
    <div className="gx-page">
      <OrgHeader
        logo={d.gang.logo}
        name={d.gang.name}
        rank={d.realRank}
        prestige={d.me?.prestige}
        kasa={d.kasaShown}
        kasaMidnight={!d.kasaLive}
        sub={d.gang.biat?.name ? <BiatTag name={d.gang.biat.name} logo={d.gang.biat.logo} /> : null}
      />
      {d.underVote && <UnderVoteBanner until={d.underVoteUntilMs} low="Çömez" />}
      {tab === 'sohbet' && <ChatTab org="gang" d={d} />}
      {tab === 'savas' && <WarsTab org="gang" d={d} />}
      {tab === 'ticaret' && <TradeTab d={d} />}
      {tab === 'cetem' && <CetemTab d={d} />}
    </div>
  );
}

function IntelViews({ membership, tab, onOpen }) {
  const d = useIntelData(membership);
  if (tab === 'ceteler') return <ListTab membership={membership} onOpen={onOpen} />;
  return (
    <div className="gx-page">
      {d.underVote && <UnderVoteBanner until={d.underVoteUntilMs} low="Muhbir" />}
      <OrgHeader intel logo={INTEL_LOGO} name="İstihbarat Teşkilatı" rank={d.rank} prestige={d.me?.prestige} kasa={d.state?.kasa} sub={<span className="gx-codename">🕶️ {d.me?.codeName || membership.intelCodeName}</span>} />
      {tab === 'sohbet' && <ChatTab org="intel" d={d} />}
      {tab === 'savas' && <WarsTab org="intel" d={d} />}
      {tab === 'operasyon' && <OpsTab d={d} />}
      {tab === 'istihbarat' && <IntelTab d={d} />}
    </div>
  );
}
