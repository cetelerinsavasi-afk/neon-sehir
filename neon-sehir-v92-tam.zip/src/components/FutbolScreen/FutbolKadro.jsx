import { useEffect, useRef, useState } from 'react';
import { useFutbolTeamPlayers } from '../../hooks/useFutbolTeamPlayers';
import { setFutbolLineup } from '../../services/gameActions';
import { formatCountdown, isFutbolLineupLockedIstanbul, msUntilFutbolLineupUnlock } from '../../lib/istanbulTime';
import FutbolPlayerAvatar from './FutbolPlayerAvatar';
import InfoTooltip from '../InfoTooltip/InfoTooltip';
import './FutbolKadro.css';

const FORMATIONS = {
  '2-2-1': { GK: 1, DEF: 2, MID: 2, FWD: 1 },
  '2-1-2': { GK: 1, DEF: 2, MID: 1, FWD: 2 },
  '3-1-1': { GK: 1, DEF: 3, MID: 1, FWD: 1 },
  '1-2-2': { GK: 1, DEF: 1, MID: 2, FWD: 2 },
  '1-3-1': { GK: 1, DEF: 1, MID: 3, FWD: 1 },
  '1-1-3': { GK: 1, DEF: 1, MID: 1, FWD: 3 },
};
const TACTICS = [
  { id: 'defansif', label: 'Defansif' },
  { id: 'dengeli', label: 'Dengeli' },
  { id: 'ofansif', label: 'Ofansif' },
];
// Mücadele — yeni istek: "kadro > taktiğin altına mücadele kısmı
// koyalım (Dikkatli/Normal/Agresif/Çok Agresif)". Ne kadar agresif
// oynarsan o maçta oyuncuların o kadar güçlü ama sakatlanma riski ve
// maç sonrası form kaybı da o kadar yüksek olur (bkz. functions/index.js
// FUTBOL_MUCADELE_LEVELS) — dikkatli oynarsan tam tersi.
const MUCADELE_LEVELS = [
  { id: 'dikkatli', label: 'Dikkatli' },
  { id: 'normal', label: 'Normal' },
  { id: 'agresif', label: 'Agresif' },
  { id: 'cok_agresif', label: 'Çok Agresif' },
];
const POSITION_LABELS = { GK: 'Kaleci', DEF: 'Defans', MID: 'Orta Saha', FWD: 'Forvet' };
// Sahada yukarıdan aşağıya gösterim sırası (forvet rakip kaleye yakın üstte).
const ROW_ORDER = ['FWD', 'MID', 'DEF', 'GK'];

function buildSlots(formation, lineup, players) {
  const need = FORMATIONS[formation];
  const byId = {};
  players.forEach((p) => (byId[p.id] = p));
  const slots = {};
  ROW_ORDER.forEach((pos) => {
    slots[pos] = Array.from({ length: need[pos] }, () => null);
  });
  // Mevcut lineup'ı, pozisyonu tutan slotlara sırayla yerleştir.
  (lineup || []).forEach((id) => {
    const player = byId[id];
    if (!player || !slots[player.position]) return;
    const idx = slots[player.position].findIndex((s) => s === null);
    if (idx !== -1) slots[player.position][idx] = id;
  });
  return slots;
}

const FORMATION_KEYS = Object.keys(FORMATIONS);

// "Otomatik Doldur" — backend'deki resolveFutbolTeamLineup/pickFutbolLineup
// ile aynı kural: form x güç (bkz. futbolEffectivePower) en yüksek, sakat
// olmayan ve antrenmanda olmayan oyuncular kadroya eklenir.
function futbolEffectivePower(p) {
  return p.power * (p.form / 100);
}

function eligibleAutoFillPlayersByPosition(players, team) {
  const trainingSet = new Set(team.trainingPlayerIds || []);
  const map = { GK: [], DEF: [], MID: [], FWD: [] };
  players.forEach((p) => {
    if ((p.injuryDaysLeft || 0) > 0) return; // sakat oyuncu ilk 11'e giremez
    if (trainingSet.has(p.id)) return; // antrenmandaki oyuncu ilk 11'e giremez
    if (!map[p.position]) return;
    map[p.position].push(p);
  });
  Object.keys(map).forEach((pos) => {
    map[pos].sort((a, b) => futbolEffectivePower(b) - futbolEffectivePower(a));
  });
  return map;
}

function formationFillable(byPos, need) {
  return Object.keys(need).every((pos) => (byPos[pos]?.length || 0) >= need[pos]);
}

function formationMissingCount(byPos, need) {
  return Object.keys(need).reduce((sum, pos) => sum + Math.max(0, need[pos] - (byPos[pos]?.length || 0)), 0);
}

function fillSlotsForFormation(byPos, need) {
  const slots = {};
  ROW_ORDER.forEach((pos) => {
    const list = byPos[pos] || [];
    const count = need[pos] || 0;
    slots[pos] = Array.from({ length: count }, (_, idx) => (list[idx] ? list[idx].id : null));
  });
  return slots;
}

export default function FutbolKadro({ team, role }) {
  // KULLANICI İSTEĞİ: menajer varken başkan bu sekmeye girip inceleyebilir
  // ama işlem yapamaz — sadece asıl kontrolcü (MANAGED'da menajer,
  // OWNER_ACTIVE/OWNER_AUTO'da başkan) düzenleyebilir.
  const readOnly = role === 'owner' && Boolean(team.managerUid);
  // KULLANICI REVİZESİ: saat 18:00-19:00 arası (İstanbul) kadro kilitli —
  // o günkü maç zaten 18:00'de hesaplanıp donduruldu (bkz. functions/index.js
  // computeFutbolMatchLive/futbolIsLineupLockedIstanbul), bu pencerede
  // yapılan bir değişiklik bugünkü maça ZATEN yansımaz. Sunucu zaten
  // reddediyor — burada da aynı pencerede fieldset'i kilitleyip sebebini
  // gösteriyoruz. Her 15 saniyede bir yeniden değerlendiriliyor ki kilit
  // 19:00'da otomatik açılsın.
  const [lineupLocked, setLineupLocked] = useState(() => isFutbolLineupLockedIstanbul());
  const [lockCountdown, setLockCountdown] = useState(() => msUntilFutbolLineupUnlock());
  useEffect(() => {
    const tick = () => {
      setLineupLocked(isFutbolLineupLockedIstanbul());
      setLockCountdown(msUntilFutbolLineupUnlock());
    };
    tick();
    const id = setInterval(tick, 15000);
    return () => clearInterval(id);
  }, []);
  const { players } = useFutbolTeamPlayers(team.id);
  const [formation, setFormation] = useState(team.formation || '2-2-1');
  const [tactic, setTactic] = useState(team.tactic || 'dengeli');
  const [mucadele, setMucadele] = useState(team.mucadele || 'normal');
  const [slots, setSlots] = useState({});
  const [pickerFor, setPickerFor] = useState(null); // { position, slotIndex }
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState('');
  // Kullanıcı revizesi: "kadroyu kaydet butonuna basmasak da kadroyu en
  // son ne durumda bıraktıysak otomatik o şekilde kaydolsun" — bir
  // sonraki otomatik-kaydetme denemesini (sunucudan taze veri geldiğinde,
  // kullanıcı henüz bir şey değiştirmemişken) atlamak için kullanılıyor.
  const skipNextAutoSaveRef = useRef(true);
  // Otomatik Doldur — hangi dizilimden başlayarak deneneceğini tutar.
  // Takım değişince ya da kullanıcı elle bir dizilim seçince, bir sonraki
  // "Otomatik Doldur" önce O dizilimi dener (yeterli oyuncu varsa dizilim
  // değişmez). Aynı butona ÜST ÜSTE basılırsa, bir sonraki dener dizilim
  // sıradaki farklı dizilime kayar — "tekrar basarsa farklı bi dizilim
  // yapılsın" isteği.
  const autoFillCursorRef = useRef(0);

  useEffect(() => {
    const f = team.formation || '2-2-1';
    setFormation(f);
    setTactic(team.tactic || 'dengeli');
    setMucadele(team.mucadele || 'normal');
    skipNextAutoSaveRef.current = true;
    autoFillCursorRef.current = Math.max(0, FORMATION_KEYS.indexOf(f));
  }, [team.id]);

  useEffect(() => {
    if (players.length > 0) {
      setSlots(buildSlots(formation, team.lineup, players));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [players.length, team.id]);

  const changeFormation = (f) => {
    const flatCurrent = Object.values(slots).flat().filter(Boolean);
    setFormation(f);
    setSlots(buildSlots(f, flatCurrent, players));
    // Kullanıcı dizilimi elle seçtiyse, otomatik doldur bir dahaki sefere
    // önce bunu denesin.
    autoFillCursorRef.current = Math.max(0, FORMATION_KEYS.indexOf(f));
  };

  const usedPlayerIds = new Set(Object.values(slots).flat().filter(Boolean));

  // Otomatik Doldur — taktik/mücadele hep sabit kalır; dizilim SADECE
  // mevcut/denenen dizilimde ihtiyacı karşılayacak sağlıklı+antrenmanda
  // olmayan oyuncu yoksa değişir. Kadrodaki oyuncular her zaman form x güç
  // sırasına göre en iyileriyle doldurulur.
  const handleAutoFill = () => {
    if (!players.length) {
      setMessage('Kadroda oyuncu yok.');
      return;
    }
    setMessage('');
    const byPos = eligibleAutoFillPlayersByPosition(players, team);
    const n = FORMATION_KEYS.length;
    const startIdx = ((autoFillCursorRef.current % n) + n) % n;
    const order = Array.from({ length: n }, (_, i) => FORMATION_KEYS[(startIdx + i) % n]);

    let chosenKey = order.find((key) => formationFillable(byPos, FORMATIONS[key]));
    if (!chosenKey) {
      // Hiçbir dizilim tam doldurulamıyor — en az eksikli olanla, elden
      // geldiğince (bkz. backend'deki aynı "best effort" mantığı).
      let bestMissing = Infinity;
      order.forEach((key) => {
        const missing = formationMissingCount(byPos, FORMATIONS[key]);
        if (missing < bestMissing) {
          bestMissing = missing;
          chosenKey = key;
        }
      });
    }

    const need = FORMATIONS[chosenKey];
    const newSlots = fillSlotsForFormation(byPos, need);
    const previousFormation = formation;
    setFormation(chosenKey);
    setSlots(newSlots);
    autoFillCursorRef.current = (FORMATION_KEYS.indexOf(chosenKey) + 1) % n;

    const totalNeeded2 = Object.values(need).reduce((a, b) => a + b, 0);
    const filled = Object.values(newSlots).flat().filter(Boolean).length;
    if (filled < totalNeeded2) {
      setMessage(
        `Uygun (sakat olmayan, antrenmanda olmayan) yeterli oyuncu bulunamadı — kadro ${filled}/${totalNeeded2} dolduruldu.`
      );
    } else if (chosenKey !== previousFormation) {
      setMessage(`Mevcut dizilim için yeterli oyuncu yoktu, ${chosenKey} dizilimine geçildi ve kadro dolduruldu.`);
    } else {
      setMessage('Kadro otomatik dolduruldu.');
    }
  };

  const assignPlayer = (position, slotIndex, playerId) => {
    setMessage('');
    setSlots((prev) => {
      const next = { ...prev, [position]: [...prev[position]] };
      next[position][slotIndex] = playerId;
      return next;
    });
    setPickerFor(null);
  };

  const clearSlot = (position, slotIndex) => {
    setSlots((prev) => {
      const next = { ...prev, [position]: [...prev[position]] };
      next[position][slotIndex] = null;
      return next;
    });
  };

  const flatLineup = Object.values(slots).flat().filter(Boolean);
  const totalNeeded = Object.values(FORMATIONS[formation]).reduce((a, b) => a + b, 0);
  const isComplete = flatLineup.length === totalNeeded;

  const handleSave = async () => {
    setBusy(true);
    setMessage('');
    try {
      await setFutbolLineup(team.id, formation, tactic, flatLineup, mucadele);
      setMessage('Kaydedildi ✓');
    } catch (err) {
      setMessage(err?.message || 'Kaydedilemedi.');
    } finally {
      setBusy(false);
    }
  };

  // Dizilim, taktik ya da slotlar TAMAMLANMIŞ haldeyken değişince (kısa
  // bir debounce ile — her tek tık için ayrı ayrı sunucuya gitmesin)
  // otomatik kaydediyoruz. İlk yüklemede ya da takım değişiminde
  // (sunucudan taze veri geldiğinde) TETİKLENMEZ — sadece kullanıcı
  // gerçekten bir şey değiştirince devreye girer.
  const flatLineupKey = flatLineup.join(',');
  useEffect(() => {
    if (skipNextAutoSaveRef.current) {
      skipNextAutoSaveRef.current = false;
      return;
    }
    if (!isComplete || lineupLocked) return;
    const t = setTimeout(() => {
      handleSave();
    }, 900);
    return () => clearTimeout(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [formation, tactic, mucadele, flatLineupKey, isComplete, lineupLocked]);

  const playersById = {};
  players.forEach((p) => (playersById[p.id] = p));

  return (
    <fieldset className="futbol-kadro" disabled={readOnly || lineupLocked}>
      {lineupLocked && (
        <p className="futbol-kadro-lock-notice">
          🔒 Saat 18:00-19:00 arası kadro kilitli — bugünkü maç zaten hesaplandı, değişiklikler ancak bugün 19:00&apos;dan
          sonra bir sonraki maça yansır. Kilit açılmasına kalan süre: {formatCountdown(lockCountdown)}
        </p>
      )}
      <p className="futbol-kadro-section-title">Dizilim</p>
      <div className="futbol-kadro-chip-row">
        {Object.keys(FORMATIONS).map((f) => (
          <button
            key={f}
            className={`futbol-kadro-chip ${formation === f ? 'active' : ''}`}
            onClick={() => changeFormation(f)}
          >
            {f}
          </button>
        ))}
      </div>

      <p className="futbol-kadro-section-title">
        Taktik
        <InfoTooltip text="Taktik, takımının maçta nasıl oynayacağını belirler — hücum, denge ya da savunma ağırlıklı." />
      </p>
      <div className="futbol-kadro-chip-row">
        {TACTICS.map((t) => (
          <button
            key={t.id}
            className={`futbol-kadro-chip ${tactic === t.id ? 'active' : ''}`}
            onClick={() => setTactic(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      <p className="futbol-kadro-section-title">
        Mücadele
        <InfoTooltip text="Ne kadar mücadeleci oynarsan takımın o maçta o kadar güçlü olur, ama sakatlanma riski ve maç sonrası form kaybı artar. Dikkatli oynarsan tam tersi olur: daha güvenli ama daha zayıf." />
      </p>
      <div className="futbol-kadro-chip-row">
        {MUCADELE_LEVELS.map((m) => (
          <button
            key={m.id}
            className={`futbol-kadro-chip ${mucadele === m.id ? 'active' : ''}`}
            onClick={() => setMucadele(m.id)}
          >
            {m.label}
          </button>
        ))}
      </div>

      <button type="button" className="futbol-admin-reset futbol-kadro-autofill" onClick={handleAutoFill}>
        ⚡ Otomatik Doldur
      </button>

      <div className="futbol-pitch-big">
        {ROW_ORDER.map((pos) => (
          <div key={pos} className="futbol-pitch-row-wrap">
            <p className="futbol-pitch-row-label">{POSITION_LABELS[pos]}</p>
            <div className="futbol-pitch-row">
              {(slots[pos] || []).map((playerId, idx) => {
                const player = playerId ? playersById[playerId] : null;
                return (
                  <button
                    key={idx}
                    className="futbol-pitch-slot"
                    onClick={() => setPickerFor({ position: pos, slotIndex: idx })}
                  >
                    <FutbolPlayerAvatar playerId={playerId || `${pos}-${idx}-empty`} position={pos} size={46} />
                    {player ? (
                      <span className="futbol-pitch-slot-info">
                        <strong>{player.name.split(' ')[0]}</strong>
                        {(player.injuryDaysLeft || 0) > 0 ? (
                          <span className="futbol-injury-badge">🚑 Sakat ({player.injuryDaysLeft}g)</span>
                        ) : (
                          `${player.age}y · ${player.power.toFixed(0)}g · ${Math.round(player.form)}f`
                        )}
                      </span>
                    ) : (
                      <span className="futbol-pitch-slot-info futbol-pitch-slot-empty">
                        {POSITION_LABELS[pos]} seç
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {!isComplete && (
        <p className="futbol-admin-error">
          {flatLineup.length}/{totalNeeded} oyuncu seçildi — tüm slotları doldurunca otomatik kaydedilir.
        </p>
      )}
      {message && <p className="futbol-placeholder">{message}</p>}
      <button className="futbol-admin-submit" disabled={busy || !isComplete} onClick={handleSave}>
        {busy ? 'Kaydediliyor...' : 'Şimdi Kaydet'}
      </button>
      <p className="futbol-placeholder futbol-kadro-note">
        Kadron otomatik kaydedilir — bir değişiklik yaptığında kısa bir
        süre sonra kendiliğinden kaydolur, bu butona basmana gerek yok
        (istersen anında kaydetmek için kullanabilirsin).
      </p>
      <p className="futbol-placeholder futbol-kadro-note">
        Not: seçtiğin oyunculardan biri formu %50&apos;nin altına düşerse ya
        da SAKATLANIRSA, o maç için otomatik olarak (denenebilecek ilk
        uygun dizilimle) en formda/sağlıklı kadroya geri dönülür. Hiçbir
        dizilimle sağlıklı 6 kişi çıkaramazsan takım elinden alınır.
        Antrenmandaki ve sakat oyuncular ilk 11&apos;e seçilemez.
      </p>

      {pickerFor && (
        <PlayerPicker
          position={pickerFor.position}
          players={players.filter(
            (p) =>
              p.position === pickerFor.position &&
              !(team.trainingPlayerIds || []).includes(p.id) &&
              !((p.injuryDaysLeft || 0) > 0)
          )}
          usedPlayerIds={usedPlayerIds}
          currentId={slots[pickerFor.position]?.[pickerFor.slotIndex]}
          onPick={(playerId) => assignPlayer(pickerFor.position, pickerFor.slotIndex, playerId)}
          onClear={() => {
            clearSlot(pickerFor.position, pickerFor.slotIndex);
            setPickerFor(null);
          }}
          onClose={() => setPickerFor(null)}
        />
      )}
    </fieldset>
  );
}

function PlayerPicker({ position, players, usedPlayerIds, currentId, onPick, onClear, onClose }) {
  return (
    <div className="futbol-picker-backdrop" onClick={onClose}>
      <div className="futbol-picker" onClick={(e) => e.stopPropagation()}>
        <p className="futbol-kadro-section-title">{POSITION_LABELS[position]} seç</p>
        <div className="futbol-picker-list">
          {players.map((p) => {
            const isCurrent = currentId === p.id;
            const usedElsewhere = !isCurrent && usedPlayerIds.has(p.id);
            return (
              <button
                key={p.id}
                className={`futbol-picker-row ${isCurrent ? 'selected' : ''} ${usedElsewhere ? 'used-elsewhere' : ''}`}
                disabled={usedElsewhere}
                onClick={() => onPick(p.id)}
              >
                <FutbolPlayerAvatar playerId={p.id} position={p.position} size={38} />
                <span className="futbol-picker-info">
                  <strong>
                    {p.name}
                    {p.real && <em className="fp-real" title="Gerçek oyuncu">👤</em>}
                  </strong>
                  <span>
                    {p.age} yaş · {p.power.toFixed(1)} güç · {Math.round(p.form)}% form
                  </span>
                </span>
                {isCurrent && <span className="futbol-picker-badge current">Bu slotta</span>}
                {usedElsewhere && <span className="futbol-picker-badge">Kadroda</span>}
              </button>
            );
          })}
          {players.length === 0 && <p className="futbol-placeholder">Bu mevkide oyuncun yok.</p>}
        </div>
        {currentId && (
          <button className="futbol-admin-reset" onClick={onClear}>
            Slotu Boşalt
          </button>
        )}
      </div>
    </div>
  );
}
