import { useEffect, useState } from 'react';
import { ProContracts } from './FutbolProMarket';
import { useMyFutbolTeam } from '../../hooks/useMyFutbolTeam';
import { useFutbolTeams } from '../../hooks/useFutbolTeams';
import { useFutbolTeamPlayers } from '../../hooks/useFutbolTeamPlayers';
import {
  listFutbolBuyableTeams,
  getMyFutbolTeamFinance,
  getFutbolTeamDetail,
  buyFutbolTeam,
  sellFutbolTeam,
  listFutbolTeamForSale,
  cancelFutbolTeamListing,
} from '../../services/gameActions';
import FutbolCrest from './FutbolCrest';
import FutbolPlayerAvatar from './FutbolPlayerAvatar';
import FutbolKadro from './FutbolKadro';
import FutbolTransfer from './FutbolTransfer';
import FutbolLogoEditor from './FutbolLogoEditor';
import FutbolAltyapi from './FutbolAltyapi';
import FutbolDoktor from './FutbolDoktor';
import FutbolStadyum from './FutbolStadyum';
import FutbolSponsor from './FutbolSponsor';
import FutbolMenajer from './FutbolMenajer';
import FutbolMenajerOl from './FutbolMenajerOl';
import NotificationBell from '../NotificationBell/NotificationBell';
import { groupFutbolPlayersByPositionOrdered } from './futbolPositionOrder';
import QuantityStepper from '../QuantityStepper/QuantityStepper';
import ConfirmModal from '../ConfirmModal/ConfirmModal';
import './FutbolTakimim.css';

const CLUB_PRICE_QUICK_AMOUNTS = [100, 1000, 10000, 100000, { value: 1000000, label: '1M' }];

function initialsFromName(name) {
  return (name || '')
    .split(' ')
    .map((w) => w[0])
    .join('');
}

const MY_TEAM_TABS = [
  { id: 'takimin', label: 'Takımın' },
  { id: 'kadro', label: 'Kadro' },
  { id: 'transfer', label: 'Transfer' },
  { id: 'altyapi', label: 'Antrenman' },
  { id: 'doktor', label: 'Doktor' },
  { id: 'forma', label: 'Forma' },
  { id: 'stadyum', label: 'Stadyum' },
  { id: 'sponsor', label: 'Sponsor' },
  { id: 'menajer', label: 'Menajer' },
];

// FutbolTakimim — KULLANICI REVİZESİ (Menajerlik Sistemi): takım sahipliği
// ve menajerlik BİRBİRİNİ DIŞLAR — bir oyuncu aynı anda hem takım sahibi hem
// başka bir takımın menajeri OLAMAZ (takım sahipleri başka takımlara
// menajerlik yapamaz; bir menajer takım satın almak isterse önce istifa
// etmesi gerekir — bkz. applyFutbolManager/requestFutbolManagerHandover ve
// buyFutbolTeam'deki sunucu tarafı kontroller). Bu yüzden ekran da buna göre
// TEK bir "Takımım" görünümü: hiç takımın yoksa "Takım Satın Al" / "Menajer
// Ol" seçim paneli, bir takımın (sahip OLARAK ya da menajer OLARAK) varsa
// doğrudan o takımın sekmeleri — sahip olunan takımda aynen eskisi gibi,
// SADECE ek bir "Menajer" alt-sekmesiyle (devir/kasa araçları için).
export default function FutbolTakimim() {
  const { ownedTeam, managedTeam, loading } = useMyFutbolTeam();
  const [tab, setTab] = useState('takimin');
  const [joinTab, setJoinTab] = useState('buy');

  if (loading) return <p className="futbol-placeholder">Yükleniyor...</p>;

  const team = ownedTeam || managedTeam;
  const role = ownedTeam ? 'owner' : managedTeam ? 'manager' : null;

  if (!team) {
    return (
      <div className="futbol-my-team-wrap">
        <div className="futbol-subtabs futbol-subtabs-inner">
          <button
            className={`futbol-subtab-btn ${joinTab === 'buy' ? 'active' : ''}`}
            onClick={() => setJoinTab('buy')}
          >
            Takım Satın Al
          </button>
          <button
            className={`futbol-subtab-btn ${joinTab === 'menajerOl' ? 'active' : ''}`}
            onClick={() => setJoinTab('menajerOl')}
          >
            Menajer Ol
          </button>
        </div>
        {joinTab === 'buy' ? <BuyTeamPanel /> : <FutbolMenajerOl />}
      </div>
    );
  }

  return (
    <div className="futbol-my-team-wrap">
      <TeamTabsPanel team={team} role={role} tab={tab} setTab={setTab} />
    </div>
  );
}

function TeamTabsPanel({ team, role, tab, setTab }) {
  return (
    <div>
      <div className="futbol-subtabs futbol-subtabs-inner futbol-my-team-subtabs-scroll">
        {MY_TEAM_TABS.map((t) => (
          <button
            key={t.id}
            className={`futbol-subtab-btn ${tab === t.id ? 'active' : ''}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
          </button>
        ))}
      </div>

      {tab === 'takimin' && <MyTeamOverview team={team} role={role} />}
      {tab === 'kadro' && <FutbolKadro team={team} role={role} />}
      {tab === 'transfer' && <FutbolTransfer team={team} role={role} />}
      {tab === 'altyapi' && <FutbolAltyapi team={team} role={role} />}
      {tab === 'doktor' && <FutbolDoktor team={team} role={role} />}
      {tab === 'forma' && <FutbolLogoEditor team={team} role={role} />}
      {tab === 'stadyum' && <FutbolStadyum team={team} role={role} />}
      {tab === 'sponsor' && <FutbolSponsor team={team} role={role} />}
      {tab === 'menajer' && <FutbolMenajer team={team} role={role} />}
    </div>
  );
}

function BuyTeamPanel() {
  const [teams, setTeams] = useState(null);
  const [busyId, setBusyId] = useState(null);
  const [error, setError] = useState('');

  const load = async () => {
    setError('');
    try {
      const res = await listFutbolBuyableTeams();
      setTeams(res?.data?.teams || []);
    } catch (err) {
      setError('Liste yüklenemedi.');
    }
  };

  useEffect(() => {
    load();
  }, []);

  const handleBuy = async (teamId) => {
    setBusyId(teamId);
    setError('');
    try {
      await buyFutbolTeam(teamId);
      await load();
    } catch (err) {
      setError(err?.message || 'Satın alma başarısız.');
    } finally {
      setBusyId(null);
    }
  };

  if (teams === null) return <p className="futbol-placeholder">Yükleniyor...</p>;

  return (
    <div className="futbol-buy-list">
      {error && <p className="futbol-admin-error">{error}</p>}
      {teams.length === 0 && <p className="futbol-placeholder">Satılık takım kalmadı.</p>}
      {teams.map((t) => (
        <div key={t.id} className="futbol-buy-row">
          <FutbolCrest logo={t.logo} initials={initialsFromName(t.name)} size={40} />
          <div className="futbol-buy-info">
            <p className="futbol-buy-name">
              {t.name} {t.listedByPlayer && <span className="futbol-buy-badge">Oyuncu İlanı</span>}
            </p>
            <p className="futbol-buy-meta">
              {t.tier}. Lig · {t.fans.toLocaleString('tr-TR')} taraftar
            </p>
          </div>
          <div className="futbol-buy-action">
            <p className="futbol-buy-price">{t.price.toLocaleString('tr-TR')} altın</p>
            {t.listedByPlayer && (
              <p className="futbol-buy-meta">Değeri: {t.value.toLocaleString('tr-TR')} altın</p>
            )}
            <button
              className="futbol-admin-submit"
              disabled={busyId === t.id}
              onClick={() => handleBuy(t.id)}
            >
              {busyId === t.id ? '...' : 'Satın Al'}
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}

function MyTeamOverview({ team, role }) {
  const { teams: leagueTeams } = useFutbolTeams(team.leagueId);
  const { players } = useFutbolTeamPlayers(team.id);
  const [finance, setFinance] = useState(null);
  const [detailValue, setDetailValue] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [showSellPanel, setShowSellPanel] = useState(false);
  const [listPrice, setListPrice] = useState(0);
  const [confirmInstantSell, setConfirmInstantSell] = useState(false);
  const isOwner = role === 'owner';
  // KULLANICI REVİZESİ: takım kasası/transfer desteği SADECE gerçekten
  // canlı olduğu durumlarda gösterilsin — menajerli (role: 'manager') ya da
  // başkan pasif olduğu için oto-bot moduna geçmiş (autoManaged) takımlarda.
  // Normal aktif başkanlı (menajersiz) bir takımda kasa kavramı YOK (Bölüm
  // 5/10 — para doğrudan başkanın kişisel altınına gider), o yüzden orada
  // hiç gösterilmemeli.
  const hasTreasury = role === 'manager' || (isOwner && Boolean(team.autoManaged));

  const rank = leagueTeams.findIndex((t) => t.id === team.id) + 1;

  const loadFinance = () => {
    if (!isOwner) return;
    getMyFutbolTeamFinance()
      .then((res) => setFinance(res?.data?.team || null))
      .catch(() => {});
  };

  useEffect(() => {
    loadFinance();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [team.id, isOwner]);

  // Takım değeri satırı (+ bildirim çanı) hem başkan hem menajer için
  // görünür — getMyFutbolTeamFinance sadece başkana açık (satış fiyatları
  // içeriyor), bu yüzden değer için herkese açık getFutbolTeamDetail
  // kullanılıyor.
  useEffect(() => {
    getFutbolTeamDetail(team.id)
      .then((res) => setDetailValue(res?.data?.team?.value ?? null))
      .catch(() => {});
  }, [team.id]);

  const handleInstantSell = () => {
    setConfirmInstantSell(true);
  };

  const runInstantSell = async () => {
    setConfirmInstantSell(false);
    setBusy(true);
    setError('');
    try {
      await sellFutbolTeam(team.id);
    } catch (err) {
      setError(err?.message || 'Satış başarısız.');
    } finally {
      setBusy(false);
    }
  };

  const handleList = async () => {
    setBusy(true);
    setError('');
    try {
      await listFutbolTeamForSale(team.id, listPrice);
      setShowSellPanel(false);
    } catch (err) {
      setError(err?.message || 'İlan verilemedi.');
    } finally {
      setBusy(false);
    }
  };

  const handleCancelListing = async () => {
    setBusy(true);
    setError('');
    try {
      await cancelFutbolTeamListing(team.id);
    } catch (err) {
      setError(err?.message || 'İptal edilemedi.');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="futbol-my-team">
      <div className="futbol-my-team-header">
        <FutbolCrest logo={team.logo} initials={initialsFromName(team.name)} size={56} />
        <div>
          <p className="futbol-my-team-name">{team.name}</p>
          <p className="futbol-buy-meta">
            {team.tier}. Lig · {(team.fans || 0).toLocaleString('tr-TR')} taraftar ·{' '}
            {(team.stadiumCapacity || 2500).toLocaleString('tr-TR')} kapasiteli stadyum
          </p>
        </div>
      </div>

      <div className="futbol-my-team-rank">
        {rank > 0 ? `Ligde ${rank}. sıradasın` : 'Sıralama hesaplanıyor...'}
        {(team.championshipsCount > 0 || team.cupsCount > 0) && (
          <span className="futbol-my-team-trophies">
            {team.championshipsCount > 0 && ` · 🏆 ${team.championshipsCount} şampiyonluk`}
            {team.cupsCount > 0 && ` · 🏆 ${team.cupsCount} kupa`}
          </span>
        )}
      </div>
      <div className="futbol-my-team-rank futbol-my-team-value-row">
        <span>Takım Değeri: {detailValue != null ? `${detailValue.toLocaleString('tr-TR')} altın` : '…'}</span>
        <NotificationBell kind="team" id={team.id} unread={Boolean(team.notifUnread)} />
      </div>
      {hasTreasury && (
        <div className="futbol-finance-stack">
          <p className="futbol-finance-line treasury">
            💰 Takım Kasası: {(team.treasury || 0).toLocaleString('tr-TR')} altın
          </p>
          <p className="futbol-finance-line support">
            🎯 Transfer Desteği: {(team.transferSupport || 0).toLocaleString('tr-TR')} altın
          </p>
        </div>
      )}

      {error && <p className="futbol-admin-error">{error}</p>}

      {isOwner &&
        (team.forSale ? (
          <div className="futbol-my-team-finance">
            <p>İlan fiyatın: {(team.salePrice || 0).toLocaleString('tr-TR')} altın</p>
            <button className="futbol-admin-reset" disabled={busy} onClick={handleCancelListing}>
              İlanı İptal Et
            </button>
          </div>
        ) : !showSellPanel ? (
          <button className="futbol-admin-reset" onClick={() => setShowSellPanel(true)}>
            Takımı Sat
          </button>
        ) : (
          <div className="futbol-my-team-finance">
            {finance && (
              <p className="futbol-buy-meta">
                Değer: {finance.value.toLocaleString('tr-TR')} · Anında satış:{' '}
                {finance.instantSellPrice.toLocaleString('tr-TR')} · Azami ilan:{' '}
                {finance.maxListPrice.toLocaleString('tr-TR')}
              </p>
            )}
            <QuantityStepper
              value={listPrice}
              onChange={setListPrice}
              max={finance?.maxListPrice}
              quickAmounts={CLUB_PRICE_QUICK_AMOUNTS}
            />
            <button className="futbol-admin-submit" disabled={busy || listPrice <= 0} onClick={handleList}>
              Listeye Koy
            </button>
            {finance && (
              <button className="futbol-admin-reset" disabled={busy} onClick={handleInstantSell}>
                Anında Sat ({finance.instantSellPrice.toLocaleString('tr-TR')})
              </button>
            )}
            <button className="futbol-placeholder futbol-my-team-cancel-link" onClick={() => setShowSellPanel(false)}>
              Vazgeç
            </button>
          </div>
        ))}

      <p className="futbol-kadro-section-title">Kadromuz ({players.length})</p>
      <div className="futbol-roster-list">
        {groupFutbolPlayersByPositionOrdered(players).map((group) => (
          <div key={group.position} className="futbol-transfer-position-group">
            <p className="futbol-transfer-group-header">{group.label}</p>
            {group.players.map((p) => {
              const lineup = team.lineup || [];
              const trainingIds = team.trainingPlayerIds || [];
              const inLineup = lineup.includes(p.id);
              const inTraining = trainingIds.includes(p.id);
              const isInjured = (p.injuryDaysLeft || 0) > 0;
              const status = isInjured
                ? { label: `🚑 Sakat (${p.injuryDaysLeft}g)`, cls: 'injured' }
                : inLineup
                  ? { label: '🟢 Kadroda', cls: 'lineup' }
                  : inTraining
                    ? { label: '🟡 Antrenmanda', cls: 'training' }
                    : { label: '⚪ Boşta', cls: 'idle' };
              return (
                <div key={p.id} className="futbol-roster-row">
                  <FutbolPlayerAvatar playerId={p.id} position={p.position} size={38} />
                  <div className="futbol-roster-info">
                    <p className="futbol-transfer-name">{p.name}</p>
                    <p className="futbol-buy-meta">
                      {p.age} yaş · {p.power.toFixed(1)} güç · {Math.round(p.form)}% form
                    </p>
                  </div>
                  <span className={`futbol-roster-status ${status.cls}`}>{status.label}</span>
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* v77 — sözleşmeli (maaşlı) futbolcular; hiç yoksa görünmez */}
      <ProContracts team={team} readOnly={role === 'owner' && Boolean(team.managerUid)} />

      {confirmInstantSell && (
        <ConfirmModal
          title="Takımı Sat"
          message={`${team.name} takımını anında satmak istediğine emin misin?`}
          confirmLabel="Evet, Sat"
          onConfirm={runInstantSell}
          onCancel={() => setConfirmInstantSell(false)}
        />
      )}
    </div>
  );
}
